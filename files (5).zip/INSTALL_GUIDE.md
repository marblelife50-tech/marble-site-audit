# Marble Site Audit - Beginner Installation Guide

You need: a Google account, a free GitHub account, a computer (for setup), and an Android phone with Chrome.
Allow about 45 minutes the first time. Do the steps in order.

## How the pieces fit together
- **Frontend** (the app screens): the `frontend` folder. It must live on an **HTTPS website** so the phone can install it and work offline. GitHub Pages is free and simple.
- **Backend** (the "brain"): Google Apps Script, in the `backend` folder. It stores data in a **Google Sheet** and files in **Google Drive**.
- **On the phone**: drafts, photos and PDFs are kept on the phone itself (IndexedDB) so the app works with no signal, and sync when the internet returns.

---
## PART 1 - Google Sheet, Drive folder, Apps Script

**Step 1 - Create the Sheet.** Go to sheets.google.com > Blank. Name it `Marble Site Audit Database`.
Copy its ID: in the address bar it is the long text between `/d/` and `/edit`. Paste it in Notepad as SHEET ID.

**Step 2 - Create the Drive folder.** Go to drive.google.com > New > New folder > `Marble Site Audit`. Open it.
The address looks like `drive.google.com/drive/folders/XXXXXXXX`. Copy the XXXXXXXX part as FOLDER ID.
Keep this folder private (do not share it).

**Step 3 - Open Apps Script.** In the Sheet: **Extensions > Apps Script**. A code editor opens.

**Step 4 - Create the files.** For each file in the `backend` folder:
1. Click **+** next to "Files" > **Script**. Name it exactly like the file without `.gs` (for example `Config`, `Db`, `Auth`, `Code`, `Setup`...).
2. Delete the sample code and paste the file's content. (The default file `Code.gs` already exists: paste `Code.gs` into it.)
The 13 script files are: Code, Config, Db, Auth, Validation, Projects, Findings, Photos, Reports, Sync, Settings, DriveFolders, Setup.
3. Click the gear icon (**Project Settings**) > tick **Show "appsscript.json" manifest file in editor**. Go back to Editor, open `appsscript.json`, replace all its text with the provided file.

**Step 5 - Put your two IDs in.** Open `Config` and replace `PASTE_SPREADSHEET_ID_HERE` and `PASTE_ROOT_FOLDER_ID_HERE` (keep the quote marks). Click the save icon.

**Step 6 - Set your access code.** Open `Setup`. In `setAccessCode()` change `TYPE-YOUR-CODE-HERE` (in the `NEW_CODE` line only) to a **strong code of 10+ characters**. Choose `setAccessCode` in the dropdown at the top > **Run**.
Google asks for permission: **Review permissions > choose your account > Advanced > Go to project (unsafe) > Allow**. (It says "unsafe" only because you wrote the script yourself.)
Afterwards change the line **back** to `TYPE-YOUR-CODE-HERE` and save, so your code is not left in the script.

**Step 7 - Create the tabs.** Run `setupAll`. Then run `verifySetup`. The log (View > Logs) must end with `ALL CHECKS PASSED`.
Your Sheet now has the tabs: Projects, Findings, Photos, Reports, Sync Log, Settings.

**Step 8 - Deploy.** **Deploy > New deployment > gear icon > Web app.**
- Description: `Marble Site Audit`
- Execute as: **Me**
- Who has access: **Anyone**
Click Deploy and copy the **Web app URL** (ends in `/exec`).

> **What "Execute as Me / Anyone" means.** The script runs with *your* Google permissions, so the app can write to your Sheet and Drive even though the phone is not logged in to Google. "Anyone" means anyone who knows the URL can *reach* the script, but every action except login requires a session token that is only issued for your access code (5 wrong tries lock login for 15 minutes). Keep the access code secret and strong, never put it in the website files, and never make the Drive folder or Sheet public. The script has access to all your Drive, so do not paste code from other sources into it.

---
## PART 2 - Put the app on the web (GitHub Pages)

**Step 9 - Edit config.js.** Open `frontend/config.js` in Notepad. Replace `PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE` with your Web app URL. Save.

**Step 10 - Create the site.**
1. Sign in at github.com > **New repository** > name `site-audit` > **Public** (free GitHub Pages needs public) > Create.
2. **Add file > Upload files.** Drag in the **contents** of the `frontend` folder (index.html, styles.css, config.js, db.js, api.js, photos.js, sync.js, pdf.js, app.js, sw.js, manifest.webmanifest and the `icons` and `vendor` folders). Make sure the `icons` and `vendor` folders are uploaded with their files inside. Commit.
3. **Settings > Pages > Source: Deploy from a branch > Branch: main, folder: / (root) > Save.**
4. After about 1-2 minutes your app is at `https://YOUR-USERNAME.github.io/site-audit/`.

> The site files are public, including your Web app URL. That is acceptable only because the data is protected by the access code. Do not put anything secret in the frontend files.

---
## PART 3 - Use it on the Android phone

**Step 11 - Open the app.** In Chrome on the phone open your address. Log in with the access code (needs internet the first time). Wait a few seconds so the app saves itself for offline use.

**Step 12 - Add to Home Screen.** Chrome menu (three dots) > **Add to Home screen** (or **Install app**). Open it from the new icon.

**Step 13 - First settings.** Bottom bar > **Settings**: enter company name/address/phone, default inspector, review the disclaimer text, **Save settings**, and upload your logo (PNG or JPEG, max 1 MB). Tap **Protect local data from automatic clean-up**.

**Step 14 - Test.** Follow `TEST_CHECKLIST.md`.

---
## Updating later
- **Changed a frontend file?** Re-upload it to GitHub **and** change `CACHE_VERSION` in `sw.js` (for example `v1.0.0-2`). Phones show "A new version is ready" > tap Reload.
- **Changed backend code?** In Apps Script: **Deploy > Manage deployments > pencil icon > Version: New version > Deploy**. The URL stays the same.
- **Forgot the access code?** Run `setAccessCode` again with a new code (this logs every device out).

## Free-account limits and honest notes
- Google applies daily quotas to Apps Script, Drive and Sheets that can change; see Google's "Apps Script quotas" page. Normal inspection use is well within them. Each request must finish within Apps Script's execution time limit, which is why photos are sent one at a time.
- Photos are compressed to about 1600 px, roughly 300-600 KB each. 1,000 photos is about 0.5 GB of Drive space (free Drive is 15 GB shared with Gmail/Photos).
- The phone browser decides how much local storage you get; the Settings screen shows usage. Sync regularly and do not clear browser data for the site before syncing.
- Offline works only after the app has been opened once online from the HTTPS site. It does not work from a plain Apps Script link.
- PDF text supports Latin characters; Arabic text prints as "?".
- Deleting is soft: deleted projects can be restored; removed Drive files go to the Drive trash.
