# Marble Site Audit - Test Checklist (Android phone)

Tick each line. If something fails, note what you tapped and the message shown (screenshot it).
Use a test project named `TEST - delete me`. Keep the Google Sheet and Drive folder open on a computer to verify.

## A. Install and login
- [ ] Site opens in Chrome; login screen appears.
- [ ] Wrong code shows "Incorrect access code" (do NOT try more than 3 times).
- [ ] Correct code opens the dashboard. Chips show "Online" and "Synced".
- [ ] Add to Home Screen works; app opens full-screen from the icon.
- [ ] Settings: save company details and upload a logo; both show after reopening Settings.

## B. New project
- [ ] New Project > Save Draft with empty fields shows red "Required" on name, client, location.
- [ ] Fill the fields, Save Draft: message says saved on this phone; chip shows Pending then Synced.
- [ ] Google Sheet **Projects** tab has exactly 1 row with a PRJ-... ID and phone number intact (leading + or 0 kept).
- [ ] Drive has `Marble Site Audit / PRJ-... - TEST - delete me / Photos, Reports, Supporting Documents`.

## C. Multiple findings and photos
- [ ] Add 3 findings (different areas, one with finish "Other" and defect "Other": extra boxes appear).
- [ ] Sheet **Findings** has 3 rows with the same project_id and sort_order 1,2,3.
- [ ] In finding 1 tap **Take Photo**, capture one photo; preview appears; choose "Before", type a caption, Add photo.
- [ ] Add 2 more via **Choose from Gallery** (select two at once); try "Add the rest without captions".
- [ ] Choosing the same picture twice says it is already attached.
- [ ] Change a caption and a label (Before > After) on a saved photo.
- [ ] Replace one photo; Remove one photo (confirm dialog appears).
- [ ] Sync Now. Sheet **Photos** rows have correct project_id/finding_id; Drive has files in `Photos/FND-... - Area/` (the right finding folder); the removed photo is in Drive Trash.

## D. Reorder, edit, reopen
- [ ] Move finding 3 to top with the arrows; Sync; Sheet sort_order changes; reopen the project: order kept.
- [ ] Edit a finding (change priority), Save, reopen: change kept and its photos still attached.
- [ ] Close the app completely, reopen: project, findings, photos all still there.
- [ ] Edit the project name, Save: Drive folder is renamed; findings and photos unchanged.
- [ ] Search by client name and by location finds the project; Status filter works; Clear filters works.

## E. PDF report
- [ ] Generate PDF Report with no findings: asks you to add one.
- [ ] With findings: loading message, then "Report saved to Google Drive" **only after** it is really in Drive.
- [ ] Sheet **Reports** has a row; Drive `Reports/` folder holds the PDF; project status became "Report Generated".
- [ ] Preview / Open in Drive / Download buttons work (Preview may be blank on some Androids: Open/Download must work).
- [ ] PDF: logo or placeholder at top, title, details, executive summary, numbered findings, photos with captions (not cut off), "possible cause" labelled as inspector's assessment, recommendations, disclaimer, signature boxes, "Page X of Y", report date.
- [ ] Turn on Airplane mode and generate again: PDF is created and the app says it is NOT on Drive yet; after reconnecting and Sync Now it is uploaded.

## F. Offline and sync
- [ ] Airplane mode: chip shows "Offline". Open the app from the Home Screen: it still opens.
- [ ] Offline: create a new project, add a finding and a photo, edit an older project. Everything saves; chip shows "Pending sync (n)".
- [ ] Turn internet on: it syncs automatically within a few seconds (or tap Sync Now). Sheet/Drive now match.
- [ ] Tap Sync Now again, and again: no duplicate rows and no duplicate Drive files.
- [ ] Switch to airplane mode in the middle of a sync: nothing is lost; the next sync finishes it.
- [ ] Tap the sync chip: the list shows waiting/failed items; "Retry failed" works.

## G. Two devices and conflicts
- [ ] On a second device (or a Chrome tab on a computer) log in and open the same project; it appears with its findings and photos.
- [ ] Change the project's **site location** on phone A while offline; change the **client name** on device B and sync B. Reconnect A and sync: A shows "Changed on another device" with options (Keep mine / Use server / Save as copy). Try each on test data; nothing is silently overwritten.

## H. Delete and restore
- [ ] Delete a finding (confirmation shown); gone from the app; Sheet row has deleted = Y.
- [ ] Delete the project; it disappears; Filters > Status > "Deleted (restore)" shows it; Restore brings back findings, photos and reports.
- [ ] Duplicate project (online, after syncing): new "(Copy)" project with the findings, no photos.

## I. Errors and safety
- [ ] Wrong API_URL (test on a copy): a clear message, no crash, local data kept.
- [ ] Settings > Clear local data: warns strongly if anything is unsynced; Cancel keeps data.
- [ ] Typing `<script>` or `<b>` in a field shows as plain text.
- [ ] Drive folder and files are not shared publicly (Drive > Share shows only you).
- [ ] After 12 hours (or after re-running setAccessCode) the app asks you to log in again; offline work is still there.

## J. Android usability
- [ ] Buttons are easy to hit with a thumb; text readable in sunlight; keyboard does not hide the field you type in.
- [ ] Rotating the phone does not lose typed text.
- [ ] Android Back button moves back one screen and asks before discarding unsaved changes.
