/* Marble Site Audit - api.js
   The only file that talks to the Apps Script backend. Sends text/plain JSON (no CORS pre-flight). */
(function () {
  'use strict';
  const C = window.APP_CONFIG;
  let token = null, expiresAt = 0, deviceId = 'unknown';
  let authLostHandler = null;

  function ApiError(code, message, data) {
    const e = new Error(message);
    e.code = code; e.data = data || null; e.name = 'ApiError';
    return e;
  }

  const API = {
    ApiError: ApiError,

    init: async function () {
      deviceId = await DB.getMeta('deviceId', null);
      if (!deviceId) { deviceId = Ids.device(); await DB.setMeta('deviceId', deviceId); }
      const s = await DB.getMeta('session', null);
      if (s && s.token && s.expiresAt > Date.now()) { token = s.token; expiresAt = s.expiresAt; }
    },
    getDeviceId: function () { return deviceId; },
    isConfigured: function () { return !!C.API_URL && C.API_URL.indexOf('PASTE_') !== 0; },
    hasToken: function () { return !!token && expiresAt > Date.now(); },
    onAuthLost: function (fn) { authLostHandler = fn; },

    login: async function (code) {
      const d = await API.call('login', { code: code }, { noAuth: true });
      token = d.token; expiresAt = d.expiresAt;
      await DB.setMeta('session', { token: token, expiresAt: expiresAt });
      await DB.setMeta('everLoggedIn', true);
    },
    logout: async function () { token = null; expiresAt = 0; await DB.setMeta('session', null); },

    /** Resolves with response.data, or throws ApiError { code, message, data }. */
    call: async function (action, payload, opts) {
      opts = opts || {};
      if (!API.isConfigured()) throw ApiError('NOT_CONFIGURED', 'API_URL is not set in config.js.');
      if (!navigator.onLine) throw ApiError('NETWORK', 'No internet connection.');
      const ctl = new AbortController();
      const timer = setTimeout(function () { ctl.abort(); }, opts.timeout || C.REQUEST_TIMEOUT_MS);
      let res, text;
      try {
        res = await fetch(C.API_URL, {
          method: 'POST', redirect: 'follow', credentials: 'omit', signal: ctl.signal,
          headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify({
            action: action, token: opts.noAuth ? undefined : token, deviceId: deviceId,
            operationId: opts.operationId || undefined, payload: payload || {}
          })
        });
        text = await res.text();
      } catch (e) {
        throw ApiError(e.name === 'AbortError' ? 'TIMEOUT' : 'NETWORK',
          e.name === 'AbortError' ? 'The server took too long to answer.' : 'Could not reach the server.');
      } finally { clearTimeout(timer); }

      let json;
      try { json = JSON.parse(text); }
      catch (e) {
        throw ApiError('BAD_RESPONSE', 'Unexpected reply from the server. Check that the web app is deployed with access "Anyone" and that API_URL ends in /exec.');
      }
      if (!json.ok) {
        const er = json.error || {};
        if (er.code === 'AUTH') { token = null; expiresAt = 0; DB.setMeta('session', null); if (authLostHandler) authLostHandler(); }
        throw ApiError(er.code || 'SERVER_ERROR', er.message || 'Server error.', er.data);
      }
      return json.data;
    }
  };
  window.API = API;
})();
