/* Marble Site Audit - photos.js
   Compresses photos on the phone, stores them locally, and loads missing ones from Drive. */
(function () {
  'use strict';
  const C = window.APP_CONFIG;

  async function decode(file) {
    if (window.createImageBitmap) {
      try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch (e) { /* fall back */ }
    }
    return new Promise(function (resolve, reject) {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = function () { URL.revokeObjectURL(url); resolve(img); };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('This file is not a readable image.')); };
      img.src = url;
    });
  }

  function toJpeg(canvas, q) {
    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (b) { b ? resolve(b) : reject(new Error('Could not compress the photo.')); }, 'image/jpeg', q);
    });
  }

  const Photos = {
    /** file -> { blob, width, height, hash, size } (JPEG, longest side <= PHOTO_MAX_DIMENSION, under the upload limit) */
    process: async function (file) {
      if (!file || !/^image\//.test(file.type || 'image/jpeg')) throw new Error('Please choose an image file.');
      const bmp = await decode(file);
      let w = bmp.width, h = bmp.height;
      let maxDim = C.PHOTO_MAX_DIMENSION, q = C.PHOTO_JPEG_QUALITY, blob = null;
      for (let attempt = 0; attempt < 5; attempt++) {
        const scale = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
        w = Math.max(1, Math.round(bmp.width * scale)); h = Math.max(1, Math.round(bmp.height * scale));
        const cv = document.createElement('canvas');
        cv.width = w; cv.height = h;
        const ctx = cv.getContext('2d');
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h);
        ctx.drawImage(bmp, 0, 0, w, h);
        blob = await toJpeg(cv, q);
        if (blob.size <= C.PHOTO_MAX_UPLOAD_BYTES) break;
        q = Math.max(0.5, q - 0.1); maxDim = Math.round(maxDim * 0.8);
      }
      if (bmp.close) bmp.close();
      if (blob.size > C.PHOTO_MAX_UPLOAD_BYTES) throw new Error('This photo is too large even after compression.');
      return { blob: blob, width: w, height: h, size: blob.size, hash: await Util.sha256Hex(blob) };
    },

    /** Saves a processed photo + its image for a finding. Returns the photo record. */
    add: async function (finding, processed, stage, caption, sortOrder) {
      const rec = DB.newPhoto({
        project_id: finding.project_id, finding_id: finding.finding_id, stage: stage || 'Before',
        caption: caption || '', sort_order: sortOrder, file_name: 'photo.jpg', mime_type: 'image/jpeg',
        size_bytes: processed.size, width: processed.width, height: processed.height,
        content_hash: processed.hash, opId: Ids.op(), dirty: false, rev: 1
      });
      await DB.putBlob(rec.photo_id, processed.blob, processed.hash);
      await DB.put('photos', rec);
      return rec;
    },

    /** Swaps the image of an existing photo (same photo_id, so the server replaces the Drive file). */
    replace: async function (rec, processed) {
      await DB.putBlob(rec.photo_id, processed.blob, processed.hash);
      Object.assign(rec, { size_bytes: processed.size, width: processed.width, height: processed.height,
        content_hash: processed.hash, uploaded: false, updated_at: Util.nowIso() });
      DB.touch(rec);
      await DB.put('photos', rec);
      return rec;
    },

    /** Returns the image Blob, downloading it from Drive (and caching it) if this phone does not have it. */
    ensureBlob: async function (rec) {
      const b = await DB.getBlob(rec.photo_id);
      if (b && b.blob) return b.blob;
      if (!rec.uploaded || !navigator.onLine || !API.hasToken()) return null;
      try {
        const d = await API.call('getPhotoData', { photoId: rec.photo_id });
        const blob = Util.base64ToBlob(d.dataBase64, d.mime_type);
        await DB.putBlob(rec.photo_id, blob, d.content_hash);
        return blob;
      } catch (e) { return null; }
    }
  };
  window.Photos = Photos;
})();
