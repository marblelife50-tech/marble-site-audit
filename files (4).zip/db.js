/* Marble Site Audit - db.js
   Offline storage (IndexedDB) plus small helpers shared by every other script.
   Loaded right after config.js.

   Local records are the server's fields PLUS bookkeeping fields used by the sync engine:
     dirty        - has changes that are not on the server yet
     rev          - counts local edits (detects edits made while a sync request was in flight)
     opId         - operation ID of the latest local edit (the server uses it to ignore repeats)
     isNew        - never successfully saved on the server
     attempted    - a request to create it was sent at least once (so deletes must still be sent)
     conflict     - { kind, server } when another device changed it
     syncError    - last error message from the server
*/
(function () {
  'use strict';
  const C = window.APP_CONFIG;
  const UP = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const LOW = 'abcdefghijklmnopqrstuvwxyz0123456789';

  function randStr(n, chars) {
    const a = new Uint8Array(n);
    crypto.getRandomValues(a);
    let s = '';
    for (let i = 0; i < n; i++) s += chars.charAt(a[i] % chars.length);
    return s;
  }
  function datePart() { return new Date().toISOString().slice(0, 10).replace(/-/g, ''); }

  /* ---------- IDs (same formats the server checks in Config.gs) ---------- */
  const Ids = {
    project: function () { return 'PRJ-' + datePart() + '-' + randStr(6, UP); },
    finding: function () { return 'FND-' + datePart() + '-' + randStr(6, UP); },
    photo: function () { return 'PHT-' + datePart() + '-' + randStr(8, UP); },
    report: function () { return 'RPT-' + datePart() + '-' + randStr(6, UP); },
    op: function () { return 'op_' + randStr(22, LOW); },
    device: function () { return 'DEV-' + randStr(12, UP); }
  };

  /* ---------- Small utilities ---------- */
  const Util = {
    nowIso: function () { return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'); },

    sha256Hex: async function (blob) {
      const buf = await blob.arrayBuffer();
      const digest = await crypto.subtle.digest('SHA-256', buf);
      return Array.from(new Uint8Array(digest)).map(function (b) { return b.toString(16).padStart(2, '0'); }).join('');
    },

    blobToBase64: function (blob) {
      return new Promise(function (resolve, reject) {
        const r = new FileReader();
        r.onload = function () { resolve(String(r.result).split(',')[1] || ''); };
        r.onerror = function () { reject(new Error('Could not read the file.')); };
        r.readAsDataURL(blob);
      });
    },

    base64ToBlob: function (b64, mime) {
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new Blob([bytes], { type: mime || 'application/octet-stream' });
    },

    debounce: function (fn, ms) {
      let t = null;
      return function () {
        const args = arguments;
        clearTimeout(t);
        t = setTimeout(function () { fn.apply(null, args); }, ms);
      };
    },

    bySort: function (a, b) {
      const x = a.sort_order == null ? 1e9 : a.sort_order;
      const y = b.sort_order == null ? 1e9 : b.sort_order;
      if (x !== y) return x - y;
      return String(a.created_at || a.captured_at || '').localeCompare(String(b.created_at || b.captured_at || ''));
    }
  };

  /* ---------- IndexedDB ---------- */
  const STORES = {
    meta: { keyPath: 'key' },
    projects: { keyPath: 'project_id' },
    findings: { keyPath: 'finding_id', indexes: [['project_id', 'project_id']] },
    photos: { keyPath: 'photo_id', indexes: [['project_id', 'project_id'], ['finding_id', 'finding_id']] },
    blobs: { keyPath: 'id' },                       // photo images and PDF files (kept apart so lists stay fast)
    reports: { keyPath: 'report_id', indexes: [['project_id', 'project_id']] }
  };

  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve, reject) {
      if (!window.indexedDB) { reject(new Error('This browser does not support offline storage (IndexedDB).')); return; }
      const req = indexedDB.open(C.DB_NAME, C.DB_VERSION);
      req.onupgradeneeded = function () {
        const db = req.result;
        Object.keys(STORES).forEach(function (name) {
          const os = db.objectStoreNames.contains(name)
            ? req.transaction.objectStore(name)
            : db.createObjectStore(name, { keyPath: STORES[name].keyPath });
          (STORES[name].indexes || []).forEach(function (ix) {
            if (!os.indexNames.contains(ix[0])) os.createIndex(ix[0], ix[1]);
          });
        });
      };
      req.onsuccess = function () {
        const db = req.result;
        db.onversionchange = function () { db.close(); };
        resolve(db);
      };
      req.onerror = function () { reject(req.error || new Error('Could not open offline storage.')); };
      req.onblocked = function () { reject(new Error('Offline storage is blocked by another open tab. Close other tabs of this app.')); };
    });
    return dbPromise;
  }

  /** Runs one request inside its own transaction and resolves when the transaction has COMMITTED. */
  function op(store, mode, fn) {
    return open().then(function (db) {
      return new Promise(function (resolve, reject) {
        const t = db.transaction(store, mode);
        let r;
        try { r = fn(t.objectStore(store)); }
        catch (e) { try { t.abort(); } catch (x) { /* ignore */ } reject(e); return; }
        t.oncomplete = function () { resolve(r && r.result); };
        t.onerror = function () { reject(t.error || new Error('Storage error')); };
        t.onabort = function () { reject(t.error || new Error('Storage was interrupted')); };
      });
    });
  }

  const DB = {
    open: open,
    get: function (store, key) { return op(store, 'readonly', function (os) { return os.get(key); }); },
    put: function (store, value) { return op(store, 'readwrite', function (os) { return os.put(value); }); },
    del: function (store, key) { return op(store, 'readwrite', function (os) { return os.delete(key); }); },
    all: function (store) { return op(store, 'readonly', function (os) { return os.getAll(); }); },
    byIndex: function (store, index, value) {
      return op(store, 'readonly', function (os) { return os.index(index).getAll(value); });
    },
    clear: function (store) { return op(store, 'readwrite', function (os) { return os.clear(); }); },
    putMany: function (store, values) {
      return open().then(function (db) {
        return new Promise(function (resolve, reject) {
          const t = db.transaction(store, 'readwrite');
          const os = t.objectStore(store);
          values.forEach(function (v) { os.put(v); });
          t.oncomplete = function () { resolve(); };
          t.onerror = function () { reject(t.error || new Error('Storage error')); };
          t.onabort = function () { reject(t.error || new Error('Storage was interrupted')); };
        });
      });
    },

    /* ----- meta (device ID, session, settings cache, last sync...) ----- */
    getMeta: function (key, fallback) {
      return DB.get('meta', key).then(function (r) { return r && r.value !== undefined ? r.value : fallback; });
    },
    setMeta: function (key, value) { return DB.put('meta', { key: key, value: value }); },

    /* ----- blobs ----- */
    putBlob: function (id, blob, hash) { return DB.put('blobs', { id: id, blob: blob, hash: hash || '' }); },
    getBlob: function (id) { return DB.get('blobs', id); },

    /* ----- local edit bookkeeping ----- */
    touch: function (e, opField) {
      e.rev = (e.rev || 0) + 1;
      e[opField || 'opId'] = Ids.op();
      if (!opField || opField === 'opId') e.dirty = true;
      e.syncError = '';
      e.syncErrorCode = '';
      return e;
    },

    /* ----- permanent local removal (only for things the server never saw, or after the server confirmed) ----- */
    purgePhoto: async function (photoId) {
      await DB.del('blobs', photoId);
      await DB.del('photos', photoId);
    },
    purgeFinding: async function (findingId) {
      const photos = await DB.byIndex('photos', 'finding_id', findingId);
      for (const p of photos) await DB.purgePhoto(p.photo_id);
      await DB.del('findings', findingId);
    },
    purgeReport: async function (reportId) {
      await DB.del('blobs', reportId);
      await DB.del('reports', reportId);
    },
    purgeProject: async function (projectId) {
      const findings = await DB.byIndex('findings', 'project_id', projectId);
      for (const f of findings) await DB.purgeFinding(f.finding_id);
      const photos = await DB.byIndex('photos', 'project_id', projectId);
      for (const p of photos) await DB.purgePhoto(p.photo_id);
      const reports = await DB.byIndex('reports', 'project_id', projectId);
      for (const r of reports) await DB.purgeReport(r.report_id);
      await DB.del('projects', projectId);
    },

    /** Wipes everything except this phone's device ID. */
    clearAllData: async function () {
      const dev = await DB.getMeta('deviceId', null);
      for (const s of ['projects', 'findings', 'photos', 'blobs', 'reports', 'meta']) await DB.clear(s);
      if (dev) await DB.setMeta('deviceId', dev);
    },

    /* ----- record factories ----- */
    PROJECT_FIELDS: ['project_name', 'client_name', 'building_name', 'site_location', 'contact_person',
      'contact_phone', 'contact_email', 'inspection_datetime', 'inspector_name', 'job_reference', 'status',
      'general_notes', 'overall_condition', 'executive_summary', 'overall_recommendations', 'client_rep_name'],
    FINDING_FIELDS: ['area_location', 'material_type', 'finish', 'finish_other', 'defect_category',
      'defect_category_other', 'existing_condition', 'defect_description', 'possible_cause',
      'recommended_method', 'required_materials', 'estimated_area_sqm', 'priority', 'inspector_remarks',
      'client_remarks', 'next_action'],

    syncDefaults: function () {
      return {
        dirty: false, rev: 0, opId: '', delOpId: '', isNew: true, attempted: false,
        conflict: null, syncError: '', syncErrorCode: '', delState: ''
      };
    },

    newProject: function (fields) {
      const now = Util.nowIso();
      return Object.assign({
        project_id: Ids.project(),
        project_name: '', client_name: '', building_name: '', site_location: '', contact_person: '',
        contact_phone: '', contact_email: '', inspection_datetime: '', inspector_name: '', job_reference: '',
        status: 'Draft', general_notes: '', overall_condition: '', executive_summary: '',
        overall_recommendations: '', client_rep_name: '',
        drive_folder_id: '', photos_folder_id: '', reports_folder_id: '', supporting_folder_id: '',
        latest_report_id: '', version: 0, created_at: now, updated_at: now, last_device_id: '',
        deleted: '', deleted_at: '',
        restorePending: false, restoreOpId: '', orderDirty: false, orderOpId: '', orderRev: 0,
        partial: false, stale: false
      }, DB.syncDefaults(), fields || {});
    },

    newFinding: function (projectId, sortOrder, fields) {
      const now = Util.nowIso();
      return Object.assign({
        finding_id: Ids.finding(), project_id: projectId, sort_order: sortOrder,
        area_location: '', material_type: '', finish: '', finish_other: '', defect_category: '',
        defect_category_other: '', existing_condition: '', defect_description: '', possible_cause: '',
        recommended_method: '', required_materials: '', estimated_area_sqm: null, priority: 'Medium',
        inspector_remarks: '', client_remarks: '', next_action: '', drive_folder_id: '',
        version: 0, created_at: now, updated_at: now, last_device_id: '', deleted: '', deleted_at: ''
      }, DB.syncDefaults(), fields || {});
    },

    newPhoto: function (fields) {
      return Object.assign({
        photo_id: Ids.photo(), project_id: '', finding_id: '', stage: 'Before', caption: '', sort_order: 1,
        file_name: '', mime_type: 'image/jpeg', size_bytes: 0, width: 0, height: 0, content_hash: '',
        drive_file_id: '', drive_url: '', captured_at: Util.nowIso(), uploaded_at: '', updated_at: Util.nowIso(),
        deleted: '', deleted_at: '',
        uploaded: false, metaDirty: false, metaOpId: ''
      }, DB.syncDefaults(), fields || {});
    },

    newReport: function (fields) {
      return Object.assign({
        report_id: Ids.report(), project_id: '', file_name: '', drive_file_id: '', drive_url: '',
        project_version: 0, size_bytes: 0, content_hash: '', generated_at: Util.nowIso(),
        generated_by_device: '', deleted: '', deleted_at: '', uploaded: false
      }, DB.syncDefaults(), fields || {});
    }
  };

  window.Ids = Ids;
  window.Util = Util;
  window.DB = DB;
})();
