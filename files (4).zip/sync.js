/* Marble Site Audit - sync.js
   Pushes local changes to Google Sheets/Drive and pulls other devices' changes.
   Order: projects -> findings -> finding order -> photo uploads -> photo edits/deletes -> reports -> pull.
   Duplicate safety: every record has a permanent ID, every write carries an operationId, and
   the server answers a repeated operationId with the stored result instead of repeating it. */
(function () {
  'use strict';
  const C = window.APP_CONFIG;
  const listeners = [];
  let running = null;
  let state = { status: 'idle', message: '' };
  let timer = null;

  function on(fn) { listeners.push(fn); }
  function emit() { listeners.forEach(function (fn) { try { fn(state); } catch (e) { console.error(e); } }); }
  function setState(status, message) { state = { status: status, message: message || '' }; emit(); }
  function isFatal(e) { return ['NETWORK', 'TIMEOUT', 'AUTH', 'NOT_CONFIGURED', 'BAD_RESPONSE', 'BUSY'].indexOf(e.code) > -1; }
  function toErr(o) { const e = new Error((o && o.message) || 'Sync failed.'); e.code = (o && o.code) || 'SERVER_ERROR'; e.data = o && o.data; return e; }

  /* ---------- What is waiting? ---------- */
  function projectPending(p) { return !!(p.dirty || p.delState === 'pending' || p.restorePending || p.orderDirty); }
  function photoPending(p) { return p.deleted !== 'Y' ? (!p.uploaded || p.metaDirty) : p.delState === 'pending'; }
  function reportPending(r) { return r.delState === 'pending' || (!r.uploaded && r.deleted !== 'Y'); }

  /** Returns every waiting / failed / conflicting item, and the IDs of projects that have something waiting. */
  async function scan() {
    const projects = await DB.all('projects'), findings = await DB.all('findings');
    const photos = await DB.all('photos'), reports = await DB.all('reports');
    const live = {}, name = {};
    projects.forEach(function (p) { name[p.project_id] = p.project_name || p.project_id; live[p.project_id] = !(p.deleted === 'Y' || p.delState); });
    const items = [], pendingProjects = new Set();
    function add(kind, id, pid, label, e, pending) {
      const state = e.conflict ? 'Conflict' : (e.syncError ? 'Failed' : (pending ? 'Pending' : ''));
      if (!state) return;
      items.push({ kind: kind, id: id, projectId: pid, label: label, state: state, error: e.syncError || '' });
      pendingProjects.add(pid);
    }
    projects.forEach(function (p) { add('project', p.project_id, p.project_id, 'Project: ' + (p.project_name || p.project_id), p, projectPending(p)); });
    findings.forEach(function (f) { if (live[f.project_id]) add('finding', f.finding_id, f.project_id, 'Finding: ' + (f.area_location || f.finding_id) + ' (' + name[f.project_id] + ')', f, f.dirty || f.delState === 'pending'); });
    photos.forEach(function (ph) { if (live[ph.project_id]) add('photo', ph.photo_id, ph.project_id, 'Photo: ' + (ph.caption || ph.stage) + ' (' + name[ph.project_id] + ')', ph, photoPending(ph)); });
    reports.forEach(function (r) { if (live[r.project_id]) add('report', r.report_id, r.project_id, 'PDF: ' + r.file_name, r, reportPending(r)); });
    return {
      items: items, pendingProjects: pendingProjects,
      pending: items.filter(function (i) { return i.state === 'Pending'; }).length,
      failed: items.filter(function (i) { return i.state === 'Failed'; }).length,
      conflicts: items.filter(function (i) { return i.state === 'Conflict'; }).length
    };
  }

  /* ---------- Error bookkeeping ---------- */
  function markError(cur, e, summary) {
    if (e.code === 'CONFLICT' || e.code === 'DELETED_ON_SERVER') {
      const srv = e.data && (e.data.serverProject || e.data.serverFinding) || null;
      cur.conflict = { kind: e.code === 'CONFLICT' ? 'conflict' : 'deleted', server: srv };
      cur.syncError = e.code === 'CONFLICT' ? 'Changed on another device.' : 'Deleted on the server.';
      summary.conflicts++;
    } else { cur.syncError = e.message || 'Sync failed.'; cur.syncErrorCode = e.code || ''; summary.failed++; }
  }

  async function sendBatch(ops, apply) {
    for (let i = 0; i < ops.length; i += C.SYNC_BATCH_SIZE) {
      const chunk = ops.slice(i, i + C.SYNC_BATCH_SIZE);
      const data = await API.call('syncBatch', { operations: chunk.map(function (o) { return { operationId: o.operationId, action: o.action, payload: o.payload }; }) });
      const by = {};
      (data.results || []).forEach(function (r) { by[r.operationId] = r; });
      for (const o of chunk) {
        const r = by[o.operationId] || { ok: false, error: { code: 'SERVER_ERROR', message: 'No result returned.' } };
        await apply(o, r.ok ? r.data : null, r.ok ? null : toErr(r.error));
      }
    }
  }

  function pick(obj, keys) { const o = {}; keys.forEach(function (k) { o[k] = obj[k] == null ? '' : obj[k]; }); return o; }
  const SERVER_PROJECT_KEYS = ['drive_folder_id', 'photos_folder_id', 'reports_folder_id', 'supporting_folder_id', 'latest_report_id', 'created_at', 'updated_at', 'last_device_id'];

  /* ---------- 1. Projects ---------- */
  async function pushProjects(sum) {
    for (let pass = 0; pass < 2; pass++) {
      const ops = [];
      const list = await DB.all('projects');
      for (const p of list) {
        if (p.conflict) continue;
        let o = null;
        if (p.delState === 'pending') o = { action: 'deleteProject', operationId: p.delOpId, payload: { projectId: p.project_id }, type: 'del' };
        else if (p.restorePending) o = { action: 'restoreProject', operationId: p.restoreOpId, payload: { projectId: p.project_id }, type: 'restore' };
        else if (p.dirty && p.deleted !== 'Y') {
          const f = pick(p, DB.PROJECT_FIELDS); f.project_id = p.project_id;
          o = { action: 'saveProject', operationId: p.opId, payload: { project: f, baseVersion: p.version }, type: 'save' };
        }
        if (!o) continue;
        o.id = p.project_id; o.rev = p.rev;
        if (!p.attempted) { p.attempted = true; await DB.put('projects', p); }
        ops.push(o);
      }
      if (!ops.length) return;
      await sendBatch(ops, async function (o, d, err) {
        const cur = await DB.get('projects', o.id); if (!cur) return;
        if (err) { if (isFatal(err)) throw err; markError(cur, err, sum); await DB.put('projects', cur); return; }
        if (o.type === 'save') {
          cur.version = d.project.version; cur.isNew = false;
          SERVER_PROJECT_KEYS.forEach(function (k) { cur[k] = d.project[k]; });
          if (cur.rev === o.rev) { cur.dirty = false; cur.syncError = ''; cur.syncErrorCode = ''; }
        } else if (o.type === 'del') {
          if (d.project) cur.version = d.project.version;
          cur.isNew = false;
          if (cur.delState === 'pending') { cur.delState = 'synced'; cur.deleted = 'Y'; }
          else { cur.delState = 'synced'; cur.deleted = ''; cur.restorePending = true; cur.restoreOpId = Ids.op(); }   // restored while sending
          cur.syncError = '';
        } else if (o.type === 'restore') {
          await mergeBundle(d, { rebase: true });
          const again = await DB.get('projects', o.id);
          again.restorePending = false; again.delState = ''; again.deleted = ''; again.syncError = '';
          await DB.put('projects', again); return;
        }
        sum.done++;
        await DB.put('projects', cur);
      });
    }
  }

  /* ---------- 2. Findings ---------- */
  async function pushFindings(sum) {
    const projects = {}; (await DB.all('projects')).forEach(function (p) { projects[p.project_id] = p; });
    const ops = [];
    for (const f of await DB.all('findings')) {
      const p = projects[f.project_id];
      if (!p || p.isNew || p.deleted === 'Y' || p.delState || p.conflict || f.conflict) continue;
      let o = null;
      if (f.delState === 'pending') o = { action: 'deleteFinding', operationId: f.delOpId, payload: { findingId: f.finding_id }, type: 'del' };
      else if (f.dirty && f.deleted !== 'Y') {
        const d = pick(f, DB.FINDING_FIELDS); d.estimated_area_sqm = f.estimated_area_sqm;
        d.finding_id = f.finding_id; d.project_id = f.project_id; d.sort_order = f.sort_order;
        o = { action: 'saveFinding', operationId: f.opId, payload: { finding: d, baseVersion: f.version }, type: 'save' };
      }
      if (!o) continue;
      o.id = f.finding_id; o.rev = f.rev;
      if (!f.attempted) { f.attempted = true; await DB.put('findings', f); }
      ops.push(o);
    }
    await sendBatch(ops, async function (o, d, err) {
      const cur = await DB.get('findings', o.id); if (!cur) return;
      if (err) { if (isFatal(err)) throw err; markError(cur, err, sum); await DB.put('findings', cur); return; }
      sum.done++;
      if (o.type === 'del') { await DB.purgeFinding(o.id); return; }
      cur.version = d.finding.version; cur.isNew = false; cur.drive_folder_id = d.finding.drive_folder_id;
      if (cur.rev === o.rev) { cur.dirty = false; cur.syncError = ''; cur.syncErrorCode = ''; }
      await DB.put('findings', cur);
    });
  }

  /* ---------- 3. Finding order ---------- */
  async function pushOrder(sum) {
    const ops = [];
    const findings = await DB.all('findings');
    for (const p of await DB.all('projects')) {
      if (!p.orderDirty || p.conflict || p.isNew || p.delState || p.deleted === 'Y') continue;
      const mine = findings.filter(function (f) { return f.project_id === p.project_id && f.deleted !== 'Y' && f.delState !== 'pending'; });
      if (mine.some(function (f) { return f.dirty || f.isNew; })) continue;            // wait until every finding is on the server
      ops.push({ action: 'reorderFindings', operationId: p.orderOpId, id: p.project_id, rev: p.orderRev,
        payload: { projectId: p.project_id, order: mine.sort(Util.bySort).map(function (f) { return f.finding_id; }) } });
    }
    await sendBatch(ops, async function (o, d, err) {
      const cur = await DB.get('projects', o.id); if (!cur) return;
      if (err) { if (isFatal(err)) throw err; markError(cur, err, sum); await DB.put('projects', cur); return; }
      if (cur.orderRev === o.rev) cur.orderDirty = false;
      sum.done++; await DB.put('projects', cur);
    });
  }

  /* ---------- 4. Photo uploads (one per request) ---------- */
  async function pushPhotoUploads(sum) {
    const findings = {}; (await DB.all('findings')).forEach(function (f) { findings[f.finding_id] = f; });
    const projects = {}; (await DB.all('projects')).forEach(function (p) { projects[p.project_id] = p; });
    for (const ph of await DB.all('photos')) {
      if (ph.uploaded || ph.deleted === 'Y' || ph.conflict) continue;
      const f = findings[ph.finding_id], p = projects[ph.project_id];
      if (!f || !p || f.isNew || p.isNew || f.deleted === 'Y' || p.deleted === 'Y' || p.delState) continue;
      const b = await DB.getBlob(ph.photo_id);
      if (!b || !b.blob) { ph.syncError = 'The image is missing on this phone.'; sum.failed++; await DB.put('photos', ph); continue; }
      if (!ph.attempted) { ph.attempted = true; await DB.put('photos', ph); }
      const rev = ph.rev;
      try {
        const d = await API.call('uploadPhoto', {
          photo: pick(ph, ['photo_id', 'project_id', 'finding_id', 'stage', 'caption', 'sort_order', 'file_name', 'mime_type', 'width', 'height', 'content_hash', 'captured_at']),
          dataBase64: await Util.blobToBase64(b.blob)
        }, { operationId: ph.opId, timeout: C.UPLOAD_TIMEOUT_MS });
        const cur = await DB.get('photos', ph.photo_id); if (!cur) continue;
        cur.drive_file_id = d.photo.drive_file_id; cur.drive_url = d.photo.drive_url; cur.uploaded_at = d.photo.uploaded_at;
        if (cur.rev === rev) { cur.uploaded = true; cur.metaDirty = false; cur.syncError = ''; cur.syncErrorCode = ''; }
        else cur.uploaded = false;   // replaced again while uploading: send the newer image next
        if (cur.rev === rev) cur.uploaded = true;
        await DB.put('photos', cur); sum.done++;
      } catch (e) {
        if (isFatal(e)) throw e;
        const cur = await DB.get('photos', ph.photo_id);
        if (cur) { cur.syncError = e.message; cur.syncErrorCode = e.code; await DB.put('photos', cur); }
        sum.failed++;
      }
    }
  }

  /* ---------- 5. Photo caption/label edits and deletes ---------- */
  async function pushPhotoEdits(sum) {
    const ops = [];
    for (const ph of await DB.all('photos')) {
      let o = null;
      if (ph.delState === 'pending') o = { action: 'deletePhoto', operationId: ph.delOpId, payload: { photoId: ph.photo_id }, type: 'del' };
      else if (ph.uploaded && ph.metaDirty && ph.deleted !== 'Y')
        o = { action: 'savePhotoMeta', operationId: ph.metaOpId, payload: { photo: pick(ph, ['photo_id', 'stage', 'caption', 'sort_order']) }, type: 'meta' };
      if (!o) continue;
      o.id = ph.photo_id; o.rev = ph.rev; ops.push(o);
    }
    await sendBatch(ops, async function (o, d, err) {
      const cur = await DB.get('photos', o.id); if (!cur) return;
      if (err) {
        if (isFatal(err)) throw err;
        if (err.code === 'GONE' || err.code === 'NOT_FOUND') { if (o.type === 'del') { await DB.purgePhoto(o.id); return; } }
        cur.syncError = err.message; sum.failed++; await DB.put('photos', cur); return;
      }
      sum.done++;
      if (o.type === 'del') { await DB.purgePhoto(o.id); return; }
      if (cur.rev === o.rev) { cur.metaDirty = false; cur.syncError = ''; }
      await DB.put('photos', cur);
    });
  }

  /* ---------- 6. Reports ---------- */
  async function pushReports(sum) {
    const projects = {}; (await DB.all('projects')).forEach(function (p) { projects[p.project_id] = p; });
    const dels = [];
    for (const r of await DB.all('reports')) {
      const p = projects[r.project_id];
      if (!p || p.deleted === 'Y' || p.delState) continue;
      if (r.delState === 'pending') { dels.push({ action: 'deleteReport', operationId: r.delOpId, payload: { reportId: r.report_id }, id: r.report_id }); continue; }
      if (r.uploaded || p.isNew) continue;
      await uploadReport(r.report_id, sum, true);
    }
    await sendBatch(dels, async function (o, d, err) {
      if (err) { if (isFatal(err)) throw err; const cur = await DB.get('reports', o.id); if (cur) { cur.syncError = err.message; await DB.put('reports', cur); } sum.failed++; return; }
      await DB.purgeReport(o.id); sum.done++;
    });
  }

  /** Uploads one stored PDF. Returns true only when the server confirmed it. Throws on network/auth when rethrow is true. */
  async function uploadReport(reportId, sum, rethrow) {
    const r = await DB.get('reports', reportId); if (!r || r.uploaded) return !!(r && r.uploaded);
    const b = await DB.getBlob(reportId);
    if (!b || !b.blob) { r.syncError = 'The PDF file is missing on this phone.'; await DB.put('reports', r); return false; }
    if (!r.attempted) { r.attempted = true; await DB.put('reports', r); }
    try {
      const d = await API.call('uploadReport', {
        report: pick(r, ['report_id', 'project_id', 'file_name', 'project_version', 'content_hash', 'generated_at']),
        dataBase64: await Util.blobToBase64(b.blob)
      }, { operationId: r.opId, timeout: C.UPLOAD_TIMEOUT_MS });
      const cur = await DB.get('reports', reportId);
      cur.uploaded = true; cur.drive_file_id = d.report.drive_file_id; cur.drive_url = d.report.drive_url; cur.syncError = '';
      await DB.put('reports', cur);
      const p = await DB.get('projects', cur.project_id);
      if (p) {
        p.latest_report_id = reportId;
        if (p.status === 'Draft' || p.status === 'Inspection Completed') { p.status = 'Report Generated'; DB.touch(p); }
        await DB.put('projects', p);
      }
      if (sum) sum.done++;
      return true;
    } catch (e) {
      if (rethrow && isFatal(e)) throw e;
      const cur = await DB.get('reports', reportId);
      if (cur) { cur.syncError = e.message; await DB.put('reports', cur); }
      if (sum) sum.failed++;
      if (!rethrow) throw e;
      return false;
    }
  }

  /* ---------- Pull: merge what the server has ---------- */
  function projFromServer(sp, lp) {
    const base = lp ? Object.assign({}, lp) : Object.assign(DB.newProject(), { isNew: false, attempted: true, restoreOpId: '', rev: 0 });
    Object.assign(base, sp);
    base.partial = false; base.stale = false; base.isNew = false; base.attempted = true;
    if (sp.deleted === 'Y') base.delState = 'synced';
    return base;
  }
  function findFromServer(sf, lf, keepOrder) {
    const base = lf ? Object.assign({}, lf) : Object.assign(DB.newFinding(sf.project_id, sf.sort_order), { isNew: false, attempted: true });
    const so = base.sort_order;
    Object.assign(base, sf);
    if (keepOrder && lf) base.sort_order = so;
    base.isNew = false; base.attempted = true; base.dirty = false; base.conflict = null; base.syncError = '';
    return base;
  }

  /** bundle = { project, findings, photos, reports } as returned by getProject / restoreProject / duplicateProject. */
  async function mergeBundle(b, opts) {
    opts = opts || {};
    const sp = b.project, pid = sp.project_id;
    const lp = await DB.get('projects', pid);
    const guarded = lp && (lp.dirty || lp.delState === 'pending' || lp.restorePending) && !opts.force;
    if (guarded) {
      SERVER_PROJECT_KEYS.forEach(function (k) { lp[k] = sp[k]; });
      if (opts.rebase) lp.version = sp.version;
      lp.partial = false; lp.stale = false;
      await DB.put('projects', lp);
    } else await DB.put('projects', projFromServer(sp, lp));
    const keepOrder = !!(lp && lp.orderDirty);

    const localF = {}; (await DB.byIndex('findings', 'project_id', pid)).forEach(function (f) { localF[f.finding_id] = f; });
    const srvF = new Set();
    for (const sf of b.findings || []) {
      srvF.add(sf.finding_id);
      const lf = localF[sf.finding_id];
      if (lf && (lf.dirty || lf.delState === 'pending') && !opts.force) {
        lf.drive_folder_id = sf.drive_folder_id; if (opts.rebase) lf.version = sf.version;
        await DB.put('findings', lf);
      } else await DB.put('findings', findFromServer(sf, lf, keepOrder));
    }
    for (const id of Object.keys(localF)) {
      const lf = localF[id];
      if (!srvF.has(id) && !lf.isNew && !lf.dirty && lf.delState !== 'pending') await DB.purgeFinding(id);
    }

    const localP = {}; (await DB.byIndex('photos', 'project_id', pid)).forEach(function (p) { localP[p.photo_id] = p; });
    const srvP = new Set();
    for (const sph of b.photos || []) {
      srvP.add(sph.photo_id);
      const lph = localP[sph.photo_id];
      if (lph && (!lph.uploaded || lph.metaDirty || lph.delState === 'pending')) continue;     // local change wins until it is sent
      const rec = Object.assign(lph ? Object.assign({}, lph) : DB.newPhoto(), sph, { uploaded: true, metaDirty: false, attempted: true, dirty: false, conflict: null, syncError: '', delState: '' });
      const blob = await DB.getBlob(sph.photo_id);
      if (blob && blob.hash && sph.content_hash && blob.hash !== sph.content_hash) await DB.del('blobs', sph.photo_id);
      await DB.put('photos', rec);
    }
    for (const id of Object.keys(localP)) {
      const lph = localP[id];
      if (!srvP.has(id) && lph.uploaded && !lph.metaDirty && lph.delState !== 'pending') await DB.purgePhoto(id);
    }

    const localR = {}; (await DB.byIndex('reports', 'project_id', pid)).forEach(function (r) { localR[r.report_id] = r; });
    const srvR = new Set();
    for (const sr of b.reports || []) {
      srvR.add(sr.report_id);
      const lr = localR[sr.report_id];
      if (lr && (!lr.uploaded || lr.delState === 'pending')) continue;
      await DB.put('reports', Object.assign(lr ? Object.assign({}, lr) : DB.newReport(), sr, { uploaded: true, attempted: true, delState: '', syncError: '' }));
    }
    for (const id of Object.keys(localR)) {
      if (!srvR.has(id) && localR[id].uploaded && localR[id].delState !== 'pending') await DB.purgeReport(id);
    }
  }

  async function pullProject(id) {
    const b = await API.call('getProject', { projectId: id });
    await mergeBundle(b);
    return b;
  }

  async function pullList(sum, scanResult) {
    const d = await API.call('listProjects', {});
    const locals = {}; (await DB.all('projects')).forEach(function (p) { locals[p.project_id] = p; });
    const findings = await DB.all('findings'), photos = await DB.all('photos');
    const count = function (arr, pid, extra) { return arr.filter(function (x) { return x.project_id === pid && x.deleted !== 'Y' && x.delState !== 'pending' && (!extra || extra(x)); }).length; };
    const seen = new Set();
    for (const sp of d.projects) {
      seen.add(sp.project_id);
      const lp = locals[sp.project_id];
      if (!lp) {
        const stub = Object.assign(DB.newProject(), { general_notes: '', overall_condition: '', executive_summary: '', overall_recommendations: '' }, sp,
          { partial: true, isNew: false, attempted: true, dirty: false, deleted: '', delState: '' });
        await DB.put('projects', stub); continue;
      }
      if (lp.deleted === 'Y' || lp.delState || lp.dirty || lp.partial || lp.isNew) { lp.finding_count = sp.finding_count; lp.photo_count = sp.photo_count; if (!lp.dirty) await DB.put('projects', lp); continue; }
      const busy = scanResult.pendingProjects.has(lp.project_id);
      const stale = sp.version > lp.version || sp.latest_report_id !== lp.latest_report_id ||
        (!busy && (sp.finding_count !== count(findings, lp.project_id) || sp.photo_count !== count(photos, lp.project_id)));
      if (stale) { lp.stale = true; await DB.put('projects', lp); }
    }
    for (const id of Object.keys(locals)) {
      const lp = locals[id];
      if (!seen.has(id) && !lp.isNew && !lp.dirty && !lp.delState && !lp.partial && lp.deleted !== 'Y') { lp.deleted = 'Y'; lp.delState = 'synced'; await DB.put('projects', lp); }
    }
  }

  async function pullStale(sum) {
    let n = 0;
    for (const p of await DB.all('projects')) {
      if (n >= 25) break;
      if ((p.partial || p.stale) && p.deleted !== 'Y' && !p.delState && !p.isNew) {
        n++;
        try { await pullProject(p.project_id); }
        catch (e) { if (isFatal(e)) throw e; if (e.code !== 'NOT_FOUND') sum.failed++; }
      }
    }
  }

  /** Adds server-deleted projects to the local list so they can be restored. */
  async function pullDeleted() {
    const d = await API.call('listProjects', { deleted: true });
    const locals = {}; (await DB.all('projects')).forEach(function (p) { locals[p.project_id] = p; });
    for (const sp of d.projects) {
      const lp = locals[sp.project_id];
      if (!lp) await DB.put('projects', Object.assign(DB.newProject(), sp, { partial: true, isNew: false, attempted: true, deleted: 'Y', delState: 'synced' }));
      else if (!lp.dirty && lp.deleted !== 'Y' && !lp.delState) { lp.deleted = 'Y'; lp.delState = 'synced'; await DB.put('projects', lp); }
    }
  }

  async function refreshSettings() {
    const d = await API.call('getSettings', {});
    await DB.setMeta('settings', d.settings || {});
    await DB.setMeta('logo', d.logo || null);
    if (d.enums) Object.keys(d.enums).forEach(function (k) { if (Array.isArray(d.enums[k]) && window.APP_ENUMS[k]) window.APP_ENUMS[k] = d.enums[k]; });
    return d;
  }

  /* ---------- Conflict resolution ---------- */
  async function cloneFinding(f, projectId, sort) {
    const nf = Object.assign({}, f, DB.syncDefaults(), { finding_id: Ids.finding(), project_id: projectId, sort_order: sort, version: 0, drive_folder_id: '', dirty: true, rev: 1, opId: Ids.op(), created_at: Util.nowIso(), deleted: '' });
    await DB.put('findings', nf);
    for (const ph of await DB.byIndex('photos', 'finding_id', f.finding_id)) {
      if (ph.deleted === 'Y') continue;
      const b = await DB.getBlob(ph.photo_id); if (!b || !b.blob) continue;
      const np = Object.assign({}, ph, DB.syncDefaults(), { photo_id: Ids.photo(), finding_id: nf.finding_id, project_id: projectId, uploaded: false, metaDirty: false, drive_file_id: '', drive_url: '', opId: Ids.op(), rev: 1, delState: '', deleted: '' });
      await DB.putBlob(np.photo_id, b.blob, b.hash); await DB.put('photos', np);
    }
    return nf;
  }

  /** kind: 'project' | 'finding'; choice: 'mine' | 'server' | 'copy'. Returns the ID to open (for 'copy'), else null. */
  async function resolve(kind, id, choice) {
    const store = kind === 'project' ? 'projects' : 'findings';
    const cur = await DB.get(store, id); if (!cur || !cur.conflict) return null;
    const c = cur.conflict, srv = c.server, deleted = c.kind === 'deleted';
    let result = null;
    if (choice === 'copy') {
      if (kind === 'project') {
        const np = Object.assign({}, cur, DB.syncDefaults(), { project_id: Ids.project(), project_name: (cur.project_name + ' (my copy)').slice(0, 300), version: 0, drive_folder_id: '', photos_folder_id: '', reports_folder_id: '', supporting_folder_id: '', latest_report_id: '', dirty: true, rev: 1, opId: Ids.op(), deleted: '', restorePending: false, orderDirty: true, orderOpId: Ids.op(), orderRev: 1, partial: false, stale: false, created_at: Util.nowIso() });
        await DB.put('projects', np);
        for (const f of (await DB.byIndex('findings', 'project_id', id)).filter(function (x) { return x.deleted !== 'Y'; })) await cloneFinding(f, np.project_id, f.sort_order);
        result = np.project_id;
      } else {
        const sibs = (await DB.byIndex('findings', 'project_id', cur.project_id)).filter(function (x) { return x.deleted !== 'Y'; });
        const nf = await cloneFinding(cur, cur.project_id, sibs.length + 1);
        const pr = await DB.get('projects', cur.project_id); if (pr) { pr.orderDirty = true; pr.orderOpId = Ids.op(); pr.orderRev++; await DB.put('projects', pr); }
        result = nf.finding_id;
      }
      choice = 'server';
    }
    if (choice === 'mine') {
      if (deleted) {
        if (kind === 'project') { cur.restorePending = true; cur.restoreOpId = Ids.op(); cur.delState = ''; cur.deleted = ''; }
        else return null;   // a finding deleted elsewhere cannot be kept; use copy
      } else if (srv) cur.version = srv.version;
      cur.conflict = null; DB.touch(cur);
    } else if (choice === 'server') {
      if (deleted) {
        if (kind === 'project') { cur.delState = 'synced'; cur.deleted = 'Y'; cur.dirty = false; cur.conflict = null; cur.syncError = ''; }
        else { await DB.purgeFinding(id); return result; }
      } else if (srv) {
        Object.assign(cur, srv, { dirty: false, conflict: null, syncError: '', isNew: false });
        if (kind === 'project') cur.stale = true;
      } else { cur.conflict = null; cur.dirty = false; cur.syncError = ''; }
    }
    await DB.put(store, cur);
    notify();
    return result;
  }

  /* ---------- Orchestration ---------- */
  async function doRun() {
    if (!API.isConfigured()) { setState('error', 'API_URL is not set in config.js.'); return { ok: false, reason: 'config' }; }
    if (!navigator.onLine) { setState('offline'); return { ok: false, reason: 'offline' }; }
    if (!API.hasToken()) { setState('login'); return { ok: false, reason: 'login' }; }
    setState('syncing');
    const sum = { done: 0, failed: 0, conflicts: 0 };
    try {
      await pushProjects(sum);
      await pushFindings(sum);
      await pushOrder(sum);
      await pushPhotoUploads(sum);
      await pushPhotoEdits(sum);
      await pushReports(sum);
      const sc = await scan();
      await pullList(sum, sc);
      await pullStale(sum);
      try { await refreshSettings(); } catch (e) { if (isFatal(e)) throw e; }
      if (!sum.failed && !sum.conflicts) await DB.setMeta('lastSync', Util.nowIso());
      setState('idle');
      return Object.assign({ ok: true }, sum);
    } catch (e) {
      if (e.code === 'AUTH') setState('login');
      else if (e.code === 'NETWORK' || e.code === 'TIMEOUT') setState('offline', e.message);
      else setState('error', e.message);
      return { ok: false, reason: e.code, message: e.message, done: sum.done };
    }
  }

  function run() {
    if (running) return running;
    running = doRun().then(function (r) { running = null; emit(); return r; }, function (e) { running = null; emit(); throw e; });
    return running;
  }

  /** Waits a moment (so several quick edits become one sync), then syncs if possible. */
  function schedule() {
    emit();
    clearTimeout(timer);
    timer = setTimeout(function () { if (navigator.onLine && API.hasToken()) run(); }, 1500);
  }
  function notify() { emit(); }

  /** Clears "Failed" marks so the items are tried again (conflicts are not touched). */
  async function retryFailed() {
    for (const store of ['projects', 'findings', 'photos', 'reports']) {
      for (const e of await DB.all(store)) if (e.syncError && !e.conflict) { e.syncError = ''; e.syncErrorCode = ''; await DB.put(store, e); }
    }
    return run();
  }

  window.Sync = {
    on: on, run: run, schedule: schedule, notify: notify, scan: scan, retryFailed: retryFailed,
    getState: function () { return state; }, isRunning: function () { return !!running; },
    uploadReport: function (id) { return uploadReport(id, null, false); },
    pullProject: pullProject, pullDeleted: pullDeleted, mergeBundle: mergeBundle,
    refreshSettings: refreshSettings, resolve: resolve
  };
})();
