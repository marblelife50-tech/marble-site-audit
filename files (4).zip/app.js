/* Marble Site Audit - app.js
   All screens and buttons. Uses db.js (storage), api.js (server), photos.js, sync.js, pdf.js.
   Every piece of user text is put on screen with textContent (never innerHTML), so nothing typed
   by a user can run as code. */
(function () {
  'use strict';
  const C = window.APP_CONFIG;
  const $ = function (id) { return document.getElementById(id); };
  const S = {
    view: '', hash: '', authed: false, prevView: null, returnHash: '',
    settings: {}, logo: null,
    project: null, exists: false, pSnap: '', findings: [], photos: [], reports: [],
    finding: null, fExists: false, fSnap: '', fPhotos: [],
    replaceId: '', urls: [], lastSyncStatus: 'idle'
  };

  /* =====================================================================
     Small UI helpers
     ===================================================================== */
  function toast(msg, kind) {
    const d = document.createElement('div');
    d.className = 'toast' + (kind === 'error' ? ' toast-error' : kind === 'ok' ? ' toast-ok' : '');
    d.textContent = msg;
    $('toast-region').appendChild(d);
    setTimeout(function () { d.remove(); }, kind === 'error' ? 7000 : 4000);
  }
  function loading(on, text) { $('loading').hidden = !on; if (text) $('loading-text').textContent = text; }
  function errMsg(e) {
    if (e && e.name === 'QuotaExceededError') return 'The phone storage is full. Sync and free some space, then try again.';
    return (e && e.message) ? e.message : String(e);
  }
  function online() { return navigator.onLine; }
  function canSync() { return online() && API.hasToken(); }

  function confirmDlg(o) {
    return new Promise(function (resolve) {
      const dlg = $('dlg-confirm');
      $('confirm-title').textContent = o.title || 'Are you sure?';
      $('confirm-message').textContent = o.message || '';
      const ok = $('confirm-ok'), cancel = $('confirm-cancel');
      ok.textContent = o.okText || 'OK';
      ok.className = 'btn ' + (o.danger ? 'is-danger-confirm' : 'btn-primary');
      cancel.hidden = !!o.noCancel;
      function done(v) { dlg.removeEventListener('cancel', onCancel); ok.onclick = null; cancel.onclick = null; if (dlg.open) dlg.close(); resolve(v); }
      function onCancel(ev) { ev.preventDefault(); done(false); }
      ok.onclick = function () { done(true); };
      cancel.onclick = function () { done(false); };
      dlg.addEventListener('cancel', onCancel);
      dlg.showModal();
    });
  }

  function trackUrl(blob) { const u = URL.createObjectURL(blob); S.urls.push(u); return u; }
  function revokeUrls() { S.urls.forEach(function (u) { URL.revokeObjectURL(u); }); S.urls = []; }

  function fmtDT(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}))?/.exec(s || '');
    if (!m) return s || '';
    const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][+m[2] - 1];
    return (+m[3]) + ' ' + mon + ' ' + m[1] + (m[4] ? ', ' + m[4] + ':' + m[5] : '');
  }
  function fmtIso(iso) {
    if (!iso) return 'never';
    const d = new Date(iso);
    return isNaN(d) ? iso : d.toLocaleString('en-GB', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  function nowLocalInput() {
    const d = new Date(), p = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  function fillEnums(root) {
    (root || document).querySelectorAll('select[data-enum]').forEach(function (sel) {
      const list = APP_ENUMS[sel.getAttribute('data-enum')] || [];
      const keep = sel.value;
      sel.textContent = '';
      if (sel.hasAttribute('data-blank')) { const o = document.createElement('option'); o.value = ''; o.textContent = 'Select\u2026'; sel.appendChild(o); }
      list.forEach(function (v) { const o = document.createElement('option'); o.value = v; o.textContent = v; sel.appendChild(o); });
      if (keep) sel.value = keep;
    });
  }

  function readForm(form) {
    const out = {};
    Array.prototype.forEach.call(form.elements, function (el) {
      if (!el.name) return;
      let v = el.value;
      if (el.type !== 'file') v = String(v).trim();
      out[el.name] = v;
    });
    return out;
  }
  function fillForm(form, obj) {
    Array.prototype.forEach.call(form.elements, function (el) {
      if (!el.name) return;
      const v = obj[el.name];
      el.value = (v === null || v === undefined) ? '' : v;
    });
    updateConditionals(form);
  }
  function updateConditionals(form) {
    form.querySelectorAll('[data-show-when]').forEach(function (box) {
      const p = box.getAttribute('data-show-when').split('=');
      const el = form.elements[p[0]];
      box.hidden = !el || el.value !== p[1];
    });
  }
  function clearErrors(form) {
    form.querySelectorAll('.field-error').forEach(function (n) { n.remove(); });
    form.querySelectorAll('[aria-invalid]').forEach(function (n) { n.removeAttribute('aria-invalid'); });
  }
  function showErrors(form, errors) {
    clearErrors(form);
    let first = null;
    Object.keys(errors).forEach(function (k) {
      const el = form.elements[k]; if (!el) return;
      el.setAttribute('aria-invalid', 'true');
      const p = document.createElement('p'); p.className = 'field-error'; p.setAttribute('role', 'alert'); p.textContent = errors[k];
      el.parentNode.appendChild(p);
      if (!first) first = el;
    });
    if (first) { first.scrollIntoView({ block: 'center', behavior: 'smooth' }); first.focus(); }
  }
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  function validateProject(v) {
    const e = {};
    APP_REQUIRED.project.forEach(function (k) { if (!v[k]) e[k] = 'Required.'; });
    if (v.contact_email && !EMAIL_RE.test(v.contact_email)) e.contact_email = 'Not a valid email address.';
    return e;
  }
  function validateFinding(v) {
    const e = {};
    APP_REQUIRED.finding.forEach(function (k) { if (!v[k]) e[k] = 'Required.'; });
    if (v.estimated_area_sqm !== '' && (isNaN(Number(v.estimated_area_sqm)) || Number(v.estimated_area_sqm) < 0)) e.estimated_area_sqm = 'Enter a number of 0 or more.';
    return e;
  }

  function setBanner(el, kind, text, btnLabel, fn) {
    el.textContent = '';
    if (!text) { el.hidden = true; return; }
    el.className = 'banner banner-' + kind;
    const s = document.createElement('span'); s.textContent = text; el.appendChild(s);
    if (btnLabel) { const b = document.createElement('button'); b.type = 'button'; b.className = 'btn btn-small'; b.textContent = btnLabel; b.onclick = fn; el.appendChild(b); }
    el.hidden = false;
  }

  function afterWrite() { Sync.schedule(); updateChips(); }

  /* =====================================================================
     Router
     ===================================================================== */
  function parse(h) { const p = String(h || '').replace(/^#\/?/, '').split('/'); return { name: p[0] || 'home', a: p[1], b: p[2] }; }
  function go(hash) { if (location.hash === hash) render(hash); else location.hash = hash; }
  function replaceRoute(hash) { history.replaceState(null, '', hash); S.hash = hash; }

  function isDirty() {
    if (S.view === 'project' && S.project && !S.project.deleted) return JSON.stringify(readForm($('form-project'))) !== S.pSnap;
    if (S.view === 'finding' && S.finding) return JSON.stringify(readForm($('form-finding'))) !== S.fSnap;
    return false;
  }
  async function guard() {
    if (!isDirty()) return true;
    return confirmDlg({ title: 'Discard changes?', message: 'You have changes that are not saved. Leave without saving?', okText: 'Discard', danger: true });
  }
  async function onHashChange() {
    const target = location.hash || '#/home';
    if (target === S.hash || !S.authed) return;
    if (isDirty()) {
      history.pushState(null, '', S.hash || '#/home');            // stay where we were while we ask
      if (!(await guard())) return;
      S.pSnap = S.fSnap = '';
      history.replaceState(null, '', target);
    }
    await render(target);
  }

  function showView(name, title, back) {
    S.view = name;
    document.querySelectorAll('[data-view]').forEach(function (v) { v.hidden = v.getAttribute('data-view') !== name; });
    const login = name === 'login';
    $('topbar').hidden = login; $('bottom-nav').hidden = login;
    $('screen-title').textContent = title || 'Site Audit';
    $('btn-back').hidden = !back;
    $('nav-home').setAttribute('aria-current', name === 'dashboard' ? 'page' : 'false');
    $('nav-settings').setAttribute('aria-current', name === 'settings' ? 'page' : 'false');
    window.scrollTo(0, 0);
    if (!login) S.prevView = { name: name, title: title, back: back };
  }

  async function render(hash) {
    S.hash = hash; revokeUrls();
    const r = parse(hash);
    try {
      if (r.name === 'project') await openProject(r.a || 'new');
      else if (r.name === 'finding') await openFinding(r.a, r.b);
      else if (r.name === 'settings') await renderSettings();
      else await renderDashboard();
    } catch (e) { console.error(e); toast('Something went wrong: ' + errMsg(e), 'error'); }
    updateChips();
  }

  /* =====================================================================
     Login
     ===================================================================== */
  async function showLogin(message) {
    showView('login');
    $('login-code').value = '';
    const err = $('login-error');
    err.hidden = !message; err.textContent = message || '';
    $('btn-offline-continue').hidden = !(await DB.getMeta('everLoggedIn', false));
    $('login-code').focus();
  }
  async function doLogin() {
    const code = $('login-code').value;
    const err = $('login-error'); err.hidden = true;
    if (!code) { err.textContent = 'Enter your access code.'; err.hidden = false; return; }
    if (!API.isConfigured()) { err.textContent = 'The app is not connected yet: API_URL is missing in config.js.'; err.hidden = false; return; }
    if (!online()) { err.textContent = 'Logging in needs internet.'; err.hidden = false; return; }
    loading(true, 'Logging in\u2026');
    try { await API.login(code); }
    catch (e) { loading(false); err.textContent = errMsg(e); err.hidden = false; return; }
    loading(false);
    $('login-code').value = '';
    await enterApp(true);
  }
  async function enterApp(fromLogin) {
    S.authed = true;
    S.settings = await DB.getMeta('settings', {}); S.logo = await DB.getMeta('logo', null);
    if (fromLogin && S.returnHash && S.prevView && S.prevView.name !== 'login') {
      showView(S.prevView.name, S.prevView.title, S.prevView.back); S.returnHash = '';
    } else {
      const h = location.hash || '#/home';
      S.hash = '';
      await render(h);
    }
    if (canSync()) Sync.run().then(function () { return loadSettingsCache(); });
  }
  async function loadSettingsCache() {
    S.settings = await DB.getMeta('settings', {}); S.logo = await DB.getMeta('logo', null); fillEnums(document);
  }
  function requireLogin(msg) { S.returnHash = S.hash || '#/home'; showLogin(msg || 'Please log in to sync.'); }

  /* =====================================================================
     Chips + sync UI
     ===================================================================== */
  async function updateChips() {
    const net = $('chip-net');
    net.textContent = online() ? 'Online' : 'Offline';
    net.className = 'chip ' + (online() ? 'chip-online' : 'chip-offline');
    let sc; try { sc = await Sync.scan(); } catch (e) { return; }
    const chip = $('chip-sync'), st = Sync.getState();
    let text = 'Synced', cls = 'chip-synced';
    if (Sync.isRunning() || st.status === 'syncing') { text = 'Syncing\u2026'; cls = 'chip-syncing'; }
    else if (sc.conflicts) { text = 'Conflict (' + sc.conflicts + ')'; cls = 'chip-error'; }
    else if (sc.failed) { text = 'Sync error (' + sc.failed + ')'; cls = 'chip-error'; }
    else if (st.status === 'login' && sc.pending) { text = 'Login needed (' + sc.pending + ')'; cls = 'chip-error'; }
    else if (sc.pending) { text = 'Pending sync (' + sc.pending + ')'; cls = 'chip-pending'; }
    chip.textContent = text; chip.className = 'chip ' + cls;
    $('btn-sync').disabled = Sync.isRunning();
  }

  async function doSync(manual) {
    if (!online()) { if (manual) toast('You are offline. Your work is saved on this phone and will sync later.'); return; }
    if (!API.hasToken()) { requireLogin('Please log in to sync.'); return; }
    const r = await Sync.run();
    await loadSettingsCache(); await updateChips();
    if (!manual) return;
    if (!r.ok) toast(r.reason === 'login' ? 'Please log in again.' : 'Sync did not finish: ' + (r.message || r.reason), 'error');
    else if (r.conflicts) toast(r.conflicts + ' item(s) need your decision. Tap the sync chip.', 'error');
    else if (r.failed) toast(r.failed + ' item(s) failed. Tap the sync chip for details.', 'error');
    else toast(r.done ? 'Sync complete. ' + r.done + ' change(s) sent.' : 'Everything is already up to date.', 'ok');
  }

  async function openSyncDialog() {
    const sc = await Sync.scan(), list = $('sync-queue-list');
    list.textContent = '';
    $('sync-summary').textContent = sc.items.length
      ? sc.pending + ' waiting, ' + sc.failed + ' failed, ' + sc.conflicts + ' conflict(s). ' + (online() ? '' : 'You are offline.')
      : 'Everything is saved on the server.';
    $('sync-last').textContent = fmtIso(await DB.getMeta('lastSync', ''));
    sc.items.forEach(function (it) {
      const li = $('tpl-sync-item').content.firstElementChild.cloneNode(true);
      li.querySelector('[data-f="label"]').textContent = it.label;
      const b = li.querySelector('[data-f="state"]'); b.textContent = it.state;
      b.className = 'badge ' + (it.state === 'Pending' ? 'badge-pending' : 'badge-error');
      const er = li.querySelector('[data-f="error"]');
      if (it.error) { er.textContent = it.error; er.hidden = false; }
      if (it.state === 'Conflict' && (it.kind === 'project' || it.kind === 'finding')) {
        li.style.cursor = 'pointer'; li.setAttribute('role', 'button'); li.tabIndex = 0;
        const open = function () { $('dlg-sync').close(); openConflict(it.kind, it.id); };
        li.onclick = open; li.onkeydown = function (e) { if (e.key === 'Enter') open(); };
        er.textContent = 'Tap to decide'; er.hidden = false;
      }
      list.appendChild(li);
    });
    $('sync-retry-failed').hidden = !sc.failed;
    $('dlg-sync').showModal();
  }

  async function openConflict(kind, id) {
    const rec = await DB.get(kind === 'project' ? 'projects' : 'findings', id);
    if (!rec || !rec.conflict) { toast('Nothing to resolve.'); return; }
    const c = rec.conflict, deleted = c.kind === 'deleted', what = kind === 'project' ? 'project' : 'finding';
    $('conflict-message').textContent = deleted
      ? 'This ' + what + ' was deleted on another device, but you have changes on this phone.'
      : 'This ' + what + ' was changed on another device after you last synced, and you also changed it here.';
    let detail = '';
    if (!deleted && c.server) {
      const keys = kind === 'project' ? DB.PROJECT_FIELDS : DB.FINDING_FIELDS;
      const diff = keys.filter(function (k) { return String(rec[k] == null ? '' : rec[k]) !== String(c.server[k] == null ? '' : c.server[k]); });
      detail = diff.length ? 'Different fields: ' + diff.map(function (k) { return k.replace(/_/g, ' '); }).join(', ') + '.' : '';
    }
    $('conflict-detail').textContent = detail;
    $('conflict-keep-mine').textContent = deleted && kind === 'project' ? 'Restore it and keep my version' : 'Keep my version';
    $('conflict-keep-mine').hidden = deleted && kind === 'finding';
    $('conflict-keep-server').textContent = deleted ? 'Accept the deletion' : 'Use the server\u2019s version';
    const dlg = $('dlg-conflict');
    async function pickOne(choice) {
      dlg.close();
      try {
        const newId = await Sync.resolve(kind, id, choice);
        toast(choice === 'copy' ? 'Saved your version as a new copy.' : 'Done.', 'ok');
        afterWrite();
        if (newId && choice === 'copy') go(kind === 'project' ? '#/project/' + newId : '#/finding/' + newId);
        else refreshCurrent();
      } catch (e) { toast(errMsg(e), 'error'); }
    }
    $('conflict-keep-mine').onclick = function () { pickOne('mine'); };
    $('conflict-keep-server').onclick = function () { pickOne('server'); };
    $('conflict-save-copy').onclick = function () { pickOne('copy'); };
    $('conflict-cancel').onclick = function () { dlg.close(); };
    dlg.showModal();
  }

  async function refreshCurrent() {
    if (S.view === 'dashboard') return renderDashboard();
    if (S.view === 'project' && S.project) {
      const fresh = await DB.get('projects', S.project.project_id);
      if (!fresh) return go('#/home');
      if (!isDirty()) { S.project = fresh; await renderProject(); }
      else { await loadChildren(); renderFindings(); renderReports(); }
    } else if (S.view === 'finding' && S.finding && S.fExists) {
      const ae = document.activeElement;
      if (ae && $('photo-grid').contains(ae)) return;          // do not disturb a caption being typed
      await renderPhotos(); renderFindingBanner();
    }
  }

  /* =====================================================================
     Dashboard
     ===================================================================== */
  async function renderDashboard() {
    showView('dashboard', 'Marble Site Audit', false);
    S.project = null; S.finding = null;
    const all = await DB.all('projects'), findings = await DB.all('findings'), photos = await DB.all('photos'), reports = await DB.all('reports');
    const sc = await Sync.scan();
    const attention = new Set(sc.items.filter(function (i) { return i.state !== 'Pending'; }).map(function (i) { return i.projectId; }));
    const liveP = all.filter(function (p) { return p.deleted !== 'Y'; });
    const withReport = new Set(reports.filter(function (r) { return r.deleted !== 'Y'; }).map(function (r) { return r.project_id; }));
    $('stat-total').textContent = liveP.length;
    $('stat-draft').textContent = liveP.filter(function (p) { return p.status === 'Draft'; }).length;
    $('stat-completed').textContent = liveP.filter(function (p) { return p.status === 'Inspection Completed'; }).length;
    $('stat-reports').textContent = liveP.filter(function (p) { return withReport.has(p.project_id) || p.latest_report_id; }).length;

    const dl = $('client-list'); dl.textContent = '';
    Array.from(new Set(liveP.map(function (p) { return p.client_name; }).filter(Boolean))).sort().forEach(function (c) { const o = document.createElement('option'); o.value = c; dl.appendChild(o); });

    const q = $('search-input').value.trim().toLowerCase(), fs = $('filter-status').value;
    const fc = $('filter-client').value.trim().toLowerCase(), fl = $('filter-location').value.trim().toLowerCase();
    const d1 = $('filter-date-from').value, d2 = $('filter-date-to').value;
    const rows = all.filter(function (p) {
      if (fs === '__deleted') { if (p.deleted !== 'Y') return false; } else if (p.deleted === 'Y') return false;
      if (fs === '__pending') { if (!sc.pendingProjects.has(p.project_id)) return false; }
      else if (fs && fs !== '__deleted' && p.status !== fs) return false;
      if (q && [p.project_name, p.client_name, p.building_name, p.site_location, p.project_id, p.job_reference].join(' ').toLowerCase().indexOf(q) === -1) return false;
      if (fc && String(p.client_name).toLowerCase().indexOf(fc) === -1) return false;
      if (fl && String(p.site_location).toLowerCase().indexOf(fl) === -1) return false;
      const d = String(p.inspection_datetime || '').slice(0, 10);
      if (d1 && (!d || d < d1)) return false;
      if (d2 && (!d || d > d2)) return false;
      return true;
    }).sort(function (a, b) { return String(b.updated_at).localeCompare(String(a.updated_at)); });

    const ul = $('project-list'); ul.textContent = '';
    rows.forEach(function (p) {
      const li = $('tpl-project-card').content.firstElementChild.cloneNode(true);
      li.querySelector('[data-f="project_name"]').textContent = p.project_name || '(no name)';
      li.querySelector('[data-f="client_name"]').textContent = p.client_name || '';
      li.querySelector('[data-f="site_location"]').textContent = p.site_location || '';
      const st = li.querySelector('[data-f="status"]'), label = p.deleted === 'Y' ? 'Deleted' : p.status;
      st.textContent = label; st.setAttribute('data-value', label);
      const fc2 = p.partial ? (p.finding_count || 0) : findings.filter(function (f) { return f.project_id === p.project_id && f.deleted !== 'Y'; }).length;
      const pc2 = p.partial ? (p.photo_count || 0) : photos.filter(function (x) { return x.project_id === p.project_id && x.deleted !== 'Y'; }).length;
      li.querySelector('[data-f="counts"]').textContent = fc2 + ' finding(s) \u00b7 ' + pc2 + ' photo(s)';
      const pend = li.querySelector('[data-f="pending"]');
      if (attention.has(p.project_id)) { pend.textContent = 'Needs attention'; pend.className = 'badge badge-error'; pend.hidden = false; }
      else if (sc.pendingProjects.has(p.project_id)) pend.hidden = false;
      li.querySelector('.card-main').onclick = function () { go('#/project/' + p.project_id); };
      ul.appendChild(li);
    });
    $('project-list-empty').hidden = rows.length > 0;
  }

  /* =====================================================================
     Project screen
     ===================================================================== */
  async function loadChildren() {
    const pid = S.project.project_id;
    S.findings = (await DB.byIndex('findings', 'project_id', pid)).filter(function (f) { return f.deleted !== 'Y'; }).sort(Util.bySort);
    S.photos = (await DB.byIndex('photos', 'project_id', pid)).filter(function (p) { return p.deleted !== 'Y'; });
    S.reports = (await DB.byIndex('reports', 'project_id', pid)).filter(function (r) { return r.deleted !== 'Y'; })
      .sort(function (a, b) { return String(b.generated_at).localeCompare(String(a.generated_at)); });
  }

  async function openProject(id) {
    let rec = id === 'new' ? null : await DB.get('projects', id);
    if (id !== 'new' && !rec) { toast('Project not found on this phone.', 'error'); return go('#/home'); }
    if (rec && rec.partial) {
      if (!canSync()) { toast('Open this project once while online so it is saved on this phone.', 'error'); return go('#/home'); }
      loading(true, 'Loading project\u2026');
      try { await Sync.pullProject(id); rec = await DB.get('projects', id); }
      catch (e) { loading(false); toast('Could not load the project: ' + errMsg(e), 'error'); return go('#/home'); }
      loading(false);
    }
    S.exists = !!rec;
    S.project = rec || DB.newProject({ inspection_datetime: nowLocalInput(), inspector_name: S.settings.default_inspector || '' });
    await loadChildren();
    await renderProject();
    if (rec && !rec.isNew && canSync()) {
      Sync.pullProject(id).then(async function () {
        if (S.view === 'project' && S.project && S.project.project_id === id) await refreshCurrent();
      }).catch(function () { /* offline or not on server: ignore */ });
    }
  }

  async function renderProject() {
    const p = S.project, ro = p.deleted === 'Y';
    showView('project', p.project_name || 'New project', true);
    const form = $('form-project');
    clearErrors(form); fillForm(form, p);
    Array.prototype.forEach.call(form.elements, function (el) { el.disabled = ro; });
    S.pSnap = JSON.stringify(readForm(form));
    $('project-id-label').textContent = p.project_id;
    $('project-version-label').textContent = S.exists && p.version ? String(p.version) : 'new';
    $('btn-save-project').hidden = ro; $('btn-generate-pdf').hidden = ro; $('btn-add-finding').hidden = ro;
    $('btn-duplicate-project').hidden = ro || !S.exists; $('btn-delete-project').hidden = ro || !S.exists;
    $('btn-restore-project').hidden = !ro;
    $('findings-section').hidden = false;
    const b = $('project-banner');
    if (ro) setBanner(b, 'warn', 'This project is deleted. Restore it to edit.');
    else if (p.conflict) setBanner(b, 'error', 'Changed on another device. Choose which version to keep.', 'Decide', function () { openConflict('project', p.project_id); });
    else if (p.syncError) setBanner(b, 'error', 'Sync problem: ' + p.syncError);
    else if (p.dirty || p.isNew) setBanner(b, 'warn', S.exists ? 'Saved on this phone. Waiting to sync.' : 'Not saved yet.');
    else setBanner(b, 'ok', '');
    renderFindings(); renderReports();
  }

  function renderFindings() {
    const ul = $('finding-list'); ul.textContent = '';
    const ro = S.project.deleted === 'Y';
    S.findings.forEach(function (f, i) {
      const li = $('tpl-finding-row').content.firstElementChild.cloneNode(true);
      li.querySelector('[data-f="num"]').textContent = i + 1;
      li.querySelector('[data-f="area_location"]').textContent = f.area_location;
      const defect = f.defect_category === 'Other' && f.defect_category_other ? f.defect_category_other : f.defect_category;
      li.querySelector('[data-f="defect"]').textContent = [defect, f.material_type].filter(Boolean).join(' \u00b7 ') || 'No defect selected';
      const pr = li.querySelector('[data-f="priority"]'); pr.textContent = f.priority; pr.setAttribute('data-value', f.priority);
      const n = S.photos.filter(function (x) { return x.finding_id === f.finding_id; }).length;
      li.querySelector('[data-f="counts"]').textContent = n + ' photo(s)';
      const pend = li.querySelector('[data-f="pending"]');
      if (f.conflict || f.syncError) { pend.textContent = 'Needs attention'; pend.className = 'badge badge-error'; pend.hidden = false; }
      else if (f.dirty || f.isNew) pend.hidden = false;
      li.querySelector('.card-main').onclick = function () { go('#/finding/' + f.finding_id); };
      const up = li.querySelector('.btn-up'), down = li.querySelector('.btn-down');
      up.disabled = ro || i === 0; down.disabled = ro || i === S.findings.length - 1;
      up.onclick = function () { moveFinding(f.finding_id, -1); }; down.onclick = function () { moveFinding(f.finding_id, 1); };
      ul.appendChild(li);
    });
    $('finding-empty').hidden = S.findings.length > 0;
  }

  async function moveFinding(id, dir) {
    const list = S.findings.slice(), i = list.findIndex(function (f) { return f.finding_id === id; }), j = i + dir;
    if (i < 0 || j < 0 || j >= list.length) return;
    const t = list[i]; list[i] = list[j]; list[j] = t;
    try {
      for (let k = 0; k < list.length; k++) {
        const f = await DB.get('findings', list[k].finding_id);
        if (f && f.sort_order !== k + 1) { f.sort_order = k + 1; await DB.put('findings', f); }
      }
      const p = await DB.get('projects', S.project.project_id);
      p.orderDirty = true; p.orderOpId = Ids.op(); p.orderRev = (p.orderRev || 0) + 1;
      await DB.put('projects', p); S.project = p;
      await loadChildren(); renderFindings(); afterWrite();
    } catch (e) { toast(errMsg(e), 'error'); }
  }

  function renderReports() {
    const ul = $('report-list'); ul.textContent = '';
    S.reports.forEach(function (r) {
      const li = $('tpl-report-row').content.firstElementChild.cloneNode(true);
      li.querySelector('[data-f="file_name"]').textContent = r.file_name;
      li.querySelector('[data-f="generated_at"]').textContent = 'Created ' + fmtIso(r.generated_at);
      li.querySelector('[data-f="sync"]').textContent = r.uploaded ? 'Saved to Google Drive'
        : (r.syncError ? 'Not on Drive yet: ' + r.syncError : 'Created on this phone. Waiting to upload to Drive.');
      li.querySelector('.btn-report-preview').onclick = function () { reportAction(r, 'preview'); };
      li.querySelector('.btn-report-open').onclick = function () { reportAction(r, 'drive'); };
      li.querySelector('.btn-report-download').onclick = function () { reportAction(r, 'download'); };
      ul.appendChild(li);
    });
    $('report-empty').hidden = S.reports.length > 0;
  }

  async function saveProject(silent) {
    const form = $('form-project'), v = readForm(form), errs = validateProject(v);
    if (Object.keys(errs).length) { showErrors(form, errs); toast('Please fix the highlighted fields.', 'error'); return false; }
    clearErrors(form);
    let rec = S.exists ? await DB.get('projects', S.project.project_id) : S.project;
    const changed = !S.exists || DB.PROJECT_FIELDS.some(function (k) { return String(rec[k] == null ? '' : rec[k]) !== (v[k] == null ? '' : v[k]); });
    if (!changed) { if (!silent) toast('No changes to save.'); return true; }
    DB.PROJECT_FIELDS.forEach(function (k) { rec[k] = v[k] == null ? '' : v[k]; });
    if (!rec.status) rec.status = 'Draft';
    rec.updated_at = Util.nowIso();
    DB.touch(rec);
    try { await DB.put('projects', rec); } catch (e) { toast('Could not save on this phone: ' + errMsg(e), 'error'); return false; }
    const wasNew = !S.exists;
    S.exists = true; S.project = rec; S.pSnap = JSON.stringify(readForm(form));
    if (wasNew) replaceRoute('#/project/' + rec.project_id);
    await renderProject();
    afterWrite();
    if (!silent) toast(canSync() ? 'Saved on this phone. Syncing to Google\u2026' : 'Saved on this phone. It will sync when you are online.', 'ok');
    return true;
  }

  async function deleteProject() {
    const p = S.project;
    const ok = await confirmDlg({ title: 'Delete this project?', message: '"' + (p.project_name || 'Project') + '" and its findings, photos and reports will be hidden. You can restore it later from Filters > Deleted. Files stay in Google Drive.', okText: 'Delete project', danger: true });
    if (!ok) return;
    try {
      const rec = await DB.get('projects', p.project_id);
      if (rec.isNew && !rec.attempted) await DB.purgeProject(rec.project_id);
      else { rec.deleted = 'Y'; rec.deleted_at = Util.nowIso(); rec.delState = 'pending'; rec.delOpId = Ids.op(); rec.restorePending = false; rec.syncError = ''; await DB.put('projects', rec); }
    } catch (e) { toast(errMsg(e), 'error'); return; }
    S.pSnap = ''; afterWrite(); toast('Project deleted.', 'ok'); go('#/home');
  }

  async function restoreProject() {
    const rec = await DB.get('projects', S.project.project_id);
    if (rec.delState === 'pending') { rec.delState = ''; rec.deleted = ''; rec.deleted_at = ''; }
    else { rec.deleted = ''; rec.deleted_at = ''; rec.restorePending = true; rec.restoreOpId = Ids.op(); }
    await DB.put('projects', rec); afterWrite(); toast('Project restored.', 'ok');
    S.project = rec; await loadChildren(); await renderProject();
  }

  async function duplicateProject() {
    if (isDirty()) { toast('Save your changes first.', 'error'); return; }
    const sc = await Sync.scan();
    if (S.project.isNew || sc.pendingProjects.has(S.project.project_id)) { toast('Sync this project first (tap Sync Now), then duplicate it.', 'error'); return; }
    if (!canSync()) { toast('Duplicating needs internet.', 'error'); return; }
    const ok = await confirmDlg({ title: 'Duplicate project?', message: 'A new Draft project is created with the same details and findings (photos and reports are not copied).', okText: 'Duplicate' });
    if (!ok) return;
    loading(true, 'Duplicating\u2026');
    try {
      const b = await API.call('duplicateProject', { sourceProjectId: S.project.project_id }, { operationId: Ids.op() });
      await Sync.mergeBundle(b);
      loading(false); toast('Project duplicated.', 'ok'); go('#/project/' + b.project.project_id);
    } catch (e) { loading(false); toast('Could not duplicate: ' + errMsg(e), 'error'); }
  }

  /* ----- PDF report ----- */
  async function generatePdf() {
    if (!(await saveProject(true))) return;
    const p = await DB.get('projects', S.project.project_id);
    await loadChildren();
    if (!S.findings.length) { toast('Add at least one finding before generating a report.', 'error'); return; }
    loading(true, 'Preparing photographs\u2026');
    const photos = []; let missing = 0;
    for (const ph of S.photos) {
      const blob = await Photos.ensureBlob(ph);
      if (!blob) { missing++; continue; }
      photos.push(Object.assign({}, ph, { blob: blob }));
    }
    if (missing) {
      loading(false);
      toast(missing + ' photo(s) are not on this phone and could not be downloaded. Connect to the internet and try again.', 'error');
      return;
    }
    let built;
    try { loading(true, 'Building the PDF\u2026'); built = await PDF.build({ project: p, findings: S.findings, photos: photos, settings: S.settings, logo: S.logo }); }
    catch (e) { loading(false); console.error(e); toast('The PDF could not be created: ' + errMsg(e) + ' Your project data is safe.', 'error'); return; }

    let rep;
    try {
      const hash = await Util.sha256Hex(built.blob);
      rep = DB.newReport({ project_id: p.project_id, file_name: built.fileName, project_version: p.version || 0, content_hash: hash,
        size_bytes: built.blob.size, generated_at: Util.nowIso(), generated_by_device: API.getDeviceId(), opId: Ids.op() });
      await DB.putBlob(rep.report_id, built.blob, hash);
      await DB.put('reports', rep);
    } catch (e) { loading(false); toast('Could not store the PDF on this phone: ' + errMsg(e), 'error'); return; }

    let msg = 'PDF created on this phone. It will be saved to Google Drive when you are online and synced.', kind = '';
    if (canSync()) {
      loading(true, 'Saving the report to Google Drive\u2026');
      await Sync.run();
      const after = await DB.get('reports', rep.report_id);
      if (after && after.uploaded) { msg = 'Report saved to Google Drive.'; kind = 'ok'; }
      else { msg = 'PDF created on this phone, but it is NOT on Drive yet' + (after && after.syncError ? ': ' + after.syncError : '.'); kind = 'error'; }
    }
    loading(false);
    S.project = await DB.get('projects', p.project_id);
    await loadChildren(); await renderProject(); updateChips();
    toast(msg, kind);
  }

  async function reportBlob(r) {
    const b = await DB.getBlob(r.report_id);
    if (b && b.blob) return b.blob;
    if (!canSync()) throw new Error('This PDF is not stored on this phone. Connect to the internet to download it.');
    const d = await API.call('getReportData', { reportId: r.report_id });
    const blob = Util.base64ToBlob(d.dataBase64, 'application/pdf');
    await DB.putBlob(r.report_id, blob, r.content_hash);
    return blob;
  }
  async function reportAction(r, mode) {
    if (mode === 'drive') {
      if (r.drive_url) window.open(r.drive_url, '_blank', 'noopener'); else toast('This report is not on Google Drive yet.', 'error');
      return;
    }
    loading(true, 'Opening PDF\u2026');
    let blob;
    try { blob = await reportBlob(r); } catch (e) { loading(false); toast(errMsg(e), 'error'); return; }
    loading(false);
    const url = URL.createObjectURL(blob);
    setTimeout(function () { URL.revokeObjectURL(url); }, 10 * 60 * 1000);
    if (mode === 'download') { downloadUrl(url, r.file_name); return; }
    openPdfDialog(url, r.file_name);
  }
  function downloadUrl(url, name) { const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); }
  function openPdfDialog(url, name) {
    const dlg = $('dlg-pdf');
    $('pdf-title').textContent = name;
    if (!$('pdf-hint')) { const h = document.createElement('p'); h.id = 'pdf-hint'; h.className = 'hint'; h.textContent = 'If the preview stays blank (some Android phones cannot show PDFs here), use Open or Download.'; $('pdf-frame').after(h); }
    $('pdf-frame').src = url;
    $('pdf-open').onclick = function () { window.open(url, '_blank'); };
    $('pdf-download').onclick = function () { downloadUrl(url, name); };
    dlg.showModal();
  }

  /* =====================================================================
     Finding screen + photos
     ===================================================================== */
  async function openFinding(a, b) {
    let rec, exists;
    if (a === 'new') {
      const proj = await DB.get('projects', b);
      if (!proj || proj.deleted === 'Y') { toast('Project not found.', 'error'); return go('#/home'); }
      const sibs = (await DB.byIndex('findings', 'project_id', b)).filter(function (f) { return f.deleted !== 'Y'; });
      rec = DB.newFinding(b, sibs.reduce(function (m, f) { return Math.max(m, f.sort_order || 0); }, 0) + 1);
      exists = false;
    } else {
      rec = await DB.get('findings', a); exists = true;
      if (!rec || rec.deleted === 'Y') { toast('Finding not found.', 'error'); return go('#/home'); }
    }
    S.finding = rec; S.fExists = exists;
    showView('finding', exists ? (rec.area_location || 'Finding') : 'New finding', true);
    const form = $('form-finding');
    clearErrors(form); fillForm(form, rec);
    S.fSnap = JSON.stringify(readForm(form));
    $('finding-id-label').textContent = rec.finding_id;
    $('btn-delete-finding').hidden = !exists;
    renderFindingBanner();
    await renderPhotos();
  }
  function renderFindingBanner() {
    const f = S.finding, b = $('finding-banner');
    if (f.conflict) setBanner(b, 'error', 'Changed on another device. Choose which version to keep.', 'Decide', function () { openConflict('finding', f.finding_id); });
    else if (f.syncError) setBanner(b, 'error', 'Sync problem: ' + f.syncError);
    else if (S.fExists && (f.dirty || f.isNew)) setBanner(b, 'warn', 'Saved on this phone. Waiting to sync.');
    else setBanner(b, 'ok', '');
  }

  async function saveFinding(opts) {
    opts = opts || {};
    const form = $('form-finding'), v = readForm(form), errs = validateFinding(v);
    if (Object.keys(errs).length) { showErrors(form, errs); toast('Please fix the highlighted fields.', 'error'); return false; }
    clearErrors(form);
    const rec = S.fExists ? await DB.get('findings', S.finding.finding_id) : S.finding;
    const num = v.estimated_area_sqm === '' ? null : Math.round(Number(v.estimated_area_sqm) * 100) / 100;
    const changed = !S.fExists || DB.FINDING_FIELDS.some(function (k) {
      const nv = k === 'estimated_area_sqm' ? num : v[k];
      return String(rec[k] == null ? '' : rec[k]) !== String(nv == null ? '' : nv);
    });
    if (changed) {
      DB.FINDING_FIELDS.forEach(function (k) { rec[k] = k === 'estimated_area_sqm' ? num : (v[k] == null ? '' : v[k]); });
      if (!rec.priority) rec.priority = 'Medium';
      rec.updated_at = Util.nowIso();
      DB.touch(rec);
      try { await DB.put('findings', rec); } catch (e) { toast('Could not save on this phone: ' + errMsg(e), 'error'); return false; }
    }
    const wasNew = !S.fExists;
    S.fExists = true; S.finding = rec; S.fSnap = JSON.stringify(readForm(form));
    $('btn-delete-finding').hidden = false; $('finding-id-label').textContent = rec.finding_id;
    if (wasNew) replaceRoute('#/finding/' + rec.finding_id);
    if (changed) afterWrite();
    if (!opts.stay) { toast('Finding saved on this phone.', 'ok'); go('#/project/' + rec.project_id); }
    return true;
  }

  async function deleteFinding() {
    const f = S.finding;
    const ok = await confirmDlg({ title: 'Delete this finding?', message: 'The finding "' + (f.area_location || '') + '" and its photos will be removed from the report.', okText: 'Delete finding', danger: true });
    if (!ok) return;
    try {
      const rec = await DB.get('findings', f.finding_id);
      if (rec.isNew && !rec.attempted) await DB.purgeFinding(rec.finding_id);
      else {
        rec.deleted = 'Y'; rec.deleted_at = Util.nowIso(); rec.delState = 'pending'; rec.delOpId = Ids.op(); rec.dirty = false; rec.syncError = '';
        await DB.put('findings', rec);
        for (const ph of await DB.byIndex('photos', 'finding_id', rec.finding_id)) { ph.deleted = 'Y'; ph.delState = ''; await DB.put('photos', ph); }
      }
    } catch (e) { toast(errMsg(e), 'error'); return; }
    S.fSnap = ''; afterWrite(); toast('Finding deleted.', 'ok'); go('#/project/' + f.project_id);
  }

  async function renderPhotos() {
    const fid = S.finding.finding_id;
    S.fPhotos = S.fExists ? (await DB.byIndex('photos', 'finding_id', fid)).filter(function (p) { return p.deleted !== 'Y'; }).sort(Util.bySort) : [];
    const grid = $('photo-grid'); grid.textContent = '';
    S.fPhotos.forEach(function (ph) {
      const card = $('tpl-photo-card').content.firstElementChild.cloneNode(true);
      fillEnums(card);
      const img = card.querySelector('.photo-img');
      const st = card.querySelector('[data-f="stage"]'); st.textContent = ph.stage; st.setAttribute('data-value', ph.stage);
      const cap = card.querySelector('.photo-caption'); cap.value = ph.caption || '';
      const sel = card.querySelector('.photo-stage'); sel.value = ph.stage;
      card.querySelector('[data-f="sync"]').textContent = ph.syncError ? 'Upload failed: ' + ph.syncError : (ph.uploaded && !ph.metaDirty ? 'Saved to Google Drive' : 'Waiting to upload');
      DB.getBlob(ph.photo_id).then(function (b) {
        if (b && b.blob) { img.src = trackUrl(b.blob); img.alt = ph.caption || ph.stage + ' photo'; }
        else if (canSync() && ph.uploaded) Photos.ensureBlob(ph).then(function (blob) { if (blob) { img.src = trackUrl(blob); img.alt = ph.caption || ph.stage + ' photo'; } });
        else img.alt = 'Photo not stored on this phone';
      });
      cap.onchange = function () { updatePhotoMeta(ph.photo_id, { caption: cap.value.trim() }); };
      sel.onchange = function () { updatePhotoMeta(ph.photo_id, { stage: sel.value }); st.textContent = sel.value; st.setAttribute('data-value', sel.value); };
      card.querySelector('.btn-remove').onclick = function () { removePhoto(ph.photo_id); };
      card.querySelector('.btn-replace').onclick = function () { S.replaceId = ph.photo_id; $('input-photo-replace').value = ''; $('input-photo-replace').click(); };
      grid.appendChild(card);
    });
    $('photo-empty').hidden = S.fPhotos.length > 0;
  }

  async function updatePhotoMeta(id, change) {
    try {
      const ph = await DB.get('photos', id); if (!ph) return;
      Object.assign(ph, change);
      if (ph.uploaded) { ph.metaDirty = true; DB.touch(ph, 'metaOpId'); } else DB.touch(ph, 'opId');
      ph.updated_at = Util.nowIso();
      await DB.put('photos', ph); afterWrite();
    } catch (e) { toast(errMsg(e), 'error'); }
  }

  async function removePhoto(id) {
    const ok = await confirmDlg({ title: 'Remove this photo?', message: 'The photo will be removed from this finding and from the report.', okText: 'Remove', danger: true });
    if (!ok) return;
    try {
      const ph = await DB.get('photos', id);
      if (!ph.attempted && !ph.uploaded) await DB.purgePhoto(id);
      else { ph.deleted = 'Y'; ph.deleted_at = Util.nowIso(); ph.delState = 'pending'; ph.delOpId = Ids.op(); ph.syncError = ''; await DB.put('photos', ph); }
      await renderPhotos(); afterWrite();
    } catch (e) { toast(errMsg(e), 'error'); }
  }

  async function ensureFindingSaved() {
    if (S.fExists) return true;
    toast('Saving the finding first so photos can be attached\u2026');
    return saveFinding({ stay: true });
  }

  function promptPhoto(processed, i, total) {
    return new Promise(function (resolve) {
      const dlg = $('dlg-photo');
      const url = URL.createObjectURL(processed.blob);
      $('photo-dlg-counter').textContent = total > 1 ? 'Photo ' + i + ' of ' + total : 'New photo';
      $('photo-preview-img').src = url;
      $('photo-dlg-stage').value = $('photo-default-stage').value;
      $('photo-dlg-caption').value = '';
      $('photo-dlg-add-rest').hidden = (total - i) < 1;
      function done(action) {
        const out = { action: action, stage: $('photo-dlg-stage').value, caption: $('photo-dlg-caption').value.trim() };
        dlg.removeEventListener('cancel', onCancel); URL.revokeObjectURL(url); if (dlg.open) dlg.close(); resolve(out);
      }
      function onCancel(e) { e.preventDefault(); done('discard'); }
      dlg.addEventListener('cancel', onCancel);
      $('photo-dlg-add').onclick = function () { done('add'); };
      $('photo-dlg-discard').onclick = function () { done('discard'); };
      $('photo-dlg-add-rest').onclick = function () { done('rest'); };
      dlg.showModal();
    });
  }

  async function handlePhotoFiles(fileList) {
    const files = Array.prototype.slice.call(fileList || []);
    if (!files.length) return;
    if (!(await ensureFindingSaved())) return;
    const f = await DB.get('findings', S.finding.finding_id);
    const existing = (await DB.byIndex('photos', 'finding_id', f.finding_id)).filter(function (p) { return p.deleted !== 'Y'; });
    const hashes = new Set(existing.map(function (p) { return p.content_hash; }));
    let order = existing.reduce(function (m, p) { return Math.max(m, p.sort_order || 0); }, 0), added = 0, noPrompt = false;
    for (let i = 0; i < files.length; i++) {
      let processed;
      loading(true, 'Preparing photo ' + (i + 1) + ' of ' + files.length + '\u2026');
      try { processed = await Photos.process(files[i]); }
      catch (e) { loading(false); toast(errMsg(e), 'error'); continue; }
      loading(false);
      if (hashes.has(processed.hash)) { toast('That photo is already attached to this finding.'); continue; }
      let choice = noPrompt ? { action: 'add', stage: $('photo-default-stage').value, caption: '' } : await promptPhoto(processed, i + 1, files.length);
      if (choice.action === 'discard') continue;
      if (choice.action === 'rest') noPrompt = true;
      try { await Photos.add(f, processed, choice.stage, choice.caption, ++order); hashes.add(processed.hash); added++; }
      catch (e) { toast('Could not save the photo on this phone: ' + errMsg(e), 'error'); break; }
    }
    if (added) { await renderPhotos(); afterWrite(); toast(added + ' photo(s) saved on this phone.', 'ok'); }
  }

  async function handleReplace(fileList) {
    const file = fileList && fileList[0]; if (!file || !S.replaceId) return;
    loading(true, 'Replacing photo\u2026');
    try {
      const processed = await Photos.process(file);
      const ph = await DB.get('photos', S.replaceId);
      await Photos.replace(ph, processed);
      loading(false); await renderPhotos(); afterWrite(); toast('Photo replaced. It will upload on the next sync.', 'ok');
    } catch (e) { loading(false); toast(errMsg(e), 'error'); }
    S.replaceId = '';
  }

  /* =====================================================================
     Settings screen
     ===================================================================== */
  async function renderSettings() {
    showView('settings', 'Settings', true);
    S.settings = await DB.getMeta('settings', {}); S.logo = await DB.getMeta('logo', null);
    fillForm($('form-settings'), S.settings);
    const lp = $('logo-preview');
    if (S.logo && S.logo.dataBase64) { lp.src = trackUrl(Util.base64ToBlob(S.logo.dataBase64, S.logo.mime_type)); lp.hidden = false; $('logo-none').hidden = true; }
    else { lp.hidden = true; $('logo-none').hidden = false; }
    $('last-sync-label').textContent = fmtIso(await DB.getMeta('lastSync', ''));
    $('device-id-label').textContent = API.getDeviceId(); $('app-version').textContent = C.APP_VERSION;
    updateStorageInfo();
  }
  async function updateStorageInfo() {
    const el = $('storage-info');
    if (!navigator.storage || !navigator.storage.estimate) { el.textContent = 'Storage information is not available on this browser.'; return; }
    const e = await navigator.storage.estimate();
    const used = (e.usage || 0) / 1048576, quota = (e.quota || 0) / 1048576;
    el.textContent = 'Using ' + used.toFixed(1) + ' MB of about ' + Math.round(quota) + ' MB available.' + (quota && used / quota > C.STORAGE_WARN_RATIO ? ' Storage is almost full: sync and clear old projects.' : '');
  }
  async function saveSettings() {
    if (!canSync()) { toast('Saving settings needs internet and a login.', 'error'); return; }
    loading(true, 'Saving settings\u2026');
    try {
      const d = await API.call('saveSettings', { settings: readForm($('form-settings')) }, { operationId: Ids.op() });
      await DB.setMeta('settings', d.settings); S.settings = d.settings;
      loading(false); toast('Settings saved.', 'ok');
    } catch (e) { loading(false); toast('Could not save settings: ' + errMsg(e), 'error'); }
  }
  async function uploadLogo() {
    const file = $('input-logo').files[0];
    if (!file) { toast('Choose a logo file first.', 'error'); return; }
    if (['image/png', 'image/jpeg'].indexOf(file.type) === -1) { toast('The logo must be a PNG or JPEG image.', 'error'); return; }
    if (file.size > 1024 * 1024) { toast('The logo is larger than 1 MB.', 'error'); return; }
    if (!canSync()) { toast('Uploading the logo needs internet and a login.', 'error'); return; }
    loading(true, 'Uploading logo\u2026');
    try {
      await API.call('uploadLogo', { mime_type: file.type, dataBase64: await Util.blobToBase64(file) }, { operationId: Ids.op() });
      await Sync.refreshSettings(); await renderSettings();
      loading(false); toast('Logo uploaded.', 'ok');
    } catch (e) { loading(false); toast('Could not upload the logo: ' + errMsg(e), 'error'); }
  }
  async function logout() {
    const sc = await Sync.scan();
    const ok = await confirmDlg({ title: 'Log out?', message: sc.pending ? sc.pending + ' change(s) are not synced yet. They stay on this phone and sync after you log in again.' : 'You will need your access code to log in again.', okText: 'Log out' });
    if (!ok) return;
    await API.logout(); S.authed = false; showLogin();
  }
  async function clearLocal() {
    const sc = await Sync.scan(), n = sc.pending + sc.failed + sc.conflicts;
    const ok = await confirmDlg({
      title: 'Clear all data on this phone?',
      message: n ? 'WARNING: ' + n + ' item(s) have NOT been synced and will be lost forever. Tap Cancel and use Sync Now first.' : 'All projects, photos and reports stored on this phone will be removed. Everything already synced stays in Google Sheets and Drive.',
      okText: n ? 'Delete unsynced data' : 'Clear local data', danger: true
    });
    if (!ok) return;
    if (n && !(await confirmDlg({ title: 'Really delete?', message: 'This cannot be undone.', okText: 'Yes, delete', danger: true }))) return;
    await DB.clearAllData(); S.authed = false; location.hash = ''; location.reload();
  }

  /* =====================================================================
     Wiring + start-up
     ===================================================================== */
  function wire() {
    $('btn-login').onclick = doLogin;
    $('login-code').addEventListener('keydown', function (e) { if (e.key === 'Enter') doLogin(); });
    $('btn-offline-continue').onclick = function () { enterApp(false); };
    $('btn-back').onclick = function () {
      if (S.view === 'finding' && S.finding) go('#/project/' + S.finding.project_id); else go('#/home');
    };
    $('nav-home').onclick = function () { go('#/home'); };
    $('nav-settings').onclick = function () { go('#/settings'); };
    $('btn-sync').onclick = function () { doSync(true); };
    $('chip-sync').onclick = openSyncDialog;
    $('sync-close').onclick = function () { $('dlg-sync').close(); };
    $('sync-now-dlg').onclick = async function () { $('dlg-sync').close(); await doSync(true); };
    $('sync-retry-failed').onclick = async function () { $('dlg-sync').close(); if (!canSync()) { toast('Retrying needs internet and a login.', 'error'); return; } await Sync.retryFailed(); await updateChips(); toast('Retry finished.'); refreshCurrent(); };
    $('pdf-close').onclick = function () { $('dlg-pdf').close(); };
    $('dlg-pdf').addEventListener('close', function () { $('pdf-frame').removeAttribute('src'); });

    $('btn-new-project').onclick = function () { go('#/project/new'); };
    $('btn-open-existing').onclick = function () { $('filters-details').open = false; $('search-input').focus(); $('project-list').scrollIntoView({ behavior: 'smooth' }); };
    const rd = Util.debounce(renderDashboard, 200);
    $('search-input').addEventListener('input', rd);
    ['filter-client', 'filter-location'].forEach(function (id) { $(id).addEventListener('input', rd); });
    ['filter-date-from', 'filter-date-to'].forEach(function (id) { $(id).addEventListener('change', renderDashboard); });
    $('filter-status').addEventListener('change', async function () {
      if (this.value === '__deleted' && canSync()) { try { await Sync.pullDeleted(); } catch (e) { toast('Could not load deleted projects: ' + errMsg(e), 'error'); } }
      renderDashboard();
    });
    $('btn-clear-filters').onclick = function () { ['search-input', 'filter-status', 'filter-client', 'filter-location', 'filter-date-from', 'filter-date-to'].forEach(function (id) { $(id).value = ''; }); renderDashboard(); };

    $('btn-save-project').onclick = function () { saveProject(false); };
    $('btn-generate-pdf').onclick = generatePdf;
    $('btn-delete-project').onclick = deleteProject;
    $('btn-restore-project').onclick = restoreProject;
    $('btn-duplicate-project').onclick = duplicateProject;
    $('btn-add-finding').onclick = async function () {
      if (!S.exists) { if (!(await saveProject(true))) return; toast('Project saved on this phone.', 'ok'); }
      go('#/finding/new/' + S.project.project_id);
    };
    $('form-project').addEventListener('submit', function (e) { e.preventDefault(); });
    $('form-finding').addEventListener('submit', function (e) { e.preventDefault(); });
    $('form-finding').addEventListener('change', function () { updateConditionals($('form-finding')); });

    $('btn-save-finding').onclick = function () { saveFinding({}); };
    $('btn-delete-finding').onclick = deleteFinding;
    $('btn-photo-camera').onclick = function () { $('input-photo-camera').value = ''; $('input-photo-camera').click(); };
    $('btn-photo-gallery').onclick = function () { $('input-photo-gallery').value = ''; $('input-photo-gallery').click(); };
    $('input-photo-camera').addEventListener('change', function () { handlePhotoFiles(this.files); });
    $('input-photo-gallery').addEventListener('change', function () { handlePhotoFiles(this.files); });
    $('input-photo-replace').addEventListener('change', function () { handleReplace(this.files); });

    $('btn-save-settings').onclick = saveSettings;
    $('btn-upload-logo').onclick = uploadLogo;
    $('btn-logout').onclick = logout;
    $('btn-clear-local').onclick = clearLocal;
    $('btn-persist').onclick = async function () {
      if (!navigator.storage || !navigator.storage.persist) { toast('Not supported on this browser.', 'error'); return; }
      toast((await navigator.storage.persist()) ? 'Local data is now protected from automatic clean-up.' : 'The browser did not allow this. Install the app to the Home Screen and try again.', 'ok');
    };

    window.addEventListener('online', function () { toast('Back online.', 'ok'); updateChips(); Sync.schedule(); });
    window.addEventListener('offline', function () { toast('You are offline. Your work is saved on this phone.'); updateChips(); });
    window.addEventListener('hashchange', onHashChange);
    document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') { updateChips(); if (canSync()) Sync.schedule(); } });
    window.addEventListener('beforeunload', function (e) { if (S.authed && isDirty()) { e.preventDefault(); e.returnValue = ''; } });
    setInterval(function () { if (S.authed && canSync() && !Sync.isRunning()) Sync.scan().then(function (sc) { if (sc.pending) Sync.run(); }); }, 60000);

    Sync.on(function (st) {
      updateChips();
      if (S.lastSyncStatus === 'syncing' && st.status !== 'syncing' && S.authed) { loadSettingsCache(); refreshCurrent(); }
      S.lastSyncStatus = st.status;
    });
    API.onAuthLost(function () { updateChips(); toast('Your session expired. Tap Sync Now to log in again.', 'error'); });
  }

  function registerWorker() {
    if (!('serviceWorker' in navigator)) return;
    navigator.serviceWorker.register('sw.js').then(function (reg) {
      function showUpdate() { $('update-banner').hidden = false; $('btn-reload').onclick = function () { if (reg.waiting) reg.waiting.postMessage({ type: 'SKIP_WAITING' }); }; }
      if (reg.waiting && navigator.serviceWorker.controller) showUpdate();
      reg.addEventListener('updatefound', function () {
        const nw = reg.installing;
        if (nw) nw.addEventListener('statechange', function () { if (nw.state === 'installed' && navigator.serviceWorker.controller) showUpdate(); });
      });
    }).catch(function (e) { console.warn('Service worker not registered:', e); });
    let reloaded = false;
    navigator.serviceWorker.addEventListener('controllerchange', function () { if (reloaded) return; reloaded = true; location.reload(); });
  }

  async function start() {
    try {
      wire();
      if (!API.isConfigured()) setBanner($('config-banner'), 'error', 'Setup needed: open config.js and paste your Apps Script Web app URL into API_URL.');
      await DB.open(); await API.init();
      S.settings = await DB.getMeta('settings', {}); S.logo = await DB.getMeta('logo', null);
      fillEnums(document);
      $('device-id-label').textContent = API.getDeviceId(); $('app-version').textContent = C.APP_VERSION;
      registerWorker();
      if (API.hasToken()) await enterApp(false);
      else await showLogin();
    } catch (e) {
      console.error(e);
      const b = $('config-banner'); b.className = 'banner banner-error'; b.textContent = 'The app could not start: ' + errMsg(e); b.hidden = false;
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
