/* Marble Site Audit - pdf.js
   Builds the client-ready PDF report on the phone with jsPDF (A4, embedded photographs).
   PDF.build({ project, findings, photos, settings, logo }) -> { blob, fileName }
     photos: array of photo records, each with a .blob (JPEG/PNG) already attached.
     logo:   { mime_type, dataBase64 } or null.
   Limitation: the built-in PDF fonts only cover Latin characters. Arabic or other scripts print as "?". */
(function () {
  'use strict';
  const PW = 210, PH = 297, M = 15, CW = PW - 2 * M;
  const TOP = 22, BOTTOM = PH - 20;
  const SLATE = [36, 49, 58], PRIMARY = [31, 78, 95], GOLD = [133, 96, 28], GREY = [91, 102, 112], LINE = [217, 211, 199], PALE = [243, 240, 234];
  const PRIO = { Low: [30, 122, 70], Medium: [161, 92, 0], High: [196, 80, 0], Critical: [179, 38, 30] };
  const STAGES = ['Before', 'During', 'After'];

  function clean(s) {
    return String(s == null ? '' : s)
      .replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/[\u2013\u2014]/g, '-').replace(/\u2026/g, '...')
      .replace(/\r\n?/g, '\n').replace(/[^\n\x20-\x7E\xA0-\xFF]/g, '?');
  }
  function fmtDT(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}))?/.exec(s || '');
    if (!m) return s || '-';
    const mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][+m[2] - 1];
    return (+m[3]) + ' ' + mon + ' ' + m[1] + (m[4] ? ', ' + m[4] + ':' + m[5] : '');
  }
  function today(tz) {
    try { return new Date().toLocaleDateString('en-GB', { timeZone: tz || 'Asia/Dubai', day: 'numeric', month: 'short', year: 'numeric' }); }
    catch (e) { return new Date().toDateString(); }
  }
  async function bytesOf(blob) { return new Uint8Array(await blob.arrayBuffer()); }
  async function toJpegBytes(blob) {       // PNG/WebP photos from other sources are converted so jsPDF can embed them
    const bmp = await createImageBitmap(blob);
    const cv = document.createElement('canvas'); cv.width = bmp.width; cv.height = bmp.height;
    const ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height); ctx.drawImage(bmp, 0, 0);
    const out = await new Promise(function (res) { cv.toBlob(res, 'image/jpeg', 0.85); });
    return { bytes: await bytesOf(out), w: bmp.width, h: bmp.height };
  }

  async function build(input) {
    const jsPDFCtor = window.jspdf && window.jspdf.jsPDF;
    if (!jsPDFCtor) throw new Error('The PDF library did not load. Reload the app once while online.');
    const p = input.project, S = input.settings || {};
    const company = clean(S.company_name || 'Marblelife Gulf');
    const title = clean(S.report_title || 'Marble Restoration Site Audit Report');
    const findings = input.findings.slice().sort(Util.bySort);
    const doc = new jsPDFCtor({ unit: 'mm', format: 'a4', compress: true });
    let y = TOP;

    /* ----- primitives ----- */
    function color(c) { doc.setTextColor(c[0], c[1], c[2]); }
    function font(size, bold, c) { doc.setFont('helvetica', bold ? 'bold' : 'normal'); doc.setFontSize(size); color(c || SLATE); }
    function lh(size) { return size * 0.42; }
    function newPage() { doc.addPage(); y = TOP; }
    function ensure(h) { if (y + h > BOTTOM) newPage(); }
    function rule(c) { doc.setDrawColor((c || LINE)[0], (c || LINE)[1], (c || LINE)[2]); doc.setLineWidth(0.2); doc.line(M, y, PW - M, y); }

    function para(text, o) {
      o = o || {};
      const size = o.size || 10, x = M + (o.indent || 0), w = CW - (o.indent || 0);
      font(size, o.bold, o.color);
      const lines = doc.splitTextToSize(clean(text), w);
      lines.forEach(function (ln) { ensure(lh(size) + 1); doc.text(ln, x, y + lh(size)); y += lh(size) + 1.1; });
      y += (o.after == null ? 2 : o.after);
    }
    function heading(text, level) {
      const size = level === 2 ? 11.5 : 14;
      ensure(18);
      y += level === 2 ? 2 : 4;
      font(size, true, PRIMARY); doc.text(clean(text), M, y + lh(size));
      y += lh(size) + 1.5;
      if (level !== 2) { doc.setDrawColor(GOLD[0], GOLD[1], GOLD[2]); doc.setLineWidth(0.6); doc.line(M, y, M + 24, y); y += 3; } else y += 1;
    }
    /** label / value row; long values continue on the next page */
    function kv(label, value, o) {
      o = o || {};
      const v = clean(value && String(value).trim() ? value : '-');
      const lw = 46, size = 9.5;
      font(size, false); const lines = doc.splitTextToSize(v, CW - lw - 2);
      const first = lh(size) + 1.1;
      ensure(first + 2);
      font(8.5, true, GREY);
      doc.splitTextToSize(clean(label), lw - 2).slice(0, 3).forEach(function (l, i) { doc.text(l, M, y + lh(8.5) + i * 3.4); });
      const labelLines = Math.min(3, doc.splitTextToSize(clean(label), lw - 2).length);
      font(size, !!o.bold, o.color);
      let used = 0;
      lines.forEach(function (ln, i) {
        if (i > 0 && y + lh(size) + 1.1 > BOTTOM) { rule(); newPage(); }
        doc.text(ln, M + lw, y + lh(size)); y += lh(size) + 1.1; used++;
      });
      if (used * (lh(size) + 1.1) < labelLines * 3.4) y += labelLines * 3.4 - used * (lh(size) + 1.1);
      y += 1; rule(); y += 1.5;
    }

    /* ----- cover block ----- */
    doc.setFillColor(SLATE[0], SLATE[1], SLATE[2]); doc.rect(0, 0, PW, 30, 'F');
    let logoDrawn = false;
    if (input.logo && input.logo.dataBase64) {
      try {
        const bin = atob(input.logo.dataBase64), arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        const isPng = /png/i.test(input.logo.mime_type);
        const bmp = await createImageBitmap(new Blob([arr], { type: input.logo.mime_type }));
        const lw = Math.min(50, 18 * bmp.width / bmp.height), lhh = lw * bmp.height / bmp.width;
        doc.setFillColor(255, 255, 255); doc.roundedRect(M - 2, 5, lw + 4, 20, 1.5, 1.5, 'F');
        doc.addImage(arr, isPng ? 'PNG' : 'JPEG', M, 5 + (20 - lhh) / 2, lw, lhh, 'logo', 'FAST');
        logoDrawn = true;
      } catch (e) { logoDrawn = false; }
    }
    if (!logoDrawn) { font(18, true, [255, 255, 255]); doc.text(company, M, 15); font(8, false, [200, 200, 200]); doc.text('[Logo placeholder - upload a logo in Settings]', M, 21); }
    font(8.5, false, [220, 220, 220]);
    [S.company_address, S.company_phone, S.company_email].filter(Boolean).forEach(function (t, i) { doc.text(clean(t), PW - M, 11 + i * 4.5, { align: 'right' }); });

    y = 42;
    font(22, true, PRIMARY); doc.splitTextToSize(title, CW).forEach(function (l) { doc.text(l, M, y); y += 9; });
    font(13, false, SLATE); doc.splitTextToSize(clean(p.project_name), CW).forEach(function (l) { doc.text(l, M, y); y += 6; });
    y += 3; doc.setDrawColor(GOLD[0], GOLD[1], GOLD[2]); doc.setLineWidth(0.8); doc.line(M, y, M + 30, y); y += 6;

    heading('Project and inspection details', 2);
    kv('Project ID', p.project_id); kv('Client / company', p.client_name); kv('Building / property', p.building_name);
    kv('Site location', p.site_location); kv('Client contact', [p.contact_person, p.contact_phone, p.contact_email].filter(Boolean).join('  |  '));
    kv('Inspection date', fmtDT(p.inspection_datetime)); kv('Inspector', p.inspector_name); kv('Job / quotation / PO', p.job_reference);
    kv('Report date', today(S.timezone));

    /* ----- summary sections ----- */
    if (p.executive_summary) { heading('Executive Summary', 1); para(p.executive_summary); }
    if (p.overall_condition) { heading('Overall Site Condition', 1); para(p.overall_condition); }
    if (p.general_notes) { heading('General Site Notes', 1); para(p.general_notes); }

    if (findings.length) {
      heading('Summary of Findings', 1);
      const cols = [[M, 9, '#'], [M + 9, 55, 'Area / location'], [M + 64, 52, 'Defect'], [M + 116, 22, 'Priority'], [M + 138, 30, 'Est. area (sqm)']];
      ensure(14); doc.setFillColor(PALE[0], PALE[1], PALE[2]); doc.rect(M, y, CW, 6.5, 'F');
      font(8.5, true, GREY); cols.forEach(function (c) { doc.text(c[2], c[0] + 1.5, y + 4.4); }); y += 7;
      let total = 0;
      findings.forEach(function (f, i) {
        const defect = f.defect_category === 'Other' && f.defect_category_other ? f.defect_category_other : f.defect_category;
        const aLines = doc.splitTextToSize(clean(f.area_location), 52), dLines = doc.splitTextToSize(clean(defect || '-'), 49);
        const rows = Math.max(aLines.length, dLines.length, 1), h = rows * 4 + 2;
        ensure(h);
        font(9, false); doc.text(String(i + 1), cols[0][0] + 1.5, y + 4);
        aLines.forEach(function (l, k) { doc.text(l, cols[1][0] + 1.5, y + 4 + k * 4); });
        dLines.forEach(function (l, k) { doc.text(l, cols[2][0] + 1.5, y + 4 + k * 4); });
        font(9, true, PRIO[f.priority] || SLATE); doc.text(clean(f.priority || '-'), cols[3][0] + 1.5, y + 4);
        font(9, false); doc.text(f.estimated_area_sqm != null ? String(f.estimated_area_sqm) : '-', cols[4][0] + 1.5, y + 4);
        if (f.estimated_area_sqm != null) total += Number(f.estimated_area_sqm) || 0;
        y += h; rule();
      });
      y += 1.5; font(9.5, true); ensure(7); doc.text('Total estimated area: ' + (Math.round(total * 100) / 100) + ' sqm', M, y + 4); y += 8;
    }

    /* ----- detailed findings ----- */
    if (findings.length) { newPage(); heading('Detailed Findings', 1); }
    for (let i = 0; i < findings.length; i++) {
      const f = findings[i];
      ensure(50);
      doc.setFillColor(PALE[0], PALE[1], PALE[2]); doc.rect(M, y, CW, 9, 'F');
      doc.setFillColor(SLATE[0], SLATE[1], SLATE[2]); doc.rect(M, y, 2.2, 9, 'F');
      font(11, true, SLATE); doc.text('Finding ' + (i + 1) + ' - ' + clean(f.area_location).slice(0, 70), M + 5, y + 6);
      const pc = PRIO[f.priority] || SLATE; font(9, true, pc); doc.text(clean((f.priority || '') + ' priority').toUpperCase(), PW - M - 2, y + 6, { align: 'right' });
      y += 12;
      kv('Area / location', f.area_location); kv('Stone / material', f.material_type);
      kv('Finish', f.finish === 'Other' && f.finish_other ? f.finish_other : f.finish);
      kv('Defect category', f.defect_category === 'Other' && f.defect_category_other ? f.defect_category_other : f.defect_category);
      if (f.existing_condition) kv('Existing condition', f.existing_condition);
      kv('Defect description', f.defect_description);
      if (f.possible_cause) kv("Possible cause (inspector's assessment, not a confirmed fact)", f.possible_cause);
      kv('Recommended restoration method', f.recommended_method);
      if (f.required_materials) kv('Materials / chemicals', f.required_materials);
      kv('Estimated area', f.estimated_area_sqm != null ? f.estimated_area_sqm + ' sqm' : '-');
      kv('Priority', f.priority, { bold: true, color: pc });
      if (f.inspector_remarks) kv('Inspector remarks', f.inspector_remarks);
      if (f.client_remarks) kv('Client remarks', f.client_remarks);
      if (f.next_action) kv('Recommendation / next action', f.next_action);

      const ph = input.photos.filter(function (x) { return x.finding_id === f.finding_id && x.deleted !== 'Y' && x.blob; })
        .sort(function (a, b) { return (STAGES.indexOf(a.stage) - STAGES.indexOf(b.stage)) || Util.bySort(a, b); });
      if (ph.length) {
        y += 2; ensure(80); font(10, true, PRIMARY); doc.text('Photographs', M, y + 3); y += 6;
        const cw = (CW - 6) / 2, maxH = 62;
        for (let k = 0; k < ph.length; k += 2) {
          const row = [];
          for (let j = k; j < Math.min(k + 2, ph.length); j++) {
            const x = ph[j]; let bytes, w = x.width, h = x.height;
            try {
              if (/jpe?g/i.test(x.mime_type) && w && h) bytes = await bytesOf(x.blob);
              else { const c = await toJpegBytes(x.blob); bytes = c.bytes; w = c.w; h = c.h; }
            } catch (e) { continue; }
            let dw = cw, dh = cw * h / w; if (dh > maxH) { dh = maxH; dw = maxH * w / h; }
            const cap = clean((x.stage || '') + (x.caption ? ': ' + x.caption : '')), capLines = doc.splitTextToSize(cap, cw).slice(0, 3);
            row.push({ x: x, bytes: bytes, dw: dw, dh: dh, capLines: capLines });
          }
          if (!row.length) continue;
          const rowH = Math.max.apply(null, row.map(function (r) { return r.dh + 1 + r.capLines.length * 3.6 + 1; }));
          ensure(rowH + 2);
          row.forEach(function (r, idx) {
            const cx = M + idx * (cw + 6);
            doc.addImage(r.bytes, 'JPEG', cx, y, r.dw, r.dh, r.x.photo_id, 'FAST');
            doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.setLineWidth(0.2); doc.rect(cx, y, r.dw, r.dh);
            font(8, false, GREY); r.capLines.forEach(function (l, n) { doc.text(l, cx, y + r.dh + 3.6 + n * 3.6); });
          });
          y += rowH + 2;
        }
      }
      y += 4;
      if (i < findings.length - 1) { ensure(30); }
    }

    /* ----- closing sections ----- */
    if (p.overall_recommendations) { heading('General Recommendations', 1); para(p.overall_recommendations); }
    heading('Limitations and Disclaimer', 1);
    para(S.report_disclaimer || 'This report is based on a visual inspection and reflects conditions visible on the inspection date.', { size: 9, color: GREY });

    ensure(62); y += 4; heading('Sign-off', 1);
    const bw = (CW - 8) / 2;
    [['Inspector', p.inspector_name, 'Signature'], ['Client representative', p.client_rep_name, 'Acknowledgment of receipt / signature']].forEach(function (b, i) {
      const x = M + i * (bw + 8);
      doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.setLineWidth(0.3); doc.rect(x, y, bw, 42);
      font(9, true, PRIMARY); doc.text(b[0], x + 3, y + 6);
      font(9.5, false); doc.text(clean(b[1] || '________________________').slice(0, 45), x + 3, y + 13);
      doc.setDrawColor(SLATE[0], SLATE[1], SLATE[2]); doc.line(x + 3, y + 31, x + bw - 3, y + 31);
      font(8, false, GREY); doc.text(b[2], x + 3, y + 35); doc.text('Date: ____ / ____ / ________', x + 3, y + 40);
    });
    y += 46;

    /* ----- header + footer on every page ----- */
    const n = doc.getNumberOfPages();
    for (let i = 1; i <= n; i++) {
      doc.setPage(i);
      if (i > 1) { font(8, false, GREY); doc.text(clean(p.project_name).slice(0, 60) + '  |  ' + clean(p.client_name).slice(0, 40), M, 12); doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.setLineWidth(0.2); doc.line(M, 15, PW - M, 15); }
      doc.setDrawColor(LINE[0], LINE[1], LINE[2]); doc.setLineWidth(0.2); doc.line(M, PH - 14, PW - M, PH - 14);
      font(8, false, GREY);
      doc.text(company + '  |  ' + title, M, PH - 9);
      doc.text('Page ' + i + ' of ' + n, PW - M, PH - 9, { align: 'right' });
      doc.text('Generated ' + today(S.timezone) + '  |  ' + p.project_id, M, PH - 5);
    }

    const blob = doc.output('blob');
    const safe = clean(p.project_name).replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 50) || 'Project';
    const d = new Date().toISOString().slice(0, 10);
    return { blob: blob, fileName: 'Site Audit Report - ' + safe + ' - ' + d + '.pdf' };
  }

  window.PDF = { build: build };
})();
