/* Marble Site Audit - sw.js (service worker)
   Makes the app open and work with no internet by keeping a copy of the app's own files.

   IMPORTANT: every time you change ANY app file (index.html, app.js, styles.css, config.js ...)
   and upload it again, change the number in CACHE_VERSION below too. That is what tells
   phones to fetch the new files.

   This file never touches Google requests (script.google.com): your data is handled by the
   app itself in IndexedDB, not by this file. */

const CACHE_VERSION = 'v1.0.0-1';
const CACHE_NAME = 'marble-site-audit-' + CACHE_VERSION;

const APP_FILES = [
  './',
  'index.html',
  'styles.css',
  'config.js',
  'db.js',
  'api.js',
  'photos.js',
  'sync.js',
  'pdf.js',
  'app.js',
  'vendor/jspdf.umd.min.js',
  'manifest.webmanifest',
  'icons/icon-192.png',
  'icons/icon-512.png',
  'icons/icon-maskable-512.png'
];

self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function (cache) {
      // Add files one by one so a single missing file (for example an icon) cannot break the install.
      return Promise.all(APP_FILES.map(function (path) {
        return cache.add(new Request(new URL(path, self.registration.scope).href, { cache: 'reload' }))
          .catch(function (err) { console.warn('Not cached: ' + path, err); });
      }));
    })
  );
  // No skipWaiting() here: the app shows "A new version is ready" and asks the user to reload.
});

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (names) {
      return Promise.all(names
        .filter(function (n) { return n.indexOf('marble-site-audit-') === 0 && n !== CACHE_NAME; })
        .map(function (n) { return caches.delete(n); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('message', function (event) {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', function (event) {
  const req = event.request;
  if (req.method !== 'GET') return;                       // saves/uploads (POST) go straight to Google
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;       // never intercept Google or other sites

  // Opening the app: serve the saved page instantly, even offline.
  if (req.mode === 'navigate') {
    event.respondWith(
      caches.match(new URL('index.html', self.registration.scope).href, { ignoreSearch: true })
        .then(function (cached) {
          const network = fetch(req).then(function (res) {
            if (res && res.ok) {
              const copy = res.clone();
              caches.open(CACHE_NAME).then(function (c) { c.put(new URL('index.html', self.registration.scope).href, copy); });
            }
            return res;
          }).catch(function () { return cached; });
          return cached || network;
        })
    );
    return;
  }

  // Other app files: use the saved copy, and quietly refresh it in the background.
  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then(function (cached) {
      const network = fetch(req).then(function (res) {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then(function (c) { c.put(req, copy); });
        }
        return res;
      }).catch(function () { return cached; });
      return cached || network;
    })
  );
});
