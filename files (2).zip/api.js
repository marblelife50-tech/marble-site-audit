/* Marble Site Audit - api.js
   Talks to the Apps Script backend. Every request is a POST with a text/plain JSON body
   (this avoids the browser "pre-flight" check that Apps Script cannot answer). */
(function () {
  'use strict';
  const C = window.APP_CONFIG;

  class ApiError extends Error {
    constructor(code, message, data) {
      super(message);
      this.name = 'ApiError';
      this.code = code;
      this.data = data || null;
    }
  }

  const API = {
    ApiError: ApiError,
    token: null,
    expiresAt: 0,
    deviceId: '',

    async init() {
      this.deviceId = Store.getDeviceId();
      const s = await DB.meta.get('session');
      if (s && s.token) { this.token = s.token; this.expiresAt = s.expiresAt || 0; }
    },

    hasConfig() {
      const u = String(C.API_URL || '');
      return u.indexOf('https://script.google.com/') === 0 && /\/exec$/.test(u);
    },
    hasValidSession() {
      return !!this.token && Date.now() < (this.expiresAt - C.SESSION_REFRESH_MARGIN_MS);
    },
    isNetworkError(e) { return !!e && (e.code === 'NETWORK' || e.code === 'TIMEOUT'); },

    async setSession(token, expiresAt) {
      this.token = token; this.expiresAt = expiresAt;
      await DB.meta.set('session', { token: token, expiresAt: expiresAt });
    },
    async clearSession(notify) {
      this.token = null; this.expiresAt = 0;
      try { await DB.meta.del('session'); } catch (e) { /* ignore */ }
      if (notify) Bus.emit('auth-needed', {});
    },

    async login(code) {
      const d = await this.call('login', { code: String(code || '') }, { noAuth: true });
      await this.setSession(d.token, d.expiresAt);
      Bus.emit('logged-in', {});
      return d;
    },
    async logout() { await this.clearSession(false); },

    /* Returns the "data" part of the response, or throws ApiError(code, message, data). */
    async call(action, payload, opts) {
      opts = opts || {};
      if (!this.hasConfig()) {
        throw new ApiError('NOT_CONFIGURED', 'The app is not connected to the server yet. Set API_URL in config.js.');
      }
      const body = JSON.stringify({
        action: action,
        token: opts.noAuth ? undefined : this.token,
        deviceId: this.deviceId,
        operationId: opts.operationId || undefined,
        payload: payload || {}
      });

      const ctrl = new AbortController();
      const timer = setTimeout(function () { ctrl.abort(); }, opts.timeoutMs || C.REQUEST_TIMEOUT_MS);
      let json;
      try {
        let res;
        try {
          res = await fetch(C.API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain;charset=utf-8' },
            body: body, redirect: 'follow', cache: 'no-store', credentials: 'omit', signal: ctrl.signal
          });
        } catch (e) {
          if (e && e.name === 'AbortError') throw new ApiError('TIMEOUT', 'The server took too long to answer.');
          throw new ApiError('NETWORK', 'No connection to the server.');
        }
        try { json = await res.json(); }
        catch (e) {
          if (ctrl.signal.aborted) throw new ApiError('TIMEOUT', 'The server took too long to answer.');
          throw new ApiError('BAD_RESPONSE', 'The server sent an unexpected reply. In Apps Script, check that the web app is deployed with access set to "Anyone".');
        }
      } finally {
        clearTimeout(timer);
      }

      if (!json || typeof json.ok !== 'boolean') {
        throw new ApiError('BAD_RESPONSE', 'The server sent an unexpected reply.');
      }
      if (!json.ok) {
        const er = json.error || {};
        const err = new ApiError(er.code || 'SERVER_ERROR', er.message || 'The server reported an error.', er.data);
        if (err.code === 'AUTH') await this.clearSession(true);
        throw err;
      }
      return json.data;
    },

    ping() { return this.call('ping', {}, { noAuth: true, timeoutMs: 15000 }); }
  };

  window.API = API;
})();
