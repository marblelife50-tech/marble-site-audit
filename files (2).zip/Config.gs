/**
 * Marble Site Audit - Config.gs
 * Constants, enums and the database schema. Every other file reads from here.
 * The ONLY lines you edit are the two IDs below (Part F explains how to find them).
 */

const CONFIG = {
  SPREADSHEET_ID: 'PASTE_SPREADSHEET_ID_HERE',
  ROOT_FOLDER_ID: 'PASTE_ROOT_FOLDER_ID_HERE',

  APP_VERSION: '1.0.0',
  SCHEMA_VERSION: 1,
  TIMEZONE: 'Asia/Dubai',

  SESSION_HOURS: 12,        // how long a login lasts
  MAX_FAILED_LOGINS: 5,     // wrong codes allowed before lockout
  LOCKOUT_MINUTES: 15,
  LOCK_WAIT_MS: 30000,      // max wait for the write lock
  MAX_PHOTO_BYTES: 6 * 1024 * 1024,  // server-side limit per photo
  MAX_REPORT_BYTES: 40 * 1024 * 1024 // server-side limit per PDF
};

const SHEETS = {
  PROJECTS: 'Projects',
  FINDINGS: 'Findings',
  PHOTOS: 'Photos',
  REPORTS: 'Reports',
  SYNC_LOG: 'Sync Log',
  SETTINGS: 'Settings'
};

// ID formats. IDs are created on the phone (so they work offline) and checked here.
const ID_PATTERNS = {
  project: /^PRJ-\d{8}-[A-Z0-9]{6}$/,
  finding: /^FND-\d{8}-[A-Z0-9]{6}$/,
  photo:   /^PHT-\d{8}-[A-Z0-9]{8}$/,
  report:  /^RPT-\d{8}-[A-Z0-9]{6}$/
};

// Allowed values. The frontend uses the same lists.
const ENUMS = {
  PROJECT_STATUS: ['Draft', 'Inspection Completed', 'Report Generated', 'Submitted'],
  FINISH: ['Polished', 'Honed', 'Leather', 'Flamed', 'Brushed', 'Other'],
  DEFECT_CATEGORY: ['Scratches', 'Etching', 'Dullness', 'Stains', 'Cracks', 'Chips',
                    'Lippage', 'Grout Damage', 'Sealer Failure', 'Water Marks',
                    'Slip Resistance Concern', 'Other'],
  PRIORITY: ['Low', 'Medium', 'High', 'Critical'],
  PHOTO_STAGE: ['Before', 'During', 'After']
};

/**
 * Column definitions. Each entry is [columnName, type]: 't' = text, 'n' = number.
 * Text columns are formatted as plain text so phone numbers keep their leading
 * zeros and dates are not converted. NEVER rename or reorder existing columns
 * after you have real data; only add new ones at the end.
 *
 * Relationships:
 *   Projects.project_id  <- Findings.project_id, Photos.project_id, Reports.project_id
 *   Findings.finding_id  <- Photos.finding_id
 * Deleting is "soft": deleted = 'Y' plus deleted_at. Rows are never removed.
 */
const SCHEMA = {};

SCHEMA[SHEETS.PROJECTS] = [
  ['project_id', 't'], ['project_name', 't'], ['client_name', 't'], ['building_name', 't'],
  ['site_location', 't'], ['contact_person', 't'], ['contact_phone', 't'], ['contact_email', 't'],
  ['inspection_datetime', 't'], ['inspector_name', 't'], ['job_reference', 't'], ['status', 't'],
  ['general_notes', 't'], ['overall_condition', 't'], ['executive_summary', 't'],
  ['overall_recommendations', 't'], ['client_rep_name', 't'],
  ['drive_folder_id', 't'], ['photos_folder_id', 't'], ['reports_folder_id', 't'],
  ['supporting_folder_id', 't'], ['latest_report_id', 't'],
  ['version', 'n'], ['created_at', 't'], ['updated_at', 't'], ['last_device_id', 't'],
  ['deleted', 't'], ['deleted_at', 't']
];

SCHEMA[SHEETS.FINDINGS] = [
  ['finding_id', 't'], ['project_id', 't'], ['sort_order', 'n'], ['area_location', 't'],
  ['material_type', 't'], ['finish', 't'], ['finish_other', 't'],
  ['defect_category', 't'], ['defect_category_other', 't'], ['existing_condition', 't'],
  ['defect_description', 't'], ['possible_cause', 't'],   // inspector's assessment, not confirmed fact
  ['recommended_method', 't'], ['required_materials', 't'], ['estimated_area_sqm', 'n'],
  ['priority', 't'], ['inspector_remarks', 't'], ['client_remarks', 't'], ['next_action', 't'],
  ['drive_folder_id', 't'],
  ['version', 'n'], ['created_at', 't'], ['updated_at', 't'], ['last_device_id', 't'],
  ['deleted', 't'], ['deleted_at', 't']
];

SCHEMA[SHEETS.PHOTOS] = [
  ['photo_id', 't'], ['project_id', 't'], ['finding_id', 't'], ['stage', 't'], ['caption', 't'],
  ['sort_order', 'n'], ['file_name', 't'], ['mime_type', 't'], ['size_bytes', 'n'],
  ['width', 'n'], ['height', 'n'], ['content_hash', 't'],
  ['drive_file_id', 't'], ['drive_url', 't'], ['captured_at', 't'],
  ['uploaded_at', 't'], ['updated_at', 't'], ['deleted', 't'], ['deleted_at', 't']
];

SCHEMA[SHEETS.REPORTS] = [
  ['report_id', 't'], ['project_id', 't'], ['file_name', 't'], ['drive_file_id', 't'],
  ['drive_url', 't'], ['project_version', 'n'], ['size_bytes', 'n'], ['content_hash', 't'],
  ['generated_at', 't'], ['generated_by_device', 't'], ['deleted', 't'], ['deleted_at', 't']
];

SCHEMA[SHEETS.SYNC_LOG] = [
  ['log_id', 't'], ['timestamp', 't'], ['device_id', 't'], ['operation_id', 't'],
  ['entity_type', 't'], ['entity_id', 't'], ['action', 't'], ['result', 't'], ['message', 't']
];

SCHEMA[SHEETS.SETTINGS] = [
  ['key', 't'], ['value', 't'], ['description', 't']
];

// ---------- Small helpers shared by all files ----------

function getSpreadsheet_() {
  if (!CONFIG.SPREADSHEET_ID || CONFIG.SPREADSHEET_ID.indexOf('PASTE_') === 0) {
    throw new Error('SPREADSHEET_ID is not set in Config.gs.');
  }
  return SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
}

function getRootFolder_() {
  if (!CONFIG.ROOT_FOLDER_ID || CONFIG.ROOT_FOLDER_ID.indexOf('PASTE_') === 0) {
    throw new Error('ROOT_FOLDER_ID is not set in Config.gs.');
  }
  return DriveApp.getFolderById(CONFIG.ROOT_FOLDER_ID);
}

function getSheet_(name) {
  const sh = getSpreadsheet_().getSheetByName(name);
  if (!sh) throw new Error('Sheet "' + name + '" not found. Run setupAll() first.');
  return sh;
}

function getHeaders_(name) {
  const sh = getSheet_(name);
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
}

function nowIso_() {
  return Utilities.formatDate(new Date(), 'UTC', "yyyy-MM-dd'T'HH:mm:ss'Z'");
}

function isValidId_(kind, id) {
  return typeof id === 'string' && ID_PATTERNS[kind].test(id);
}
