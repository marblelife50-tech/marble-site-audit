/**
 * Marble Site Audit - Projects.gs
 * Safe-update rules:
 *  - Only fields actually sent are changed; findings and photos are never touched by a project save.
 *  - Every save needs baseVersion = the version the phone last saw. If the server is newer the
 *    save is refused with code CONFLICT and the server's copy is returned.
 *  - Deleting is soft (flag + timestamp) and can be undone with restoreProject.
 */

function apiListProjects_(p) {
  const wantDeleted = !!(p && p.deleted);
  const findingCount = {}, photoCount = {}, reportUrl = {};
  readAllRows_(SHEETS.FINDINGS).rows.forEach(function (r) {
    if (r.deleted !== 'Y') findingCount[r.project_id] = (findingCount[r.project_id] || 0) + 1;
  });
  readAllRows_(SHEETS.PHOTOS).rows.forEach(function (r) {
    if (r.deleted !== 'Y') photoCount[r.project_id] = (photoCount[r.project_id] || 0) + 1;
  });
  readAllRows_(SHEETS.REPORTS).rows.forEach(function (r) {
    if (r.deleted !== 'Y') reportUrl[r.report_id] = r.drive_url;
  });

  const projects = readAllRows_(SHEETS.PROJECTS).rows
    .filter(function (r) { return wantDeleted ? r.deleted === 'Y' : r.deleted !== 'Y'; })
    .map(function (r) {
      const o = pub_(r);
      // Summaries only: the big text fields are loaded by getProject.
      ['general_notes', 'executive_summary', 'overall_recommendations', 'overall_condition'].forEach(function (k) { delete o[k]; });
      o.finding_count = findingCount[r.project_id] || 0;
      o.photo_count = photoCount[r.project_id] || 0;
      o.latest_report_url = reportUrl[r.latest_report_id] || '';
      return o;
    })
    .sort(function (a, b) { return String(b.updated_at).localeCompare(String(a.updated_at)); });
  return { projects: projects };
}

function getProjectBundle_(projectId) {
  const proj = findRowById_(SHEETS.PROJECTS, 'project_id', projectId);
  if (!proj) throw apiError_('NOT_FOUND', 'Project not found on the server.');
  const live = function (r) { return r.project_id === projectId && r.deleted !== 'Y'; };
  return {
    project: pub_(proj),
    findings: readAllRows_(SHEETS.FINDINGS).rows.filter(live).sort(bySortOrder_).map(pub_),
    photos: readAllRows_(SHEETS.PHOTOS).rows.filter(live).sort(bySortOrder_).map(pub_),
    reports: readAllRows_(SHEETS.REPORTS).rows.filter(live)
      .sort(function (a, b) { return String(b.generated_at).localeCompare(String(a.generated_at)); }).map(pub_)
  };
}

function apiGetProject_(p) {
  requireId_('project', p.projectId, 'projectId');
  return getProjectBundle_(p.projectId);
}

/** payload: { project:{project_id, ...fields}, baseVersion } (baseVersion ignored for a brand-new project) */
function apiSaveProject_(p, ctx) {
  const input = p.project;
  if (!input || typeof input !== 'object') throw apiError_('VALIDATION', 'Project data is missing.');
  requireId_('project', input.project_id, 'project_id');
  const fields = cleanProjectFields_(input);
  const existing = findRowById_(SHEETS.PROJECTS, 'project_id', input.project_id);
  const now = nowIso_();
  const errors = {};

  if (!existing) {
    const row = blankRow_(SHEETS.PROJECTS);
    row.status = 'Draft';
    Object.assign(row, fields);
    requireFields_(row, REQUIRED_PROJECT_FIELDS, errors);
    throwIfErrors_(errors);
    row.project_id = input.project_id;
    row.version = 1;
    row.created_at = now;
    row.updated_at = now;
    row.last_device_id = ctx.deviceId;
    try { Object.assign(row, ensureProjectFolders_(row)); }
    catch (e) { throw apiError_('DRIVE_ERROR', 'Could not create the Drive folders: ' + e.message); }
    appendRowObj_(SHEETS.PROJECTS, row);
    return { project: pub_(row), created: true, changed: true };
  }

  if (existing.deleted === 'Y') {
    throw apiError_('DELETED_ON_SERVER', 'This project was deleted on the server.', { serverProject: pub_(existing) });
  }
  if (Number(p.baseVersion) !== existing.version) {
    throw apiError_('CONFLICT', 'This project was changed on another device.', { serverProject: pub_(existing) });
  }

  const changedKeys = Object.keys(fields).filter(function (k) { return existing[k] !== fields[k]; });
  if (!changedKeys.length) return { project: pub_(existing), created: false, changed: false };

  const merged = Object.assign({}, existing, fields);
  requireFields_(merged, REQUIRED_PROJECT_FIELDS, errors);
  throwIfErrors_(errors);
  merged.version = existing.version + 1;
  merged.updated_at = now;
  merged.last_device_id = ctx.deviceId;
  writeRowObj_(SHEETS.PROJECTS, existing._row, merged);
  if (changedKeys.indexOf('project_name') > -1) tryRenameFolder_(merged.drive_folder_id, projectFolderName_(merged));
  return { project: pub_(merged), created: false, changed: true };
}

/** payload: { projectId, baseVersion? } */
function apiDeleteProject_(p, ctx) {
  requireId_('project', p.projectId, 'projectId');
  const proj = findRowById_(SHEETS.PROJECTS, 'project_id', p.projectId);
  if (!proj) return { alreadyGone: true };
  if (proj.deleted === 'Y') return { project: pub_(proj), alreadyDeleted: true };
  if (p.baseVersion !== undefined && Number(p.baseVersion) !== proj.version) {
    throw apiError_('CONFLICT', 'This project was changed on another device.', { serverProject: pub_(proj) });
  }
  const ts = nowIso_();
  proj.deleted = 'Y'; proj.deleted_at = ts; proj.updated_at = ts;
  proj.version += 1; proj.last_device_id = ctx.deviceId;
  writeRowObj_(SHEETS.PROJECTS, proj._row, proj);
  softDeleteWhere_(SHEETS.FINDINGS, 'project_id', p.projectId, ts);
  softDeleteWhere_(SHEETS.PHOTOS, 'project_id', p.projectId, ts);
  softDeleteWhere_(SHEETS.REPORTS, 'project_id', p.projectId, ts);
  // Drive files are deliberately kept so a restore is always possible.
  return { project: pub_(proj) };
}

/** payload: { projectId } */
function apiRestoreProject_(p, ctx) {
  requireId_('project', p.projectId, 'projectId');
  const proj = findRowById_(SHEETS.PROJECTS, 'project_id', p.projectId);
  if (!proj) throw apiError_('NOT_FOUND', 'Project not found on the server.');
  if (proj.deleted !== 'Y') return { project: pub_(proj), alreadyRestored: true };
  const ts = proj.deleted_at;
  proj.deleted = ''; proj.deleted_at = '';
  proj.updated_at = nowIso_(); proj.version += 1; proj.last_device_id = ctx.deviceId;
  writeRowObj_(SHEETS.PROJECTS, proj._row, proj);
  restoreWhere_(SHEETS.FINDINGS, 'project_id', p.projectId, ts);
  restoreWhere_(SHEETS.PHOTOS, 'project_id', p.projectId, ts);
  restoreWhere_(SHEETS.REPORTS, 'project_id', p.projectId, ts);
  return getProjectBundle_(p.projectId);
}

/**
 * payload: { sourceProjectId }. Copies the project fields and all findings (NOT photos or
 * reports) into a new Draft project. The server creates the new IDs, so this needs internet.
 */
function apiDuplicateProject_(p, ctx) {
  requireId_('project', p.sourceProjectId, 'sourceProjectId');
  const src = findRowById_(SHEETS.PROJECTS, 'project_id', p.sourceProjectId);
  if (!src || src.deleted === 'Y') throw apiError_('NOT_FOUND', 'The project to copy was not found.');

  const now = nowIso_();
  const row = blankRow_(SHEETS.PROJECTS);
  PROJECT_EDITABLE.forEach(function (k) { row[k] = src[k]; });
  row.project_name = (src.project_name + ' (Copy)').slice(0, MAX_SHORT);
  row.status = 'Draft';
  row.project_id = newId_('project');
  row.version = 1; row.created_at = now; row.updated_at = now; row.last_device_id = ctx.deviceId;
  try { Object.assign(row, ensureProjectFolders_(row)); }
  catch (e) { throw apiError_('DRIVE_ERROR', 'Could not create the Drive folders: ' + e.message); }
  appendRowObj_(SHEETS.PROJECTS, row);

  readAllRows_(SHEETS.FINDINGS).rows
    .filter(function (r) { return r.project_id === src.project_id && r.deleted !== 'Y'; })
    .sort(bySortOrder_)
    .forEach(function (f, i) {
      const nf = blankRow_(SHEETS.FINDINGS);
      FINDING_EDITABLE.forEach(function (k) { nf[k] = f[k]; });
      nf.finding_id = newId_('finding');
      nf.project_id = row.project_id;
      nf.sort_order = i + 1;
      nf.version = 1; nf.created_at = now; nf.updated_at = now; nf.last_device_id = ctx.deviceId;
      nf.drive_folder_id = ensureFindingFolder_(row, nf).getId();
      appendRowObj_(SHEETS.FINDINGS, nf);
    });

  return getProjectBundle_(row.project_id);
}
