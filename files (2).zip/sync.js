/* Marble Site Audit - sync.js
   Sends everything that is "not on the server yet" (see db.js) to Google Sheets / Drive, then
   pulls changes made on other devices. Rules:
    - Local data is only removed AFTER the server confirms.
    - Every change carries an operation ID, so a retry can never create a duplicate.
    - A network failure stops the run and leaves everything queued.
    - If the server copy changed on another device, the record is flagged as a conflict and
      NOTHING is overwritten until you choose what to do. */
(function () {
  'use strict';
  const C = window.APP_CONFIG;

  const FINAL_CODES = ['VALIDATION', 'TOO_LARGE', 'GONE', 'NOT_FOUND', 'BAD_REQUEST', 'FILE_MISSING', 'BLOB_MISSING'];
  const WAIT_CODES = ['PROJECT_MISSING', 'FINDING_MISSING'];
  const iso = function () { return new Date().toISOString(); };

  const Sync = {
    running: false,
    state: 'synced',
    message: '',
    online: navigator.onLine !== false,
    lastResult: null,
    _authNotified: false,
    _timer: null,

    /* ---------- status ---------- */
    _setOnline(v) {
      if (this.online !== v) { this.online = v; Bus.emit('online-changed', { online: v }); }
    },
    isOnline() { return this.online && navigator.onLine !== false; },
    _progress(msg) { this.message = msg; this._emit(); },
    async _emit() {
      const items = await Store.getPending();
      const errors = items.filter(function (i) { return i.state === 'error' || i.state === 'conflict'; }).length;
      this.state = this.running ? 'syncing' : (errors ? 'error' : (items.length ? 'pending' : 'synced'));
      Bus.emit('sync-state', { state: this.state, message: this.message, online: this.isOnline(), pending: items.length, errors: errors, items: items });
    },

    async _call(action, payload, opts) {
      try {
        const d = await API.call(action, payload, opts);
        this._setOnline(true);
        return d;
      } catch (e) {
        if (API.isNetworkError(e)) this._setOnline(false);
        throw e;
      }
    },
    _skip(rec, manual) {
      if (rec._conflict) return true;
      if (rec._syncError && rec._syncError.final && !manual) return true;
      return false;
    },

    /* ---------- main entry ---------- */
    async run(opts) {
      opts = opts || {};
      if (this.running) return { skipped: 'busy' };
      if (!API.hasConfig()) return { skipped: 'config' };
      if (navigator.onLine === false) { this._setOnline(false); await this._emit(); return { skipped: 'offline' }; }
      if (!API.hasValidSession()) {
        if (opts.manual || !this._authNotified) { this._authNotified = true; Bus.emit('auth-needed', {}); }
        await this._emit();
        return { skipped: 'auth' };
      }

      this.running = true;
      this.message = 'Syncing\u2026';
      const sum = { ok: 0, failed: 0, waiting: 0, conflicts: 0, aborted: null, error: '' };
      await this._emit();
      try {
        await this._push(sum, !!opts.manual);
        await this._pull(sum);
        await DB.meta.set('lastSync', iso());
      } catch (e) {
        if (API.isNetworkError(e)) { this._setOnline(false); sum.aborted = 'network'; sum.error = e.message; }
        else if (e.code === 'AUTH') { sum.aborted = 'auth'; sum.error = e.message; }
        else { sum.aborted = 'error'; sum.error = e.message || String(e); console.error(e); }
      } finally {
        this.running = false;
        this.message = '';
      }
      this.lastResult = sum;
      await this._emit();
      Bus.emit('sync-finished', sum);
      return sum;
    },

    start() {
      const self = this;
      window.addEventListener('online', function () { self._setOnline(true); self.run(); });
      window.addEventListener('offline', function () { self._setOnline(false); self._emit(); });
      document.addEventListener('visibilitychange', function () { if (!document.hidden) self.run(); });
      Bus.on('logged-in', function () { self._authNotified = false; self.run({ manual: true }); });
      let debounce = null;
      Bus.on('data-changed', function (d) {
        self._emit();
        if (d && d.source === 'sync') return;
        clearTimeout(debounce);
        debounce = setTimeout(function () { self.run(); }, 3000);   // push soon after local changes
      });
      this._timer = setInterval(function () { if (!document.hidden) self.run(); }, 60000);
      this._emit();
      return this.run();
    },

    /* ---------- recording failures ---------- */
    async _fail(store, key, err, sum) {
      const code = err.code || 'ERROR';
      if (API.isNetworkError(err) || code === 'AUTH') throw err;
      if (code === 'GONE' && store === 'photos') { await Store.removePhotoLocal(key); return; }
      if (code === 'GONE' && store === 'reports') { await DB.del('reports', key); await DB.del('reportBlobs', key); return; }
      await DB.update(store, key, function (r) {
        if (!r) return null;
        if (code === 'CONFLICT' || code === 'DELETED_ON_SERVER') {
          const srv = err.data && (err.data.serverProject || err.data.serverFinding) || null;
          r._conflict = { kind: code === 'CONFLICT' ? (r._deleted ? 'delete-conflict' : 'conflict') : 'deleted', server: srv, at: iso() };
          r._syncError = { code: code, message: err.message, at: iso() };
          sum.conflicts++;
        } else if (WAIT_CODES.indexOf(code) !== -1) {
          r._syncError = { code: code, message: 'Waiting for the parent record to sync first.', waiting: true, at: iso() };
          sum.waiting++;
        } else {
          r._syncError = { code: code, message: err.message || 'Sync failed.', final: FINAL_CODES.indexOf(code) !== -1, at: iso() };
          sum.failed++;
        }
        return r;
      });
    },

    /* Sends ops in batches. op = { operationId, action, payload, onOk(data), onFail(error) } */
    async _sendOps(ops, sum) {
      for (let i = 0; i < ops.length; i += C.SYNC_BATCH_SIZE) {
        const chunk = ops.slice(i, i + C.SYNC_BATCH_SIZE);
        this._progress('Syncing changes (' + Math.min(i + chunk.length, ops.length) + ' of ' + ops.length + ')\u2026');
        const data = await this._call('syncBatch', {
          operations: chunk.map(function (o) { return { operationId: o.operationId, action: o.action, payload: o.payload }; })
        });
        const byId = {};
        (data.results || []).forEach(function (r) { byId[r.operationId] = r; });
        for (const op of chunk) {
          const r = byId[op.operationId];
          if (!r) await op.onFail({ code: 'SERVER_ERROR', message: 'The server did not answer this change.' });
          else if (r.ok) { sum.ok++; await op.onOk(r.data); }
          else await op.onFail(r.error || { code: 'SERVER_ERROR', message: 'Unknown error' });
        }
      }
    },

    /* ---------- PUSH ---------- */
    async _push(sum, manual) {
      await this._phaseRestore(sum, manual);
      await this._phaseSaves(sum, manual);
      await this._phasePhotoUploads(sum, manual);
      await this._phaseMetaAndDeletes(sum, manual);
      await this._phaseReports(sum, manual);
    },

    async _phaseRestore(sum, manual) {
      const self = this, ops = [];
      (await DB.getAll('projects')).forEach(function (p) {
        if (!p._restore || p._deleted || self._skip(p, manual)) return;
        ops.push({
          operationId: 'R' + p._op, action: 'restoreProject', payload: { projectId: p.project_id },
          onOk: function (d) {
            return DB.update('projects', p.project_id, function (r) {
              if (!r) return null;
              r.version = d.project.version; r._restore = false; r._syncError = null;
              return r;
            });
          },
          onFail: function (e) { return self._fail('projects', p.project_id, e, sum); }
        });
      });
      if (ops.length) await this._sendOps(ops, sum);
    },

    async _phaseSaves(sum, manual) {
      const self = this, ops = [];
      const projects = await DB.getAll('projects');
      const pById = {};
      projects.forEach(function (p) { pById[p.project_id] = p; });

      projects.forEach(function (p) {
        if (p._deleted || !p._dirty || p._restore || self._skip(p, manual)) return;
        const sentOp = p._op;
        ops.push({
          operationId: sentOp, action: 'saveProject',
          payload: { project: Store.projectPayload(p), baseVersion: p.version === null ? 0 : p.version },
          onOk: function (d) {
            return DB.update('projects', p.project_id, function (r) {
              if (!r) return null;
              const s = d.project;
              r.version = s.version; r.created_at = s.created_at; r.updated_at = s.updated_at;
              ['drive_folder_id', 'photos_folder_id', 'reports_folder_id', 'supporting_folder_id', 'latest_report_id'].forEach(function (k) { r[k] = s[k]; });
              r._syncError = null; r._conflict = null; r._stale = false;
              if (r._op === sentOp) r._dirty = false;     // edited again meanwhile? stay dirty
              return r;
            });
          },
          onFail: function (e) { return self._fail('projects', p.project_id, e, sum); }
        });
      });

      (await DB.getAll('findings')).forEach(function (f) {
        if (f._deleted || !f._dirty || self._skip(f, manual)) return;
        const parent = pById[f.project_id];
        if (!parent || parent._deleted) return;
        const sentOp = f._op;
        ops.push({
          operationId: sentOp, action: 'saveFinding',
          payload: { finding: Store.findingPayload(f), baseVersion: f.version === null ? 0 : f.version },
          onOk: function (d) {
            return DB.update('findings', f.finding_id, function (r) {
              if (!r) return null;
              const s = d.finding;
              r.version = s.version; r.created_at = s.created_at; r.updated_at = s.updated_at; r.drive_folder_id = s.drive_folder_id;
              r._syncError = null; r._conflict = null;
              if (r._op === sentOp) r._dirty = false;
              return r;
            });
          },
          onFail: function (e) { return self._fail('findings', f.finding_id, e, sum); }
        });
      });

      for (const p of projects) {
        if (p._deleted || !p._orderDirty || self._skip(p, manual)) continue;
        const order = (await Store.listFindings(p.project_id)).map(function (f) { return f.finding_id; });
        const sentOp = p._orderOp;
        ops.push({
          operationId: sentOp, action: 'reorderFindings', payload: { projectId: p.project_id, order: order },
          onOk: function () {
            return DB.update('projects', p.project_id, function (r) {
              if (!r) return null;
              if (r.version === null) return null;          // project itself did not sync: keep the flag
              if (r._orderOp === sentOp) r._orderDirty = false;
              return r;
            });
          },
          onFail: function (e) { return self._fail('projects', p.project_id, e, sum); }
        });
      }
      if (ops.length) await this._sendOps(ops, sum);
    },

    async _phasePhotoUploads(sum, manual) {
      const self = this;
      const pById = {}, fById = {};
      (await DB.getAll('projects')).forEach(function (p) { pById[p.project_id] = p; });
      (await DB.getAll('findings')).forEach(function (f) { fById[f.finding_id] = f; });
      const todo = (await DB.getAll('photos'))
        .filter(function (ph) { return !ph._deleted && !ph._uploaded && !self._skip(ph, manual); })
        .sort(function (a, b) { return String(a.captured_at).localeCompare(String(b.captured_at)); })
        .filter(function (ph) {
          const f = fById[ph.finding_id], p = pById[ph.project_id];
          if (!f || f._deleted || !p || p._deleted) return false;
          if (f.version === null || p.version === null) { sum.waiting++; return false; }   // parent not on server yet
          return true;
        });
      for (let i = 0; i < todo.length; i++) {
        this._progress('Uploading photo ' + (i + 1) + ' of ' + todo.length + '\u2026');
        await this._uploadOne(todo[i].photo_id, sum);
      }
    },

    async _uploadOne(photoId, sum) {
      const ph = await DB.get('photos', photoId);
      if (!ph || ph._deleted || ph._uploaded) return;
      const blobRec = await DB.get('photoBlobs', photoId);
      if (!blobRec || !blobRec.blob) {
        await DB.update('photos', photoId, function (r) {
          if (r) r._syncError = { code: 'BLOB_MISSING', message: 'The photo file is missing on this phone. Remove it and take the photo again.', final: true, at: iso() };
          return r;
        });
        sum.failed++;
        return;
      }
      const sentHash = ph.content_hash;
      const opId = 'U' + photoId.replace(/[^A-Za-z0-9]/g, '') + sentHash.slice(0, 12);
      try {
        const b64 = await Photos.blobToBase64(blobRec.blob);
        const d = await this._call('uploadPhoto', { photo: Store.photoPayload(ph), dataBase64: b64 },
          { operationId: opId, timeoutMs: C.UPLOAD_TIMEOUT_MS });
        sum.ok++;
        let found = true;
        await DB.update('photos', photoId, function (r) {
          if (!r) { found = false; return null; }
          r.drive_file_id = d.photo.drive_file_id; r.drive_url = d.photo.drive_url; r._syncError = null;
          if (r.content_hash === sentHash) r._uploaded = true;       // replaced again meanwhile? upload again
          if (r._uploaded && (r.caption !== d.photo.caption || r.stage !== d.photo.stage)) { r._metaDirty = true; r._metaOp = Store.newOp('m'); }
          return r;
        });
        if (!found) {
          // The user removed the photo while it was uploading: tell the server so no orphan is left.
          try { await this._call('deletePhoto', { photoId: photoId }, { operationId: 'D' + opId.slice(1, 40) }); }
          catch (e) { if (API.isNetworkError(e)) throw e; }
        }
      } catch (e) {
        await this._fail('photos', photoId, e, sum);
      }
    },

    async _phaseMetaAndDeletes(sum, manual) {
      const self = this, ops = [];

      for (const ph of await DB.getAll('photos')) {
        if (ph._deleted) {
          if (!ph.drive_file_id) { await Store.removePhotoLocal(ph.photo_id); continue; }
          if (self._skip(ph, manual)) continue;
          ops.push({
            operationId: 'D' + ph._op, action: 'deletePhoto', payload: { photoId: ph.photo_id },
            onOk: function () { return Store.removePhotoLocal(ph.photo_id); },
            onFail: function (e) { return self._fail('photos', ph.photo_id, e, sum); }
          });
        } else if (ph._uploaded && ph._metaDirty && !self._skip(ph, manual)) {
          const sentOp = ph._metaOp;
          ops.push({
            operationId: sentOp, action: 'savePhotoMeta',
            payload: { photo: { photo_id: ph.photo_id, stage: ph.stage, caption: ph.caption, sort_order: ph.sort_order } },
            onOk: function () {
              return DB.update('photos', ph.photo_id, function (r) {
                if (!r) return null;
                r._syncError = null;
                if (r._metaOp === sentOp) r._metaDirty = false;
                return r;
              });
            },
            onFail: function (e) { return self._fail('photos', ph.photo_id, e, sum); }
          });
        }
      }

      for (const r of await DB.getAll('reports')) {
        if (!r._deleted || self._skip(r, manual)) continue;
        ops.push({
          operationId: 'D' + r._op, action: 'deleteReport', payload: { reportId: r.report_id },
          onOk: async function () { await DB.del('reports', r.report_id); await DB.del('reportBlobs', r.report_id); },
          onFail: function (e) { return self._fail('reports', r.report_id, e, sum); }
        });
      }
      for (const f of await DB.getAll('findings')) {
        if (!f._deleted || self._skip(f, manual)) continue;
        ops.push({
          operationId: 'D' + f._op, action: 'deleteFinding', payload: { findingId: f.finding_id },
          onOk: function () { return Store.removeFindingLocal(f.finding_id); },
          onFail: function (e) { return self._fail('findings', f.finding_id, e, sum); }
        });
      }
      for (const p of await DB.getAll('projects')) {
        if (!p._deleted || self._skip(p, manual)) continue;
        ops.push({
          operationId: 'D' + p._op, action: 'deleteProject', payload: { projectId: p.project_id, baseVersion: p.version },
          onOk: function () { return Store.removeProjectLocal(p.project_id); },
          onFail: function (e) { return self._fail('projects', p.project_id, e, sum); }
        });
      }
      if (ops.length) await this._sendOps(ops, sum);
    },

    async _phaseReports(sum, manual) {
      const self = this;
      const pById = {};
      (await DB.getAll('projects')).forEach(function (p) { pById[p.project_id] = p; });
      const todo = (await DB.getAll('reports')).filter(function (r) {
        if (r._deleted || r._uploaded || self._skip(r, manual)) return false;
        const p = pById[r.project_id];
        if (!p || p._deleted) return false;
        if (p.version === null) { sum.waiting++; return false; }
        return true;
      });
      for (let i = 0; i < todo.length; i++) {
        const rep = todo[i];
        this._progress('Uploading report ' + (i + 1) + ' of ' + todo.length + '\u2026');
        const blobRec = await DB.get('reportBlobs', rep.report_id);
        if (!blobRec || !blobRec.blob) {
          await DB.update('reports', rep.report_id, function (r) {
            if (r) r._syncError = { code: 'BLOB_MISSING', message: 'The report file is missing on this phone. Generate it again.', final: true, at: iso() };
            return r;
          });
          sum.failed++;
          continue;
        }
        const opId = 'P' + rep.report_id.replace(/[^A-Za-z0-9]/g, '') + rep.content_hash.slice(0, 12);
        try {
          const b64 = await Photos.blobToBase64(blobRec.blob);
          const d = await this._call('uploadReport', {
            report: { report_id: rep.report_id, project_id: rep.project_id, file_name: rep.file_name,
              project_version: rep.project_version || 0, content_hash: rep.content_hash, generated_at: rep.generated_at },
            dataBase64: b64
          }, { operationId: opId, timeoutMs: C.UPLOAD_TIMEOUT_MS });
          sum.ok++;
          await DB.update('reports', rep.report_id, function (r) {
            if (!r) return null;
            r.drive_file_id = d.report.drive_file_id; r.drive_url = d.report.drive_url; r._uploaded = true; r._syncError = null;
            return r;
          });
          await DB.update('projects', rep.project_id, function (r) {
            if (!r) return null;
            r.latest_report_id = d.latest_report_id || rep.report_id;
            return r;
          });
        } catch (e) {
          await this._fail('reports', rep.report_id, e, sum);
        }
      }
    },

    /* ---------- PULL ---------- */
    async _pull(sum) {
      const data = await this._call('listProjects', {});
      const serverIds = {};
      for (const s of data.projects) {
        serverIds[s.project_id] = true;
        await this._mergeSummary(s);
      }
      // Projects the server no longer lists were deleted elsewhere.
      for (const p of await DB.getAll('projects')) {
        if (serverIds[p.project_id] || p.version === null || p._deleted) continue;
        if (!p._dirty && !(await Store.hasPendingChildren(p.project_id))) {
          await Store.removeProjectLocal(p.project_id);
        } else {
          await DB.update('projects', p.project_id, function (r) {
            if (!r || r._conflict) return null;
            r._conflict = { kind: 'deleted', server: null, at: iso() };
            r._syncError = { code: 'DELETED_ON_SERVER', message: 'This project was deleted on another device.', at: iso() };
            sum.conflicts++;
            return r;
          });
        }
      }
      // Refresh up to 10 projects that changed elsewhere and have no unsynced local edits.
      let n = 0;
      for (const p of await DB.getAll('projects')) {
        if (n >= 10) break;
        if (p._stale && !p._dirty && !p._deleted && !p._conflict) { n++; await this.fetchProject(p.project_id); }
      }
      Bus.emit('data-changed', { kind: 'list', id: null, source: 'sync' });
    },

    async _mergeSummary(s) {
      const local = await DB.get('projects', s.project_id);
      if (!local) {
        const rec = Object.assign(Store.projectFlags(), {
          general_notes: '', overall_condition: '', executive_summary: '', overall_recommendations: ''
        }, s, { _full: false });
        await DB.put('projects', rec);
        return;
      }
      if (local._deleted || local._dirty) return;
      if (s.version > (local.version || 0)) {
        // Do NOT adopt the new version yet: the long text fields are missing from summaries.
        await DB.update('projects', s.project_id, function (r) { if (!r) return null; r._stale = true; r._serverVersion = s.version; return r; });
      } else if (!local._full) {
        await DB.update('projects', s.project_id, function (r) {
          if (!r) return null;
          r.finding_count = s.finding_count; r.photo_count = s.photo_count; r.latest_report_url = s.latest_report_url;
          return r;
        });
      }
    },

    /* Downloads the full project (findings, photo details, reports) and merges it locally. */
    async fetchProject(projectId) {
      try {
        const bundle = await this._call('getProject', { projectId: projectId });
        await Store.applyBundle(bundle);
        return bundle;
      } catch (e) {
        if (e.code === 'NOT_FOUND') {
          const p = await DB.get('projects', projectId);
          if (p && !p._dirty && p.version !== null && !(await Store.hasPendingChildren(projectId))) await Store.removeProjectLocal(projectId);
        }
        throw e;
      }
    },

    async refreshSettings() {
      const d = await this._call('getSettings', {});
      Object.keys(d.enums || {}).forEach(function (k) { if (Array.isArray(d.enums[k])) window.APP_ENUMS[k] = d.enums[k]; });
      await DB.meta.set('settingsCache', { settings: d.settings, logo: d.logo, fetchedAt: iso() });
      Bus.emit('settings-updated', d);
      return d;
    },

    /* ---------- retry ---------- */
    async retryFailed() {
      for (const store of ['projects', 'findings', 'photos', 'reports']) {
        for (const r of await DB.getAll(store)) {
          if (r._syncError && !r._conflict) {
            await DB.update(store, r[store === 'projects' ? 'project_id' : store === 'findings' ? 'finding_id' : store === 'photos' ? 'photo_id' : 'report_id'],
              function (x) { if (!x) return null; x._syncError = null; return x; });
          }
        }
      }
      return this.run({ manual: true });
    },

    /* ---------- conflict resolution ----------
       entity: 'project' | 'finding'      choice: 'mine' | 'server' | 'copy'
       Nothing is lost: "mine" re-sends your version on top of the server's, "server" adopts the
       server's version, "copy" keeps yours as a brand-new record and then adopts the server's. */
    async resolveConflict(entity, id, choice) {
      const store = entity === 'project' ? 'projects' : 'findings';
      const rec = await DB.get(store, id);
      if (!rec || !rec._conflict) return {};
      const c = rec._conflict, srv = c.server;
      const result = {};

      const adoptServer = function () {
        return DB.update(store, id, function (r) {
          if (!r || !srv) return null;
          return entity === 'project'
            ? Object.assign(Store.projectFlags(), srv, { _full: r._full, _stale: true })
            : Object.assign(Store.findingFlags(), srv);
        });
      };
      const markMine = function (extra) {
        return DB.update(store, id, function (r) {
          if (!r) return null;
          r._conflict = null; r._syncError = null; r._op = Store.newOp();
          Object.assign(r, extra || {});
          return r;
        });
      };

      if (entity === 'project') {
        if (c.kind === 'conflict') {
          if (choice === 'mine') await markMine({ version: srv.version, _dirty: true });
          else if (choice === 'server') await adoptServer();
          else if (choice === 'copy') { const cp = await Store.copyProject(id); result.copyId = cp.project.project_id; await adoptServer(); }
        } else if (c.kind === 'deleted') {
          if (choice === 'mine') await markMine(Object.assign({ _restore: true, _dirty: true }, srv ? { version: srv.version } : {}));
          else if (choice === 'server') await Store.removeProjectLocal(id);
          else if (choice === 'copy') { const cp = await Store.copyProject(id); result.copyId = cp.project.project_id; await Store.removeProjectLocal(id); }
        } else if (c.kind === 'delete-conflict') {
          if (choice === 'mine') await markMine(srv ? { version: srv.version } : {});   // delete anyway
          else await adoptServer();                                                       // keep the project
        }
      } else {
        if (c.kind === 'conflict') {
          if (choice === 'mine') await markMine({ version: srv.version, _dirty: true });
          else if (choice === 'server') await adoptServer();
          else if (choice === 'copy') { const cp = await Store.copyFinding(id); result.copyId = cp.finding.finding_id; await adoptServer(); }
        } else if (c.kind === 'deleted') {
          // A deleted finding cannot be un-deleted on the server, so "mine" keeps it as a new finding.
          if (choice === 'server') await Store.removeFindingLocal(id);
          else { const cp = await Store.copyFinding(id); result.copyId = cp.finding.finding_id; await Store.removeFindingLocal(id); }
        } else if (c.kind === 'delete-conflict') {
          if (choice === 'mine') await markMine(srv ? { version: srv.version } : {});
          else await adoptServer();
        }
      }
      Bus.emit('data-changed', { kind: entity, id: id });
      this.run({ manual: true });
      return result;
    }
  };

  window.Sync = Sync;
})();
