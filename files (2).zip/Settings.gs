/**
 * Marble Site Audit - Settings.gs  (NEW file, not in the Part A list)
 * Company details, disclaimer text and logo used by the PDF report.
 */

const EDITABLE_SETTINGS = ['company_name', 'report_title', 'company_address', 'company_phone',
  'company_email', 'default_inspector', 'report_disclaimer'];

function getSettingsMap_() {
  const map = {};
  readAllRows_(SHEETS.SETTINGS).rows.forEach(function (r) { map[r.key] = r.value; });
  return map;
}

function setSetting_(key, value) {
  const row = findRowById_(SHEETS.SETTINGS, 'key', key);
  if (row) { row.value = value; writeRowObj_(SHEETS.SETTINGS, row._row, row); }
  else appendRowObj_(SHEETS.SETTINGS, { key: key, value: value, description: '' });
}

/** Returns settings, the allowed dropdown lists, and the logo (as base64) if one is set. */
function apiGetSettings_() {
  const settings = getSettingsMap_();
  let logo = null;
  try {
    const file = getFileSafe_(settings.logo_file_id);
    if (file && file.getSize() <= 1500000) {
      logo = { mime_type: file.getMimeType(), dataBase64: Utilities.base64Encode(file.getBlob().getBytes()) };
    }
  } catch (e) { console.warn('Logo not loaded: ' + e.message); }
  return {
    settings: settings,
    logo: logo,
    enums: ENUMS,
    required: { project: REQUIRED_PROJECT_FIELDS, finding: REQUIRED_FINDING_FIELDS },
    appVersion: CONFIG.APP_VERSION
  };
}

/** payload: { settings:{ key: value, ... } } (only keys in EDITABLE_SETTINGS are accepted) */
function apiSaveSettings_(p) {
  const input = p.settings;
  if (!input || typeof input !== 'object') throw apiError_('VALIDATION', 'Settings are missing.');
  const errors = {}, clean = {};
  EDITABLE_SETTINGS.forEach(function (k) {
    if (has_(input, k)) clean[k] = cleanText_(input[k], k === 'report_disclaimer' ? MAX_LONG : MAX_SHORT, k, errors);
  });
  throwIfErrors_(errors);
  Object.keys(clean).forEach(function (k) { setSetting_(k, clean[k]); });
  return { settings: getSettingsMap_() };
}

/** payload: { mime_type:'image/png'|'image/jpeg', dataBase64 }  (max 1 MB). Stored in your root folder. */
function apiUploadLogo_(p) {
  const mime = String(p.mime_type || '');
  if (mime !== 'image/png' && mime !== 'image/jpeg') throw apiError_('VALIDATION', 'The logo must be a PNG or JPEG image.');
  const bytes = decodeBase64_(p.dataBase64, 1024 * 1024);
  const old = getFileSafe_(getSettingsMap_().logo_file_id);
  const file = getRootFolder_().createFile(
    Utilities.newBlob(bytes, mime, 'Company Logo.' + (mime === 'image/png' ? 'png' : 'jpg')));
  if (old) { try { old.setTrashed(true); } catch (e) { console.warn('Old logo not trashed: ' + e.message); } }
  setSetting_('logo_file_id', file.getId());
  return { logo_file_id: file.getId() };
}
