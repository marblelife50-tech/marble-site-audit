/**
 * Marble Site Audit - Setup.gs
 * Run these from the Apps Script editor (never called by the web app):
 *   1. setupAll()      - creates tabs, headers and default settings (safe to re-run)
 *   2. setAccessCode() - sets your login code (edit the code first, run, then erase it)
 *   3. verifySetup()   - checks that everything works
 */

// ---------- 1. Create / repair the spreadsheet ----------
function setupAll() {
  const ss = getSpreadsheet_();
  const names = Object.keys(SCHEMA);

  names.forEach(function (name) { ensureSheet_(ss, name, SCHEMA[name]); });

  // Remove the empty default sheet if it is still there.
  const def = ss.getSheetByName('Sheet1') || ss.getSheetByName('Sheet 1');
  if (def && def.getLastRow() === 0 && ss.getSheets().length > 1) ss.deleteSheet(def);

  ensureDefaultSettings_();
  getRootFolder_(); // throws a clear error if the folder ID is wrong

  Logger.log('Setup complete. Tabs: ' + names.join(', '));
  return 'Setup complete';
}

/** Creates a tab if missing, adds any missing headers at the END (never deletes or reorders). */
function ensureSheet_(ss, name, columns) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);

  let headers = [];
  if (sh.getLastColumn() > 0) {
    headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
    while (headers.length && headers[headers.length - 1] === '') headers.pop();
  }

  const missing = columns.map(function (c) { return c[0]; })
    .filter(function (h) { return headers.indexOf(h) === -1; });

  if (missing.length) {
    const needed = headers.length + missing.length;
    if (sh.getMaxColumns() < needed) sh.insertColumnsAfter(sh.getMaxColumns(), needed - sh.getMaxColumns());
    sh.getRange(1, headers.length + 1, 1, missing.length).setValues([missing]);
    headers = headers.concat(missing);
  }

  // Formatting: plain text for text columns, frozen bold header row.
  columns.forEach(function (c) {
    const idx = headers.indexOf(c[0]);
    if (idx === -1) return;
    const col = sh.getRange(2, idx + 1, Math.max(sh.getMaxRows() - 1, 1), 1);
    col.setNumberFormat(c[1] === 't' ? '@' : (c[0] === 'estimated_area_sqm' ? '0.00' : '0'));
  });
  sh.getRange(1, 1, 1, headers.length).setFontWeight('bold').setBackground('#e8e1d5');
  sh.setFrozenRows(1);
  return sh;
}

/** Adds default settings only when the key does not exist yet (never overwrites your edits). */
function ensureDefaultSettings_() {
  const sh = getSheet_(SHEETS.SETTINGS);
  const last = sh.getLastRow();
  const existing = last > 1 ? sh.getRange(2, 1, last - 1, 1).getValues().map(function (r) { return String(r[0]); }) : [];

  const defaults = [
    ['company_name', 'Marblelife Gulf', 'Shown in the PDF header'],
    ['report_title', 'Marble Restoration Site Audit Report', 'Title on the PDF cover'],
    ['company_address', 'Dubai, UAE', 'Shown in the PDF footer (edit freely)'],
    ['company_phone', '', 'Shown in the PDF footer'],
    ['company_email', '', 'Shown in the PDF footer'],
    ['logo_file_id', '', 'Drive file ID of your logo PNG/JPG (leave blank for a text placeholder)'],
    ['default_inspector', '', 'Pre-filled inspector name on new projects'],
    ['report_disclaimer',
      'This report is based on a visual inspection carried out on the date shown and reflects ' +
      'conditions visible at that time. Statements about possible causes are the inspector\'s ' +
      'assessment and are not confirmed facts unless stated otherwise. Estimated areas are ' +
      'approximate and must be verified before quotation. Hidden defects, sub-surface conditions ' +
      'and results of laboratory testing are outside the scope of this inspection. Recommended ' +
      'methods may change after on-site trials. This report does not constitute a warranty or ' +
      'guarantee of any kind.',
      'Printed in the PDF under Limitations and Disclaimer'],
    ['schema_version', String(CONFIG.SCHEMA_VERSION), 'Do not edit'],
    ['timezone', CONFIG.TIMEZONE, 'Used for dates in the PDF']
  ];

  const toAdd = defaults.filter(function (d) { return existing.indexOf(d[0]) === -1; });
  if (toAdd.length) sh.getRange(last + 1, 1, toAdd.length, 3).setValues(toAdd);
}

// ---------- 2. Access code ----------
/**
 * HOW TO USE:
 *  a) Replace TYPE-YOUR-CODE-HERE with a code of at least 10 characters.
 *  b) Run setAccessCode() once.
 *  c) Change the line back to 'TYPE-YOUR-CODE-HERE' so the code is not left in your script.
 * Running it again later changes the code AND logs out every device.
 * Only a salted hash is stored (in Script Properties), never the code itself.
 */
function setAccessCode() {
  const NEW_CODE = 'TYPE-YOUR-CODE-HERE';

  if (NEW_CODE === 'TYPE-YOUR-CODE-HERE') throw new Error('Edit NEW_CODE in setAccessCode() first.');
  if (NEW_CODE.length < 10) throw new Error('The access code must be at least 10 characters.');

  const salt = Utilities.getUuid();
  PropertiesService.getScriptProperties().setProperties({
    ACCESS_SALT: salt,
    ACCESS_HASH: hashAccessCode_(NEW_CODE, salt),
    SESSION_SECRET: Utilities.getUuid() + Utilities.getUuid(), // new secret = old sessions stop working
    FAILED_LOGINS: '0',
    LOCKED_UNTIL: '0'
  });
  Logger.log('Access code saved. Now change NEW_CODE back to the placeholder.');
}

/** Salted, repeated SHA-256 (300 rounds: kept low because Apps Script calls are slow; logins are rate-limited). Auth.gs (Part C) reuses this function; do not redefine it there. */
function hashAccessCode_(code, salt) {
  let h = salt + ':' + code;
  for (let i = 0; i < 300; i++) {
    h = bytesToHex_(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, h + salt));
  }
  return h;
}

function bytesToHex_(bytes) {
  return bytes.map(function (b) { return ('0' + (b & 0xff).toString(16)).slice(-2); }).join('');
}

// ---------- 3. Self-check ----------
function verifySetup() {
  const problems = [];
  const ok = [];

  try {
    const ss = getSpreadsheet_();
    Object.keys(SCHEMA).forEach(function (name) {
      const sh = ss.getSheetByName(name);
      if (!sh) { problems.push('Missing tab: ' + name); return; }
      const headers = sh.getRange(1, 1, 1, Math.max(sh.getLastColumn(), 1)).getValues()[0].map(String);
      const missing = SCHEMA[name].map(function (c) { return c[0]; })
        .filter(function (h) { return headers.indexOf(h) === -1; });
      if (missing.length) problems.push(name + ' is missing columns: ' + missing.join(', '));
      else ok.push('Tab OK: ' + name);
    });
  } catch (e) { problems.push('Spreadsheet: ' + e.message); }

  try {
    const root = getRootFolder_();
    const test = root.createFolder('_write_test');
    test.setTrashed(true);
    ok.push('Drive folder OK: ' + root.getName());
  } catch (e) { problems.push('Drive folder: ' + e.message); }

  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty('ACCESS_HASH')) problems.push('Access code not set. Run setAccessCode().');
  else ok.push('Access code is set');

  ok.concat(problems.map(function (p) { return 'PROBLEM: ' + p; })).forEach(function (l) { Logger.log(l); });
  if (problems.length) throw new Error('Setup problems found:\n- ' + problems.join('\n- '));
  Logger.log('ALL CHECKS PASSED');
  return 'ALL CHECKS PASSED';
}
