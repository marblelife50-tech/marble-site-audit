/**
 * Marble Site Audit - Db.gs  (NEW file, not in the Part A list)
 * Low-level helpers for reading and writing rows by column NAME.
 * No other file touches sheet columns by position, so column order never matters.
 */

const _tableCache_ = {};

function getTable_(name) {
  if (_tableCache_[name]) return _tableCache_[name];
  const sh = getSheet_(name);
  const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
  const types = {};
  (SCHEMA[name] || []).forEach(function (c) { types[c[0]] = c[1]; });
  _tableCache_[name] = { name: name, sh: sh, headers: headers, types: types };
  return _tableCache_[name];
}

function rowToObj_(t, arr) {
  const o = {};
  t.headers.forEach(function (h, i) {
    let v = arr[i];
    if (t.types[h] === 'n') {
      v = (v === '' || v === null || v === undefined) ? null : Number(v);
      if (v !== null && isNaN(v)) v = null;
    } else {
      v = (v === null || v === undefined) ? '' : String(v);
    }
    o[h] = v;
  });
  return o;
}

/** Reads every data row. Each object carries _row (its sheet row number). */
function readAllRows_(name) {
  const t = getTable_(name);
  const last = t.sh.getLastRow();
  const rows = [];
  if (last >= 2) {
    t.sh.getRange(2, 1, last - 1, t.headers.length).getValues().forEach(function (arr, i) {
      const o = rowToObj_(t, arr);
      o._row = i + 2;
      rows.push(o);
    });
  }
  return { table: t, rows: rows };
}

/** Finds one row by its ID column. Returns an object (with _row) or null. */
function findRowById_(name, idField, id) {
  const t = getTable_(name);
  const last = t.sh.getLastRow();
  if (last < 2 || !id) return null;
  const col = t.headers.indexOf(idField) + 1;
  const ids = t.sh.getRange(2, col, last - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) {
    if (String(ids[i][0]) === id) {
      const o = rowToObj_(t, t.sh.getRange(i + 2, 1, 1, t.headers.length).getValues()[0]);
      o._row = i + 2;
      return o;
    }
  }
  return null;
}

function blankRow_(name) {
  const t = getTable_(name);
  const o = {};
  t.headers.forEach(function (h) { o[h] = (t.types[h] === 'n') ? null : ''; });
  return o;
}

/** Writes a whole row, forcing the right number format (so text stays text, e.g. +971 numbers). */
function writeRowObj_(name, rowNum, obj) {
  const t = getTable_(name);
  const vals = [], fmts = [];
  t.headers.forEach(function (h) {
    const isNum = t.types[h] === 'n';
    let v = obj[h];
    if (v === undefined || v === null) v = '';
    vals.push(isNum ? v : String(v));
    fmts.push(isNum ? (h === 'estimated_area_sqm' ? '0.00' : '0') : '@');
  });
  const range = t.sh.getRange(rowNum, 1, 1, t.headers.length);
  range.setNumberFormats([fmts]);
  range.setValues([vals]);
}

function appendRowObj_(name, obj) {
  const t = getTable_(name);
  const row = t.sh.getLastRow() + 1;
  if (row > t.sh.getMaxRows()) t.sh.insertRowsAfter(t.sh.getMaxRows(), 100);
  writeRowObj_(name, row, obj);
  obj._row = row;
  return row;
}

/** Copy of a row object without internal fields, safe to send to the phone. */
function pub_(o) {
  const c = {};
  Object.keys(o).forEach(function (k) { if (k !== '_row') c[k] = o[k]; });
  return c;
}

function newId_(kind) {
  const map = {
    project: ['PRJ', 6, SHEETS.PROJECTS, 'project_id'],
    finding: ['FND', 6, SHEETS.FINDINGS, 'finding_id'],
    photo:   ['PHT', 8, SHEETS.PHOTOS, 'photo_id'],
    report:  ['RPT', 6, SHEETS.REPORTS, 'report_id']
  }[kind];
  const date = Utilities.formatDate(new Date(), 'UTC', 'yyyyMMdd');
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let id;
  do {
    let s = '';
    for (let i = 0; i < map[1]; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
    id = map[0] + '-' + date + '-' + s;
  } while (findRowById_(map[2], map[3], id));
  return id;
}

function sha256Hex_(bytes) {
  return bytesToHex_(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, bytes));
}

/** Marks matching rows deleted. All rows in one cascade share the same deleted_at (used for restore). */
function softDeleteWhere_(name, field, value, ts) {
  let n = 0;
  readAllRows_(name).rows.forEach(function (r) {
    if (r[field] === value && r.deleted !== 'Y') {
      r.deleted = 'Y';
      r.deleted_at = ts;
      if ('updated_at' in r) r.updated_at = ts;
      writeRowObj_(name, r._row, r);
      n++;
    }
  });
  return n;
}

/** Restores only rows that were deleted by the same cascade (same deleted_at). */
function restoreWhere_(name, field, value, ts) {
  let n = 0;
  readAllRows_(name).rows.forEach(function (r) {
    if (r[field] === value && r.deleted === 'Y' && r.deleted_at === ts) {
      r.deleted = '';
      r.deleted_at = '';
      if ('updated_at' in r) r.updated_at = nowIso_();
      writeRowObj_(name, r._row, r);
      n++;
    }
  });
  return n;
}

function bySortOrder_(a, b) {
  const x = a.sort_order === null ? 1e9 : a.sort_order;
  const y = b.sort_order === null ? 1e9 : b.sort_order;
  if (x !== y) return x - y;
  return String(a.created_at || a.uploaded_at || '').localeCompare(String(b.created_at || b.uploaded_at || ''));
}
