/**
 * Marble Site Audit - DriveFolders.gs
 * Creates:  Root / "PRJ-... - Name" / Photos / "FND-... - Area"
 *                                   / Reports
 *                                   / Supporting Documents
 * Folder IDs always come from the Sheet (never from the phone), and everything lives
 * under your root folder. Existing folders are reused, so no duplicates are created.
 */

function safeName_(s, max) {
  const t = String(s || '').replace(/[\\\/:*?"<>|\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max || 60);
  return t || 'Untitled';
}

function projectFolderName_(p) { return p.project_id + ' - ' + safeName_(p.project_name, 60); }
function findingFolderName_(f) { return f.finding_id + ' - ' + safeName_(f.area_location, 50); }

function getFolderSafe_(id) {
  if (!id) return null;
  try {
    const f = DriveApp.getFolderById(id);
    return f.isTrashed() ? null : f;
  } catch (e) { return null; }
}

function getFileSafe_(id) {
  if (!id) return null;
  try {
    const f = DriveApp.getFileById(id);
    return f.isTrashed() ? null : f;
  } catch (e) { return null; }
}

function ensureSubFolder_(parent, id, name) {
  const existing = getFolderSafe_(id);
  if (existing) return existing;
  const it = parent.getFoldersByName(name);
  while (it.hasNext()) {
    const c = it.next();
    if (!c.isTrashed()) return c;
  }
  return parent.createFolder(name);
}

/** Makes sure the project folder and its 3 sub-folders exist. Returns their IDs. */
function ensureProjectFolders_(proj) {
  let main = getFolderSafe_(proj.drive_folder_id);
  if (!main) {
    const root = getRootFolder_();
    const it = root.searchFolders('title contains "' + proj.project_id + '" and trashed = false');
    main = it.hasNext() ? it.next() : root.createFolder(projectFolderName_(proj));
  }
  return {
    drive_folder_id: main.getId(),
    photos_folder_id: ensureSubFolder_(main, proj.photos_folder_id, 'Photos').getId(),
    reports_folder_id: ensureSubFolder_(main, proj.reports_folder_id, 'Reports').getId(),
    supporting_folder_id: ensureSubFolder_(main, proj.supporting_folder_id, 'Supporting Documents').getId()
  };
}

/** Same as above for a project that already has a row; saves any changed IDs back to the sheet. */
function ensureProjectFoldersSaved_(proj) {
  const ids = ensureProjectFolders_(proj);
  let changed = false;
  Object.keys(ids).forEach(function (k) { if (proj[k] !== ids[k]) { proj[k] = ids[k]; changed = true; } });
  if (changed) writeRowObj_(SHEETS.PROJECTS, proj._row, proj);
  return proj;
}

/** Returns the Drive folder for a finding's photos (creating it if needed). Caller saves its ID. */
function ensureFindingFolder_(proj, finding) {
  let photos = getFolderSafe_(proj.photos_folder_id);
  if (!photos) {
    proj = ensureProjectFoldersSaved_(proj);
    photos = getFolderSafe_(proj.photos_folder_id);
  }
  const existing = getFolderSafe_(finding.drive_folder_id);
  if (existing) return existing;
  const it = photos.searchFolders('title contains "' + finding.finding_id + '" and trashed = false');
  return it.hasNext() ? it.next() : photos.createFolder(findingFolderName_(finding));
}

/** Renaming is cosmetic; failure must never block a save. */
function tryRenameFolder_(id, newName) {
  try {
    const f = getFolderSafe_(id);
    if (f && f.getName() !== newName) f.setName(newName);
  } catch (e) { console.warn('Folder rename failed: ' + e.message); }
}
