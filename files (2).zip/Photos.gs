/**
 * Marble Site Audit - Photos.gs
 * One photo per request. photo_id is the duplicate-prevention key: uploading the same
 * photo_id again never creates a second Drive file. content_hash (SHA-256 of the exact
 * bytes) verifies the upload arrived intact and detects a replaced image.
 */

const PHOTO_MIMES = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };

function decodeBase64_(b64, maxBytes) {
  if (typeof b64 !== 'string' || !b64) throw apiError_('VALIDATION', 'No file data was received.');
  b64 = b64.replace(/^data:[^,]*,/, '');
  if (b64.length * 0.75 > maxBytes * 1.02) throw apiError_('TOO_LARGE', 'The file is too large (limit ' + Math.round(maxBytes / 1048576) + ' MB).');
  let bytes;
  try { bytes = Utilities.base64Decode(b64); }
  catch (e) { throw apiError_('VALIDATION', 'The file data is not valid.'); }
  if (bytes.length > maxBytes) throw apiError_('TOO_LARGE', 'The file is too large (limit ' + Math.round(maxBytes / 1048576) + ' MB).');
  return bytes;
}

/**
 * payload: { photo:{photo_id, project_id, finding_id, stage, caption, sort_order, file_name,
 *            mime_type, width, height, content_hash, captured_at}, dataBase64 }
 * Uploading an existing photo_id with different bytes REPLACES the image (old file goes to Drive trash).
 */
function apiUploadPhoto_(p, ctx) {
  const meta = cleanPhotoMeta_(p.photo, true);
  if (!PHOTO_MIMES[meta.mime_type]) throw apiError_('VALIDATION', 'Only JPEG, PNG or WebP photos are allowed.');

  const bytes = decodeBase64_(p.dataBase64, CONFIG.MAX_PHOTO_BYTES);
  const hash = sha256Hex_(bytes);
  if (hash !== meta.content_hash) throw apiError_('HASH_MISMATCH', 'The photo was damaged during upload. Please retry.');

  const proj = findRowById_(SHEETS.PROJECTS, 'project_id', meta.project_id);
  if (!proj || proj.deleted === 'Y') throw apiError_('PROJECT_MISSING', 'The project is not on the server (or was deleted).');
  const finding = findRowById_(SHEETS.FINDINGS, 'finding_id', meta.finding_id);
  if (!finding || finding.deleted === 'Y') throw apiError_('FINDING_MISSING', 'The finding is not on the server (or was deleted).');
  if (finding.project_id !== meta.project_id) throw apiError_('VALIDATION', 'The finding belongs to a different project.');

  const existing = findRowById_(SHEETS.PHOTOS, 'photo_id', meta.photo_id);
  let oldFile = null;
  const now = nowIso_();

  if (existing) {
    if (existing.deleted === 'Y') throw apiError_('GONE', 'This photo was deleted on the server.');
    if (existing.project_id !== meta.project_id || existing.finding_id !== meta.finding_id) {
      throw apiError_('VALIDATION', 'This photo ID is already used by a different finding.');
    }
    const file = getFileSafe_(existing.drive_file_id);
    if (file && existing.content_hash === hash) {
      // Already uploaded: only refresh caption/stage/order if they changed.
      let changed = false;
      ['stage', 'caption', 'sort_order'].forEach(function (k) {
        if (existing[k] !== meta[k]) { existing[k] = meta[k]; changed = true; }
      });
      if (changed) { existing.updated_at = now; writeRowObj_(SHEETS.PHOTOS, existing._row, existing); }
      return { photo: pub_(existing), deduped: true };
    }
    oldFile = file;
  }

  let folder;
  try {
    folder = ensureFindingFolder_(proj, finding);
    if (finding.drive_folder_id !== folder.getId()) {
      finding.drive_folder_id = folder.getId();
      writeRowObj_(SHEETS.FINDINGS, finding._row, finding);
    }
  } catch (e) { throw apiError_('DRIVE_ERROR', 'Could not open the Drive folder: ' + e.message); }

  let file;
  try {
    const name = meta.photo_id + '_' + meta.stage + '.' + PHOTO_MIMES[meta.mime_type];
    file = folder.createFile(Utilities.newBlob(bytes, meta.mime_type, name));
    file.setDescription('photo_id=' + meta.photo_id + '; finding_id=' + meta.finding_id + '; project_id=' + meta.project_id);
  } catch (e) { throw apiError_('DRIVE_ERROR', 'Could not save the photo to Drive: ' + e.message); }
  if (oldFile) { try { oldFile.setTrashed(true); } catch (e) { console.warn('Old photo not trashed: ' + e.message); } }

  const row = existing || blankRow_(SHEETS.PHOTOS);
  const sameFindingPhotos = readAllRows_(SHEETS.PHOTOS).rows
    .filter(function (r) { return r.finding_id === meta.finding_id && r.deleted !== 'Y'; }).length;
  Object.assign(row, {
    photo_id: meta.photo_id, project_id: meta.project_id, finding_id: meta.finding_id,
    stage: meta.stage, caption: meta.caption,
    sort_order: meta.sort_order !== null ? meta.sort_order : sameFindingPhotos + 1,
    file_name: file.getName(), mime_type: meta.mime_type, size_bytes: bytes.length,
    width: meta.width, height: meta.height, content_hash: hash,
    drive_file_id: file.getId(), drive_url: file.getUrl(),
    captured_at: meta.captured_at, updated_at: now, deleted: '', deleted_at: ''
  });
  if (!existing) { row.uploaded_at = now; appendRowObj_(SHEETS.PHOTOS, row); }
  else { row.uploaded_at = now; writeRowObj_(SHEETS.PHOTOS, row._row, row); }
  return { photo: pub_(row), deduped: false, replaced: !!existing };
}

/** payload: { photo:{photo_id, stage?, caption?, sort_order?} }. The photo must already be uploaded. */
function apiSavePhotoMeta_(p) {
  const meta = cleanPhotoMeta_(p.photo, false);
  const row = findRowById_(SHEETS.PHOTOS, 'photo_id', meta.photo_id);
  if (!row) throw apiError_('NOT_FOUND', 'The photo is not on the server yet. Upload it first.');
  if (row.deleted === 'Y') throw apiError_('GONE', 'This photo was deleted on the server.');
  let changed = false;
  ['stage', 'caption', 'sort_order'].forEach(function (k) {
    if (has_(meta, k) && row[k] !== meta[k]) { row[k] = meta[k]; changed = true; }
  });
  if (changed) { row.updated_at = nowIso_(); writeRowObj_(SHEETS.PHOTOS, row._row, row); }
  return { photo: pub_(row), changed: changed };
}

/** payload: { photoId }. The Drive file goes to the Drive trash (recoverable for 30 days). */
function apiDeletePhoto_(p) {
  requireId_('photo', p.photoId, 'photoId');
  const row = findRowById_(SHEETS.PHOTOS, 'photo_id', p.photoId);
  if (!row) return { alreadyGone: true };
  if (row.deleted === 'Y') return { photo: pub_(row), alreadyDeleted: true };
  const file = getFileSafe_(row.drive_file_id);
  if (file) { try { file.setTrashed(true); } catch (e) { console.warn('Photo not trashed: ' + e.message); } }
  const ts = nowIso_();
  row.deleted = 'Y'; row.deleted_at = ts; row.updated_at = ts;
  writeRowObj_(SHEETS.PHOTOS, row._row, row);
  return { photo: pub_(row) };
}

/** payload: { photoId }  ->  { photo_id, mime_type, dataBase64 } (files stay private; the app caches this) */
function apiGetPhotoData_(p) {
  requireId_('photo', p.photoId, 'photoId');
  const row = findRowById_(SHEETS.PHOTOS, 'photo_id', p.photoId);
  if (!row || row.deleted === 'Y') throw apiError_('NOT_FOUND', 'Photo not found.');
  const file = getFileSafe_(row.drive_file_id);
  if (!file) throw apiError_('FILE_MISSING', 'The photo file is missing from Drive.');
  return {
    photo_id: row.photo_id,
    mime_type: row.mime_type,
    content_hash: row.content_hash,
    dataBase64: Utilities.base64Encode(file.getBlob().getBytes())
  };
}
