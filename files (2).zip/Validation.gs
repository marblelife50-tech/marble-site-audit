/**
 * Marble Site Audit - Validation.gs
 * Server-side validation and cleaning. The server never trusts the phone.
 */

// Fields the phone may change. Everything else (version, folder IDs, dates...) is server-managed.
const PROJECT_EDITABLE = ['project_name', 'client_name', 'building_name', 'site_location',
  'contact_person', 'contact_phone', 'contact_email', 'inspection_datetime', 'inspector_name',
  'job_reference', 'status', 'general_notes', 'overall_condition', 'executive_summary',
  'overall_recommendations', 'client_rep_name'];

const FINDING_EDITABLE = ['area_location', 'material_type', 'finish', 'finish_other',
  'defect_category', 'defect_category_other', 'existing_condition', 'defect_description',
  'possible_cause', 'recommended_method', 'required_materials', 'estimated_area_sqm',
  'priority', 'inspector_remarks', 'client_remarks', 'next_action'];

const REQUIRED_PROJECT_FIELDS = ['project_name', 'client_name', 'site_location'];
const REQUIRED_FINDING_FIELDS = ['area_location'];

const LONG_FIELDS = ['general_notes', 'overall_condition', 'executive_summary', 'overall_recommendations',
  'existing_condition', 'defect_description', 'possible_cause', 'recommended_method',
  'required_materials', 'inspector_remarks', 'client_remarks', 'next_action'];

const MAX_SHORT = 300;
const MAX_LONG = 5000;
const CONTROL_CHARS = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}([T ]\d{2}:\d{2}(:\d{2})?)?$/;
const HASH_RE = /^[a-f0-9]{64}$/;

/** Creates an error carrying a machine-readable code that the app understands. */
function apiError_(code, message, data) {
  const e = new Error(message);
  e.code = code;
  e.data = data || null;
  return e;
}

function has_(obj, key) { return Object.prototype.hasOwnProperty.call(obj, key); }

function cleanText_(v, max, field, errors) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'object') { errors[field] = 'Invalid value.'; return ''; }
  const s = String(v).replace(CONTROL_CHARS, '').replace(/\r\n?/g, '\n').trim();
  if (s.length > max) { errors[field] = 'Too long (maximum ' + max + ' characters).'; return ''; }
  return s;
}

function cleanEnum_(v, list, field, errors, defaultValue) {
  const s = cleanText_(v, 100, field, errors);
  if (s === '') return defaultValue || '';
  if (list.indexOf(s) === -1) { errors[field] = 'Not an allowed value.'; return ''; }
  return s;
}

function cleanNumber_(v, min, max, field, errors) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  if (!isFinite(n) || n < min || n > max) { errors[field] = 'Must be a number between ' + min + ' and ' + max + '.'; return null; }
  return Math.round(n * 100) / 100;
}

function requireFields_(obj, list, errors) {
  list.forEach(function (k) { if (!obj[k]) errors[k] = 'Required.'; });
}

function throwIfErrors_(errors) {
  const keys = Object.keys(errors);
  if (!keys.length) return;
  const first = keys.slice(0, 3).map(function (k) { return k + ': ' + errors[k]; }).join('; ');
  throw apiError_('VALIDATION', 'Please fix: ' + first, { fields: errors });
}

function requireId_(kind, id, field) {
  if (!isValidId_(kind, id)) {
    const f = {}; f[field] = 'Missing or invalid ID.';
    throw apiError_('VALIDATION', field + ' is missing or not a valid ID.', { fields: f });
  }
}

/** Returns only the project fields that were actually sent, cleaned and validated. */
function cleanProjectFields_(input) {
  const errors = {}, out = {};
  PROJECT_EDITABLE.forEach(function (k) {
    if (!has_(input, k)) return;
    const v = input[k];
    if (k === 'status') {
      out[k] = cleanEnum_(v, ENUMS.PROJECT_STATUS, k, errors, 'Draft');
    } else if (k === 'contact_email') {
      const s = cleanText_(v, MAX_SHORT, k, errors);
      if (s && !EMAIL_RE.test(s)) errors[k] = 'Not a valid email address.';
      out[k] = s;
    } else if (k === 'inspection_datetime') {
      const s = cleanText_(v, 40, k, errors);
      if (s && !DATE_RE.test(s)) errors[k] = 'Not a valid date/time.';
      out[k] = s;
    } else {
      out[k] = cleanText_(v, LONG_FIELDS.indexOf(k) > -1 ? MAX_LONG : MAX_SHORT, k, errors);
    }
  });
  throwIfErrors_(errors);
  return out;
}

function cleanFindingFields_(input) {
  const errors = {}, out = {};
  FINDING_EDITABLE.forEach(function (k) {
    if (!has_(input, k)) return;
    const v = input[k];
    if (k === 'finish') out[k] = cleanEnum_(v, ENUMS.FINISH, k, errors, '');
    else if (k === 'defect_category') out[k] = cleanEnum_(v, ENUMS.DEFECT_CATEGORY, k, errors, '');
    else if (k === 'priority') out[k] = cleanEnum_(v, ENUMS.PRIORITY, k, errors, 'Medium');
    else if (k === 'estimated_area_sqm') out[k] = cleanNumber_(v, 0, 1000000, k, errors);
    else out[k] = cleanText_(v, LONG_FIELDS.indexOf(k) > -1 ? MAX_LONG : MAX_SHORT, k, errors);
  });
  throwIfErrors_(errors);
  return out;
}

/** forUpload = true: all fields required. false: only photo_id plus any of stage/caption/sort_order. */
function cleanPhotoMeta_(input, forUpload) {
  if (!input || typeof input !== 'object') throw apiError_('VALIDATION', 'Photo data is missing.');
  const errors = {}, out = {};
  requireId_('photo', input.photo_id, 'photo_id');
  out.photo_id = input.photo_id;
  if (forUpload) {
    requireId_('project', input.project_id, 'project_id');
    requireId_('finding', input.finding_id, 'finding_id');
    out.project_id = input.project_id;
    out.finding_id = input.finding_id;
  }
  if (forUpload || has_(input, 'stage')) out.stage = cleanEnum_(input.stage, ENUMS.PHOTO_STAGE, 'stage', errors, 'Before');
  if (forUpload || has_(input, 'caption')) out.caption = cleanText_(input.caption, MAX_SHORT, 'caption', errors);
  if (forUpload || has_(input, 'sort_order')) out.sort_order = cleanNumber_(input.sort_order, 0, 100000, 'sort_order', errors);
  if (forUpload) {
    out.file_name = cleanText_(input.file_name, 150, 'file_name', errors);
    out.mime_type = cleanText_(input.mime_type, 40, 'mime_type', errors);
    out.width = cleanNumber_(input.width, 0, 20000, 'width', errors);
    out.height = cleanNumber_(input.height, 0, 20000, 'height', errors);
    out.captured_at = cleanText_(input.captured_at, 40, 'captured_at', errors);
    out.content_hash = String(input.content_hash || '').toLowerCase();
    if (!HASH_RE.test(out.content_hash)) errors.content_hash = 'Must be a SHA-256 hex string.';
  }
  throwIfErrors_(errors);
  return out;
}

function cleanDevice_(v) {
  const s = String(v || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64);
  return s || 'unknown';
}

function cleanOpId_(v) {
  if (v === undefined || v === null || v === '') return '';
  const s = String(v);
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(s)) throw apiError_('BAD_REQUEST', 'operationId must be 8-64 letters, digits, - or _.');
  return s;
}
