/**
 * Marble Site Audit - Auth.gs
 * Access-code login, lockout after wrong attempts, and signed session tokens.
 * Reuses hashAccessCode_ from Setup.gs.
 */

function apiLogin_(p) {
  const props = PropertiesService.getScriptProperties();
  const salt = props.getProperty('ACCESS_SALT');
  const hash = props.getProperty('ACCESS_HASH');
  const secret = props.getProperty('SESSION_SECRET');
  if (!salt || !hash || !secret) {
    throw apiError_('NOT_CONFIGURED', 'The access code has not been set. Run setAccessCode() in Apps Script.');
  }

  const lock = LockService.getScriptLock();
  try { lock.waitLock(CONFIG.LOCK_WAIT_MS); }
  catch (e) { throw apiError_('BUSY', 'The server is busy. Please try again in a moment.'); }

  try {
    const lockedUntil = Number(props.getProperty('LOCKED_UNTIL') || 0);
    if (Date.now() < lockedUntil) {
      const mins = Math.ceil((lockedUntil - Date.now()) / 60000);
      throw apiError_('LOCKED', 'Too many wrong attempts. Try again in about ' + mins + ' minute(s).');
    }

    const code = String((p && p.code) || '');
    if (code && safeEqual_(hashAccessCode_(code, salt), hash)) {
      props.setProperties({ FAILED_LOGINS: '0', LOCKED_UNTIL: '0' });
      return issueToken_(secret);
    }

    const fails = Number(props.getProperty('FAILED_LOGINS') || 0) + 1;
    if (fails >= CONFIG.MAX_FAILED_LOGINS) {
      props.setProperties({ FAILED_LOGINS: '0', LOCKED_UNTIL: String(Date.now() + CONFIG.LOCKOUT_MINUTES * 60000) });
      Utilities.sleep(1000);
      throw apiError_('LOCKED', 'Too many wrong attempts. Login is locked for ' + CONFIG.LOCKOUT_MINUTES + ' minutes.');
    }
    props.setProperty('FAILED_LOGINS', String(fails));
    Utilities.sleep(1000);
    throw apiError_('BAD_CODE', 'Incorrect access code. Attempts left: ' + (CONFIG.MAX_FAILED_LOGINS - fails) + '.');
  } finally {
    lock.releaseLock();
  }
}

function issueToken_(secret) {
  const expires = Date.now() + CONFIG.SESSION_HOURS * 3600000;
  const body = Utilities.base64EncodeWebSafe(JSON.stringify({ exp: expires, n: Utilities.getUuid() }));
  const sig = Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(body, secret));
  return { token: body + '.' + sig, expiresAt: expires };
}

function verifyToken_(token) {
  const fail = function () { return apiError_('AUTH', 'Please log in again.'); };
  if (typeof token !== 'string' || token.indexOf('.') < 1) throw fail();
  const secret = PropertiesService.getScriptProperties().getProperty('SESSION_SECRET');
  if (!secret) throw fail();

  const parts = token.split('.');
  if (parts.length !== 2) throw fail();
  const expected = Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(parts[0], secret));
  if (!safeEqual_(expected, parts[1])) throw fail();

  let payload;
  try {
    payload = JSON.parse(Utilities.newBlob(Utilities.base64DecodeWebSafe(parts[0])).getDataAsString());
  } catch (e) { throw fail(); }
  if (!payload || !payload.exp || Date.now() > payload.exp) throw fail();
  return payload;
}

/** Compares two strings without stopping at the first difference. */
function safeEqual_(a, b) {
  a = String(a); b = String(b);
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
