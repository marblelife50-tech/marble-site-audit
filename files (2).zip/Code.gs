/**
 * Marble Site Audit - Code.gs
 * The single entry point. The app sends:
 *   POST  { action, token, deviceId, operationId?, payload }   (as text/plain JSON)
 * and always receives:
 *   { ok:true,  data, serverTime, replayed? }   or
 *   { ok:false, error:{ code, message, data } }
 */

function doGet() {
  return ContentService.createTextOutput('Marble Site Audit API is running.');
}

/** Built on demand (not at load time) so file order never matters. */
function actionTable_() {
  return {
    ping:            { fn: apiPing_,           auth: false, write: false },
    login:           { fn: apiLogin_,          auth: false, write: false },
    getSettings:     { fn: apiGetSettings_,    auth: true,  write: false },
    listProjects:    { fn: apiListProjects_,   auth: true,  write: false },
    getProject:      { fn: apiGetProject_,     auth: true,  write: false },
    getPhotoData:    { fn: apiGetPhotoData_,   auth: true,  write: false },
    getReportData:   { fn: apiGetReportData_,  auth: true,  write: false },

    saveSettings:    { fn: apiSaveSettings_,    auth: true, write: true },
    uploadLogo:      { fn: apiUploadLogo_,      auth: true, write: true },
    saveProject:     { fn: apiSaveProject_,     auth: true, write: true },
    deleteProject:   { fn: apiDeleteProject_,   auth: true, write: true },
    restoreProject:  { fn: apiRestoreProject_,  auth: true, write: true },
    duplicateProject:{ fn: apiDuplicateProject_,auth: true, write: true },
    saveFinding:     { fn: apiSaveFinding_,     auth: true, write: true },
    deleteFinding:   { fn: apiDeleteFinding_,   auth: true, write: true },
    reorderFindings: { fn: apiReorderFindings_, auth: true, write: true },
    uploadPhoto:     { fn: apiUploadPhoto_,     auth: true, write: true },
    savePhotoMeta:   { fn: apiSavePhotoMeta_,   auth: true, write: true },
    deletePhoto:     { fn: apiDeletePhoto_,     auth: true, write: true },
    uploadReport:    { fn: apiUploadReport_,    auth: true, write: true },
    deleteReport:    { fn: apiDeleteReport_,    auth: true, write: true },
    syncBatch:       { fn: apiSyncBatch_,       auth: true, write: 'batch' }
  };
}

/** Actions allowed inside syncBatch (no file uploads: those go one per request). */
const BATCHABLE_ACTIONS = ['saveProject', 'deleteProject', 'restoreProject', 'saveFinding',
  'deleteFinding', 'reorderFindings', 'savePhotoMeta', 'deletePhoto', 'deleteReport'];

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) throw apiError_('BAD_REQUEST', 'Empty request.');
    let req;
    try { req = JSON.parse(e.postData.contents); }
    catch (x) { throw apiError_('BAD_REQUEST', 'The request was not valid JSON.'); }

    const def = actionTable_()[req.action];
    if (!def) throw apiError_('BAD_REQUEST', 'Unknown action: ' + String(req.action).slice(0, 40));
    if (def.auth) verifyToken_(req.token);

    const ctx = { deviceId: cleanDevice_(req.deviceId) };
    const payload = (req.payload && typeof req.payload === 'object') ? req.payload : {};

    if (!def.write) return json_({ ok: true, data: def.fn(payload, ctx), serverTime: nowIso_() });
    return json_(runLocked_(def, req, payload, ctx));
  } catch (err) {
    return json_({ ok: false, error: errorBody_(err) });
  }
}

/** All writes run one at a time so two phones can never corrupt the sheet. */
function runLocked_(def, req, payload, ctx) {
  const lock = LockService.getScriptLock();
  try { lock.waitLock(CONFIG.LOCK_WAIT_MS); }
  catch (e) { throw apiError_('BUSY', 'The server is busy. Please try again in a moment.'); }
  try {
    if (def.write === 'batch') return { ok: true, data: def.fn(payload, ctx), serverTime: nowIso_() };
    const r = executeWrite_(ctx, req.action, payload, cleanOpId_(req.operationId));
    return { ok: true, data: r.data, replayed: !!r.replayed, serverTime: nowIso_() };
  } finally {
    lock.releaseLock();
  }
}

function errorBody_(err) {
  if (err && err.code) return { code: err.code, message: err.message, data: err.data || null };
  console.error(err && err.stack ? err.stack : err);
  return { code: 'SERVER_ERROR', message: 'Unexpected server error: ' + (err && err.message ? err.message : err), data: null };
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function apiPing_() {
  return {
    appVersion: CONFIG.APP_VERSION,
    schemaVersion: CONFIG.SCHEMA_VERSION,
    configured: !!PropertiesService.getScriptProperties().getProperty('ACCESS_HASH')
  };
}
