/* Marble Site Audit - photos.js
   Compresses photos in the browser, stores them locally (IndexedDB), and keeps each photo
   tied to its project and finding by ID. Nothing here talks to the server except downloading
   a photo that is not on this phone yet. */
(function () {
  'use strict';
  const C = window.APP_CONFIG;
  const urlCache = {};      // photo_id -> blob: URL (created on demand, freed when no longer needed)
  const inflight = {};      // photo_id -> Promise (avoids downloading the same photo twice)

  /* ---------- helpers ---------- */
  async function sha256Hex(blob) {
    if (!(window.crypto && crypto.subtle)) throw new Error('This browser cannot verify photos (HTTPS is required).');
    const digest = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
    return Array.from(new Uint8Array(digest), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }
  async function blobToBase64(blob) {
    const bytes = new Uint8Array(await blob.arrayBuffer());
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }
  function base64ToBlob(b64, mime) {
    const bin = atob(b64);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: mime || 'application/octet-stream' });
  }
  function toBlob(canvas, quality) {
    return new Promise(function (res, rej) {
      canvas.toBlob(function (b) { b ? res(b) : rej(new Error('The photo could not be compressed.')); }, 'image/jpeg', quality);
    });
  }
  function loadViaImg(file) {
    return new Promise(function (res, rej) {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = function () { URL.revokeObjectURL(url); res(img); };
      img.onerror = function () { URL.revokeObjectURL(url); rej(new Error('This file could not be read as an image.')); };
      img.src = url;
    });
  }
  async function loadImage(file) {
    if (window.createImageBitmap) {
      try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); }
      catch (e) { /* fall back to <img> */ }
    }
    return loadViaImg(file);
  }
  function friendlyStorageError(e) {
    if (e && (e.name === 'QuotaExceededError' || /quota/i.test(String(e.message)))) {
      return new Error('This phone is out of storage space. Sync your photos, then free up space and try again.');
    }
    return e;
  }

  const Photos = {
    sha256Hex: sha256Hex,
    blobToBase64: blobToBase64,
    base64ToBlob: base64ToBlob,

    /* Resize to PHOTO_MAX_DIMENSION, convert to JPEG, hash it. Returns everything needed to store it. */
    async processFile(file) {
      if (!file) throw new Error('No photo was selected.');
      if (file.type && file.type.indexOf('image/') !== 0) throw new Error('Please choose an image file.');
      const src = await loadImage(file);
      const w0 = src.width, h0 = src.height;
      if (!w0 || !h0) throw new Error('This image is empty or damaged.');
      const scale = Math.min(1, C.PHOTO_MAX_DIMENSION / Math.max(w0, h0));
      const w = Math.max(1, Math.round(w0 * scale)), h = Math.max(1, Math.round(h0 * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';            // PNGs with transparency become white, not black
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(src, 0, 0, w, h);
      if (src.close) src.close();

      let q = C.PHOTO_JPEG_QUALITY;
      let blob = await toBlob(canvas, q);
      while (blob.size > C.PHOTO_MAX_UPLOAD_BYTES && q > 0.4) { q -= 0.1; blob = await toBlob(canvas, q); }
      canvas.width = 0; canvas.height = 0;  // release memory
      if (blob.size > C.PHOTO_MAX_UPLOAD_BYTES) throw new Error('This photo is too large even after compression.');

      return {
        blob: blob, mime_type: 'image/jpeg', width: w, height: h, size_bytes: blob.size,
        content_hash: await sha256Hex(blob),
        file_name: 'IMG_' + new Date().toISOString().replace(/[-:T.Z]/g, '').slice(0, 14) + '.jpg'
      };
    },

    /* Stores a processed photo for a finding. The blob is saved BEFORE the record, so a record never points at nothing. */
    async addPhoto(o) {
      const siblings = await DB.byIndex('photos', 'finding_id', o.findingId);
      const max = siblings.filter(function (p) { return !p._deleted; }).reduce(function (m, p) { return Math.max(m, p.sort_order || 0); }, 0);
      const pr = o.processed;
      const rec = {
        photo_id: Store.newId('photo'), project_id: o.projectId, finding_id: o.findingId,
        stage: o.stage || 'Before', caption: String(o.caption || '').slice(0, 300), sort_order: max + 1,
        file_name: pr.file_name, mime_type: pr.mime_type, size_bytes: pr.size_bytes,
        width: pr.width, height: pr.height, content_hash: pr.content_hash,
        captured_at: Store.nowIso(), drive_file_id: '', drive_url: '',
        _uploaded: false, _metaDirty: false, _metaOp: null, _deleted: false, _op: null, _syncError: null
      };
      try {
        await DB.put('photoBlobs', { photo_id: rec.photo_id, blob: pr.blob });
        await DB.put('photos', rec);
      } catch (e) {
        await DB.del('photoBlobs', rec.photo_id).catch(function () {});
        throw friendlyStorageError(e);
      }
      Bus.emit('data-changed', { kind: 'photo', id: rec.photo_id });
      return rec;
    },

    /* Swap the image but keep the same photo_id; the server replaces the Drive file. */
    async replacePhoto(photoId, processed) {
      const cur = await DB.get('photos', photoId);
      if (!cur) throw new Error('Photo not found.');
      try { await DB.put('photoBlobs', { photo_id: photoId, blob: processed.blob }); }
      catch (e) { throw friendlyStorageError(e); }
      await DB.update('photos', photoId, function (r) {
        if (!r) return null;
        r.file_name = processed.file_name; r.mime_type = processed.mime_type; r.size_bytes = processed.size_bytes;
        r.width = processed.width; r.height = processed.height; r.content_hash = processed.content_hash;
        r._uploaded = false; r._syncError = null; r._deleted = false;
        return r;
      });
      Photos.revokeUrl(photoId);
      Bus.emit('data-changed', { kind: 'photo', id: photoId });
    },

    async updateMeta(photoId, fields) {
      let didChange = false;
      await DB.update('photos', photoId, function (r) {
        if (!r) return null;
        const caption = fields.caption !== undefined ? String(fields.caption).slice(0, 300) : r.caption;
        const stage = fields.stage !== undefined ? fields.stage : r.stage;
        if (caption === r.caption && stage === r.stage) return null;
        r.caption = caption; r.stage = stage; r._syncError = null;
        if (r.drive_file_id && r._uploaded) { r._metaDirty = true; r._metaOp = Store.newOp('m'); }
        didChange = true;
        return r;
      });
      if (didChange) Bus.emit('data-changed', { kind: 'photo', id: photoId });
    },

    async removePhoto(photoId) {
      const r = await DB.get('photos', photoId);
      if (!r) return;
      if (r.drive_file_id) {
        await DB.update('photos', photoId, function (x) { if (!x) return null; x._deleted = true; x._op = Store.newOp('d'); x._syncError = null; return x; });
        await DB.del('photoBlobs', photoId);
        Photos.revokeUrl(photoId);
      } else {
        await Store.removePhotoLocal(photoId);
      }
      Bus.emit('data-changed', { kind: 'photo', id: photoId });
    },

    async listForFinding(findingId) {
      return (await DB.byIndex('photos', 'finding_id', findingId))
        .filter(function (p) { return !p._deleted; })
        .sort(function (a, b) { return ((a.sort_order || 0) - (b.sort_order || 0)) || String(a.captured_at).localeCompare(String(b.captured_at)); });
    },

    /* The image as a Blob: from this phone if present, otherwise downloaded once and kept. Null if unavailable. */
    getBlob(photoId) {
      if (inflight[photoId]) return inflight[photoId];
      inflight[photoId] = (async function () {
        try {
          const local = await DB.get('photoBlobs', photoId);
          if (local && local.blob) return local.blob;
          const rec = await DB.get('photos', photoId);
          if (!rec || !rec.drive_file_id || !navigator.onLine || !API.hasValidSession()) return null;
          const d = await API.call('getPhotoData', { photoId: photoId });
          const blob = base64ToBlob(d.dataBase64, d.mime_type);
          await DB.put('photoBlobs', { photo_id: photoId, blob: blob });
          return blob;
        } catch (e) {
          console.warn('Photo not available:', photoId, e && e.message);
          return null;
        } finally {
          delete inflight[photoId];
        }
      })();
      return inflight[photoId];
    },

    /* blob: URL for <img src>. Cached until revoked. Null if the image is not available. */
    async getUrl(photoId) {
      if (urlCache[photoId]) return urlCache[photoId];
      const blob = await Photos.getBlob(photoId);
      if (!blob) return null;
      if (!urlCache[photoId]) urlCache[photoId] = URL.createObjectURL(blob);
      return urlCache[photoId];
    },
    revokeUrl(photoId) {
      if (urlCache[photoId]) { URL.revokeObjectURL(urlCache[photoId]); delete urlCache[photoId]; }
    },
    revokeAll() {
      Object.keys(urlCache).forEach(function (id) { URL.revokeObjectURL(urlCache[id]); delete urlCache[id]; });
    }
  };

  window.Photos = Photos;
})();
