/* Marble Site Audit - config.js

   ======================================================================
   THE ONLY LINE YOU EDIT:  API_URL
   Paste the Web app URL from Apps Script (Deploy > Manage deployments).
   It looks like:  https://script.google.com/macros/s/AKfycb.../exec
   ======================================================================
*/
window.APP_CONFIG = {
  API_URL: 'PASTE_YOUR_APPS_SCRIPT_WEB_APP_URL_HERE',

  /* ---------- Everything below is fixed. Do not edit. ---------- */
  APP_VERSION: '1.0.0',
  DB_NAME: 'marble-site-audit',
  DB_VERSION: 1,

  PHOTO_MAX_DIMENSION: 1600,        // longest side in pixels after compression
  PHOTO_JPEG_QUALITY: 0.8,          // 0.8 keeps fine detail at roughly 300-600 KB
  PHOTO_MAX_UPLOAD_BYTES: 5 * 1024 * 1024,   // must stay below the server limit (6 MB)

  SYNC_BATCH_SIZE: 20,              // server accepts at most 25 per batch
  REQUEST_TIMEOUT_MS: 90000,
  UPLOAD_TIMEOUT_MS: 180000,
  SESSION_REFRESH_MARGIN_MS: 5 * 60 * 1000,
  STORAGE_WARN_RATIO: 0.8           // warn when 80% of the browser's storage quota is used
};

/* Must match the lists in the backend (Config.gs). When online, the app refreshes these from the server. */
window.APP_ENUMS = {
  PROJECT_STATUS: ['Draft', 'Inspection Completed', 'Report Generated', 'Submitted'],
  FINISH: ['Polished', 'Honed', 'Leather', 'Flamed', 'Brushed', 'Other'],
  DEFECT_CATEGORY: ['Scratches', 'Etching', 'Dullness', 'Stains', 'Cracks', 'Chips', 'Lippage',
    'Grout Damage', 'Sealer Failure', 'Water Marks', 'Slip Resistance Concern', 'Other'],
  PRIORITY: ['Low', 'Medium', 'High', 'Critical'],
  PHOTO_STAGE: ['Before', 'During', 'After']
};

/* Must match REQUIRED_*_FIELDS in the backend (Validation.gs). */
window.APP_REQUIRED = {
  project: ['project_name', 'client_name', 'site_location'],
  finding: ['area_location']
};
