/* Marble Site Audit - pdf.js
   Builds the client-ready PDF on the phone with jsPDF (works offline), stores it locally as a
   report, and the sync engine then uploads it to the project's Drive "Reports" folder.

   Known limitation: the PDF uses the built-in Helvetica font, which only covers Latin
   characters. Arabic or other scripts are replaced by "?" instead of printing garbage. */
(function () {
  'use strict';

  const COL = {
    slate: [36, 49, 58], primary: [31, 78, 95], accent: [133, 96, 28], text: [29, 35, 41],
    muted: [91, 102, 112], line: [217, 211, 199], panel: [243, 240, 234], white: [255, 255, 255]
  };
  const PRIORITY_COL = { Low: [30, 122, 70], Medium: [161, 120, 0], High: [200, 90, 10], Critical: [179, 38, 30] };
  const STAGE_ORDER = { Before: 0, During: 1, After: 2 };
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const DEFAULT_DISCLAIMER = 'This report is based on a visual inspection carried out on the date shown and reflects ' +
    'conditions visible at that time. Statements about possible causes are the inspector\'s assessment and are not ' +
    'confirmed facts unless stated otherwise. Estimated areas are approximate and must be verified before quotation. ' +
    'Hidden defects, sub-surface conditions and results of laboratory testing are outside the scope of this inspection. ' +
    'Recommended methods may change after on-site trials. This report does not constitute a warranty or guarantee of any kind.';

  /* Keep only characters the standard PDF font can print. */
  function t(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"')
      .replace(/[\u2013\u2014]/g, '-').replace(/\u2026/g, '...').replace(/\u00A0/g, ' ')
      .replace(/\r\n?/g, '\n')
      .replace(/[^\n\x20-\x7E\u00A1-\u00FF]/g, '?');
  }
  function fmtDate(d) {
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'Asia/Dubai' });
  }
  function fmtDateTime(s) {
    const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}))?/.exec(String(s || ''));
    if (!m) return '';
    return m[3] + ' ' + MONTHS[Number(m[2]) - 1] + ' ' + m[1] + (m[4] ? ', ' + m[4] + ':' + m[5] : '');
  }
  function fmtArea(n) { return (Math.round(n * 100) / 100).toString(); }
  function safeFileName(s) {
    return String(s || 'Report').replace(/[\\\/:*?"<>|\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80) || 'Report';
  }
  function defectLabel(f) {
    return (f.defect_category === 'Other' && f.defect_category_other) ? f.defect_category_other : (f.defect_category || '');
  }
  function finishLabel(f) {
    return (f.finish === 'Other' && f.finish_other) ? f.finish_other : (f.finish || '');
  }
  function b64ToBytes(b64) {
    const bin = atob(b64), arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return arr;
  }

  /* data = { project, findings:[{finding, photos:[{photo_id, stage, caption, bytes|null}]}],
              settings, logo:{bytes, mime_type}|null, generatedAt:Date }  ->  jsPDF document */
  function buildDoc(data) {
    const jsPDF = window.jspdf.jsPDF;
    const doc = new jsPDF({ unit: 'mm', format: 'a4', compress: true });
    const P = data.project, S = data.settings || {};
    const W = 210, H = 297, ML = 18, CW = 174, TOP = 24, BOT = H - 22;
    const company = t(S.company_name || 'Marblelife Gulf');
    const title = t(S.report_title || 'Marble Restoration Site Audit Report');
    const reportDate = fmtDate(data.generatedAt);
    let y = 16;

    const color = function (c) { doc.setTextColor(c[0], c[1], c[2]); };
    const fill = function (c) { doc.setFillColor(c[0], c[1], c[2]); };
    const stroke = function (c) { doc.setDrawColor(c[0], c[1], c[2]); };
    const font = function (style, size) { doc.setFont('helvetica', style); doc.setFontSize(size); };
    const lh = function (size) { return size * 0.3528 * 1.38; };       // line height in mm
    const base = function (size) { return size * 0.3528 * 0.92; };     // baseline offset in mm
    const newPage = function () { doc.addPage(); y = TOP; };
    const ensure = function (h) { if (y + h > BOT) newPage(); };

    /* wrapped text that may continue onto the next page, line by line */
    function paragraph(text, o) {
      o = o || {};
      const size = o.size || 10, style = o.style || 'normal', x = o.x === undefined ? ML : o.x, w = o.w || CW;
      font(style, size); color(o.color || COL.text);
      const lines = doc.splitTextToSize(t(text), w);
      lines.forEach(function (line) {
        ensure(lh(size));
        font(style, size); color(o.color || COL.text);
        doc.text(line, x, y + base(size));
        y += lh(size);
      });
      y += (o.after === undefined ? 2 : o.after);
    }
    function labelled(label, text) {
      if (!String(text || '').trim()) return;
      ensure(lh(8.5) + lh(10) * 2 + 2);          // never leave a label alone at the bottom of a page
      font('bold', 8.5); color(COL.primary);
      doc.text(t(label).toUpperCase(), ML, y + base(8.5));
      y += lh(8.5) + 0.5;
      paragraph(text, { size: 10, after: 3 });
    }
    function heading(text) {
      ensure(18);
      font('bold', 14); color(COL.primary);
      doc.text(t(text), ML, y + base(14));
      y += lh(14) + 1;
      stroke(COL.accent); doc.setLineWidth(0.5); doc.line(ML, y, ML + 28, y);
      stroke(COL.line); doc.setLineWidth(0.25); doc.line(ML + 28, y, ML + CW, y);
      y += 4;
    }
    function badge(text, xRight, yTop, c) {
      font('bold', 8);
      const w = doc.getTextWidth(t(text)) + 6;
      fill(c); doc.roundedRect(xRight - w, yTop, w, 5.2, 1.4, 1.4, 'F');
      color(COL.white); doc.text(t(text), xRight - w / 2, yTop + 3.7, { align: 'center' });
    }
    function grid(rows) {
      const cols = 2, cw = CW / cols;
      const clean = rows.map(function (r) { return [r[0], String(r[1] || '').trim() || '-']; });
      for (let i = 0; i < clean.length; i += cols) {
        const cells = clean.slice(i, i + cols).map(function (r) {
          font('normal', 10);
          return { label: r[0], lines: doc.splitTextToSize(t(r[1]), cw - 6) };
        });
        const rowH = 3.8 + Math.max.apply(null, cells.map(function (c) { return c.lines.length; })) * lh(10) + 2.4;
        ensure(rowH);
        cells.forEach(function (c, k) {
          const x = ML + k * cw;
          font('bold', 7.5); color(COL.muted);
          doc.text(t(c.label).toUpperCase(), x, y + base(7.5));
          font('normal', 10); color(COL.text);
          c.lines.forEach(function (ln, j) { doc.text(ln, x, y + 3.8 + j * lh(10) + base(10)); });
        });
        stroke(COL.line); doc.setLineWidth(0.2); doc.line(ML, y + rowH - 0.6, ML + CW, y + rowH - 0.6);
        y += rowH;
      }
      y += 3;
    }

    /* ---------- cover block (page 1) ---------- */
    let logoDrawn = false;
    if (data.logo && data.logo.bytes) {
      try {
        const fmt = /png/i.test(data.logo.mime_type) ? 'PNG' : 'JPEG';
        const ip = doc.getImageProperties(data.logo.bytes);
        let lw = 56, lhh = lw * ip.height / ip.width;
        if (lhh > 22) { lhh = 22; lw = lhh * ip.width / ip.height; }
        doc.addImage(data.logo.bytes, fmt, ML, y, lw, lhh, 'logo');
        logoDrawn = true;
        y += lhh + 6;
      } catch (e) { logoDrawn = false; }
    }
    if (!logoDrawn) {                                   // text placeholder until a logo is uploaded
      font('bold', 13);
      const bw = doc.getTextWidth(company.toUpperCase()) + 10;
      stroke(COL.slate); doc.setLineWidth(0.7); doc.rect(ML, y, bw, 12);
      color(COL.slate); doc.text(company.toUpperCase(), ML + 5, y + 8);
      y += 18;
    }
    font('normal', 8.5); color(COL.muted);
    doc.text('Report date: ' + reportDate, ML + CW, 17, { align: 'right' });
    doc.text('Project ID: ' + t(P.project_id), ML + CW, 21.5, { align: 'right' });

    y += 6;
    paragraph(title, { size: 22, style: 'bold', color: COL.slate, after: 2 });
    paragraph(P.project_name, { size: 15, style: 'bold', color: COL.primary, after: 1 });
    paragraph([P.client_name, P.building_name].filter(Boolean).join('  |  '), { size: 11, color: COL.muted, after: 4 });
    stroke(COL.accent); doc.setLineWidth(0.8); doc.line(ML, y, ML + CW, y);
    y += 7;

    /* ---------- details ---------- */
    heading('Project and inspection details');
    grid([
      ['Client / Company', P.client_name], ['Building / Property', P.building_name],
      ['Site location', P.site_location], ['Client contact person', P.contact_person],
      ['Contact number', P.contact_phone], ['Email address', P.contact_email],
      ['Inspection date and time', fmtDateTime(P.inspection_datetime)], ['Inspector', P.inspector_name],
      ['Job / Quotation / PO reference', P.job_reference], ['Report date', reportDate]
    ]);

    heading('Executive summary');
    paragraph(P.executive_summary || 'No executive summary has been entered.', { after: 5 });
    heading('Overall site condition');
    paragraph(P.overall_condition || 'No overall condition statement has been entered.', { after: 5 });
    if (String(P.general_notes || '').trim()) {
      heading('General site notes');
      paragraph(P.general_notes, { after: 5 });
    }

    /* ---------- findings overview ---------- */
    const entries = data.findings || [];
    if (entries.length) {
      heading('Findings overview');
      const cw = [12, 66, 46, 24, 26];
      const hdr = ['No.', 'Area / location', 'Defect', 'Priority', 'Est. area (sqm)'];
      ensure(10);
      fill(COL.slate); doc.rect(ML, y, CW, 7, 'F');
      font('bold', 8.5); color(COL.white);
      let hx = ML;
      hdr.forEach(function (h, i) { doc.text(h, hx + 2, y + 4.8); hx += cw[i]; });
      y += 7;
      let total = 0;
      entries.forEach(function (e, i) {
        const f = e.finding;
        font('normal', 9);
        const a = doc.splitTextToSize(t(f.area_location), cw[1] - 4).slice(0, 2);
        const d = doc.splitTextToSize(t(defectLabel(f) || '-'), cw[2] - 4).slice(0, 2);
        const rh = Math.max(a.length, d.length) * lh(9) + 3;
        ensure(rh);
        if (i % 2) { fill(COL.panel); doc.rect(ML, y, CW, rh, 'F'); }
        color(COL.text); font('normal', 9);
        let x = ML;
        doc.text(String(i + 1), x + 2, y + 1.6 + base(9)); x += cw[0];
        a.forEach(function (ln, j) { doc.text(ln, x + 2, y + 1.6 + j * lh(9) + base(9)); }); x += cw[1];
        d.forEach(function (ln, j) { doc.text(ln, x + 2, y + 1.6 + j * lh(9) + base(9)); }); x += cw[2];
        font('bold', 9); color(PRIORITY_COL[f.priority] || COL.text);
        doc.text(t(f.priority || '-'), x + 2, y + 1.6 + base(9)); x += cw[3];
        font('normal', 9); color(COL.text);
        const area = (f.estimated_area_sqm === null || f.estimated_area_sqm === undefined || f.estimated_area_sqm === '') ? null : Number(f.estimated_area_sqm);
        if (area !== null && isFinite(area)) total += area;
        doc.text(area === null ? '-' : fmtArea(area), x + 2, y + 1.6 + base(9));
        y += rh;
      });
      ensure(8);
      stroke(COL.slate); doc.setLineWidth(0.4); doc.line(ML, y, ML + CW, y);
      font('bold', 9.5); color(COL.slate);
      doc.text('Total estimated area', ML + cw[0] + 2, y + 5);
      doc.text(fmtArea(total) + ' sqm', ML + CW - 2, y + 5, { align: 'right' });
      y += 10;
    }

    /* ---------- detailed findings ---------- */
    newPage();
    heading('Detailed findings');
    if (!entries.length) paragraph('No findings have been recorded for this site.', { color: COL.muted });

    entries.forEach(function (e, idx) {
      const f = e.finding;
      ensure(62);                                       // heading + first rows stay together
      fill(COL.panel); doc.rect(ML, y, CW, 9.5, 'F');
      fill(COL.slate); doc.rect(ML, y, 1.8, 9.5, 'F');
      font('bold', 12); color(COL.slate);
      const head = doc.splitTextToSize(t('Finding ' + (idx + 1) + ': ' + f.area_location), CW - 36)[0];
      doc.text(head, ML + 5, y + 6.4);
      if (f.priority) badge(f.priority, ML + CW - 3, y + 2.2, PRIORITY_COL[f.priority] || COL.muted);
      y += 12.5;

      grid([
        ['Area / location', f.area_location], ['Material / stone type', f.material_type],
        ['Finish', finishLabel(f)], ['Defect category', defectLabel(f)],
        ['Estimated area', (f.estimated_area_sqm === null || f.estimated_area_sqm === '' || f.estimated_area_sqm === undefined) ? '' : fmtArea(Number(f.estimated_area_sqm)) + ' sqm'],
        ['Priority', f.priority]
      ]);
      labelled('Existing condition', f.existing_condition);
      labelled('Defect description', f.defect_description);
      labelled("Possible cause (inspector's assessment, not a confirmed fact)", f.possible_cause);
      labelled('Recommended restoration method', f.recommended_method);
      labelled('Required materials / chemicals', f.required_materials);
      labelled('Inspector remarks', f.inspector_remarks);
      labelled('Client remarks', f.client_remarks);
      labelled('Recommendation / next action', f.next_action);

      if (e.photos && e.photos.length) {
        ensure(12 + 40);
        font('bold', 8.5); color(COL.primary);
        doc.text('PHOTOGRAPHS', ML, y + base(8.5));
        y += lh(8.5) + 1.5;
        const gap = 6, cw = (CW - gap) / 2, maxH = 62;
        for (let i = 0; i < e.photos.length; i += 2) {
          const cells = e.photos.slice(i, i + 2).map(function (p) {
            let w = cw, h = cw * 0.72, ok = !!p.bytes;
            if (ok) {
              try {
                const ip = doc.getImageProperties(p.bytes), r = ip.width / ip.height;
                w = cw; h = w / r;
                if (h > maxH) { h = maxH; w = h * r; }
              } catch (err) { ok = false; w = cw; h = cw * 0.72; }
            }
            font('italic', 8.5);
            const cap = t((p.stage || '') + (p.caption ? ' - ' + p.caption : ''));
            const lines = doc.splitTextToSize(cap, cw).slice(0, 3);
            return { p: p, ok: ok, w: w, h: h, lines: lines, total: h + 2 + lines.length * 3.8 };
          });
          const rowH = Math.max.apply(null, cells.map(function (c) { return c.total; })) + 5;
          ensure(rowH);
          cells.forEach(function (c, k) {
            const x = ML + k * (cw + gap);
            if (c.ok) {
              doc.addImage(c.p.bytes, 'JPEG', x, y, c.w, c.h, c.p.photo_id || undefined, 'FAST');
              stroke(COL.line); doc.setLineWidth(0.25); doc.rect(x, y, c.w, c.h);
            } else {
              fill(COL.panel); doc.rect(x, y, cw, c.h, 'F');
              font('italic', 9); color(COL.muted);
              doc.text('Photo not available', x + cw / 2, y + c.h / 2, { align: 'center' });
            }
            font('italic', 8.5); color(COL.muted);
            c.lines.forEach(function (ln, j) { doc.text(ln, x, y + c.h + 3.6 + j * 3.8); });
          });
          y += rowH;
        }
      }
      y += 5;
      if (idx < entries.length - 1) {
        ensure(10);
        stroke(COL.line); doc.setLineWidth(0.25); doc.line(ML, y, ML + CW, y);
        y += 6;
      }
    });

    /* ---------- closing sections ---------- */
    ensure(40);
    heading('General recommendations');
    paragraph(P.overall_recommendations || 'No general recommendations have been entered.', { after: 6 });

    heading('Limitations and disclaimer');
    paragraph(S.report_disclaimer || DEFAULT_DISCLAIMER, { size: 9, color: COL.muted, after: 6 });

    ensure(62);
    heading('Sign-off');
    const colW = (CW - 12) / 2;
    const sign = function (x, role, name, note) {
      font('bold', 10); color(COL.slate);
      doc.text(role, x, y + 4);
      font('normal', 10); color(COL.text);
      doc.text('Name: ' + (t(name) || '________________________'), x, y + 11);
      stroke(COL.slate); doc.setLineWidth(0.3);
      doc.line(x, y + 30, x + colW, y + 30);
      font('normal', 8.5); color(COL.muted);
      doc.text('Signature', x, y + 34);
      doc.line(x, y + 46, x + colW * 0.6, y + 46);
      doc.text('Date', x, y + 50);
      if (note) {
        font('italic', 8.5);
        doc.splitTextToSize(note, colW).forEach(function (ln, j) { doc.text(ln, x, y + 17 + j * 3.6); });
      }
    };
    sign(ML, 'Inspector', P.inspector_name, '');
    sign(ML + colW + 12, 'Client representative', P.client_rep_name, 'Acknowledgment of receipt of this report.');
    y += 54;

    /* ---------- headers and footers on every page (needs the final page count) ---------- */
    const total = doc.getNumberOfPages();
    const contact = t([S.company_address, S.company_phone, S.company_email].filter(Boolean).join('  |  '));
    for (let i = 1; i <= total; i++) {
      doc.setPage(i);
      stroke(COL.line); doc.setLineWidth(0.25);
      if (i > 1) {
        font('normal', 8); color(COL.muted);
        doc.text(company, ML, 11);
        doc.text(doc.splitTextToSize(t(P.project_name), 100)[0], ML + CW, 11, { align: 'right' });
        doc.line(ML, 13.5, ML + CW, 13.5);
      }
      doc.line(ML, H - 15, ML + CW, H - 15);
      font('normal', 8); color(COL.muted);
      doc.text('Generated ' + reportDate, ML, H - 10.5);
      doc.text('Page ' + i + ' of ' + total, ML + CW, H - 10.5, { align: 'right' });
      if (contact) {
        font('normal', 7.5);
        doc.text(doc.splitTextToSize(contact, 100)[0], W / 2, H - 10.5, { align: 'center' });
      }
    }
    doc.setProperties({
      title: title + ' - ' + t(P.project_name), subject: t(P.client_name),
      author: t(P.inspector_name || company), creator: 'Marble Site Audit'
    });
    return doc;
  }

  /* Gathers everything from local storage, builds the PDF, and stores it as a report. */
  async function generateForProject(projectId, opts) {
    const progress = (opts && opts.onProgress) || function () {};
    const project = await Store.getProject(projectId);
    if (!project) throw new Error('Project not found on this phone.');
    const findings = await Store.listFindings(projectId);
    const cache = await DB.meta.get('settingsCache');
    const settings = Object.assign({ company_name: 'Marblelife Gulf', report_title: 'Marble Restoration Site Audit Report', report_disclaimer: DEFAULT_DISCLAIMER },
      (cache && cache.settings) || {});
    Object.keys(settings).forEach(function (k) { if (settings[k] === '' && (k === 'report_disclaimer' || k === 'company_name' || k === 'report_title')) delete settings[k]; });
    let logo = null;
    if (cache && cache.logo && cache.logo.dataBase64) logo = { bytes: b64ToBytes(cache.logo.dataBase64), mime_type: cache.logo.mime_type };

    const entries = [];
    let missing = 0, totalPhotos = 0;
    for (let i = 0; i < findings.length; i++) {
      progress('Preparing finding ' + (i + 1) + ' of ' + findings.length + '\u2026');
      const photos = (await Photos.listForFinding(findings[i].finding_id)).slice().sort(function (a, b) {
        return ((STAGE_ORDER[a.stage] || 0) - (STAGE_ORDER[b.stage] || 0)) || ((a.sort_order || 0) - (b.sort_order || 0));
      });
      const items = [];
      for (const ph of photos) {
        totalPhotos++;
        const blob = await Photos.getBlob(ph.photo_id);
        if (!blob) missing++;
        items.push({ photo_id: ph.photo_id, stage: ph.stage, caption: ph.caption, bytes: blob ? new Uint8Array(await blob.arrayBuffer()) : null });
      }
      entries.push({ finding: findings[i], photos: items });
      await new Promise(function (r) { setTimeout(r, 0); });      // let the loading message repaint
    }

    progress('Building PDF\u2026');
    await new Promise(function (r) { setTimeout(r, 0); });
    const generatedAt = new Date();
    const doc = buildDoc({ project: project, findings: entries, settings: settings, logo: logo, generatedAt: generatedAt });
    const blob = new Blob([doc.output('arraybuffer')], { type: 'application/pdf' });
    const hash = await Photos.sha256Hex(blob);
    const day = generatedAt.toISOString().slice(0, 10);
    const report = await Store.addReport({
      project_id: projectId,
      file_name: safeFileName('Site Audit Report - ' + project.project_name + ' - ' + day) + '.pdf',
      project_version: project.version || 0, content_hash: hash, size_bytes: blob.size,
      generated_at: generatedAt.toISOString()
    }, blob);
    return { report: report, blob: blob, missingPhotos: missing, totalPhotos: totalPhotos };
  }

  /* The PDF for a report: from this phone, otherwise downloaded from Drive (needs internet). */
  async function getReportBlob(reportId) {
    const local = await DB.get('reportBlobs', reportId);
    if (local && local.blob) return local.blob;
    const rec = await DB.get('reports', reportId);
    if (!rec || !rec.drive_file_id) return null;
    const d = await API.call('getReportData', { reportId: reportId }, { timeoutMs: window.APP_CONFIG.UPLOAD_TIMEOUT_MS });
    const blob = Photos.base64ToBlob(d.dataBase64, 'application/pdf');
    await DB.put('reportBlobs', { report_id: reportId, blob: blob });
    return blob;
  }

  window.PDF = { buildDoc: buildDoc, generateForProject: generateForProject, getReportBlob: getReportBlob, safeFileName: safeFileName };
})();
