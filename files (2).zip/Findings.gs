/**
 * Marble Site Audit - Findings.gs
 * Each finding has its own version number and its own Drive photo folder.
 * sort_order is changed ONLY by reorderFindings (or set once when a finding is created),
 * so editing a finding on one phone can never undo a re-ordering done on another.
 */

/** payload: { finding:{finding_id, project_id, ...fields}, baseVersion } */
function apiSaveFinding_(p, ctx) {
  const input = p.finding;
  if (!input || typeof input !== 'object') throw apiError_('VALIDATION', 'Finding data is missing.');
  requireId_('finding', input.finding_id, 'finding_id');
  requireId_('project', input.project_id, 'project_id');

  const proj = findRowById_(SHEETS.PROJECTS, 'project_id', input.project_id);
  if (!proj) throw apiError_('PROJECT_MISSING', 'The project is not on the server yet. Sync the project first.');
  if (proj.deleted === 'Y') throw apiError_('DELETED_ON_SERVER', 'The project was deleted on the server.', { serverProject: pub_(proj) });

  const fields = cleanFindingFields_(input);
  const existing = findRowById_(SHEETS.FINDINGS, 'finding_id', input.finding_id);
  const now = nowIso_();
  const errors = {};

  if (!existing) {
    const row = blankRow_(SHEETS.FINDINGS);
    row.priority = 'Medium';
    Object.assign(row, fields);
    requireFields_(row, REQUIRED_FINDING_FIELDS, errors);
    throwIfErrors_(errors);

    row.finding_id = input.finding_id;
    row.project_id = input.project_id;
    const siblings = readAllRows_(SHEETS.FINDINGS).rows
      .filter(function (r) { return r.project_id === input.project_id && r.deleted !== 'Y'; });
    const maxSort = siblings.reduce(function (m, r) { return Math.max(m, r.sort_order || 0); }, 0);
    const wanted = Number(input.sort_order);
    row.sort_order = (isFinite(wanted) && wanted > 0) ? wanted : maxSort + 1;
    row.version = 1; row.created_at = now; row.updated_at = now; row.last_device_id = ctx.deviceId;
    try { row.drive_folder_id = ensureFindingFolder_(proj, row).getId(); }
    catch (e) { throw apiError_('DRIVE_ERROR', 'Could not create the finding folder: ' + e.message); }
    appendRowObj_(SHEETS.FINDINGS, row);
    return { finding: pub_(row), created: true, changed: true };
  }

  if (existing.project_id !== input.project_id) {
    throw apiError_('VALIDATION', 'This finding belongs to a different project.');
  }
  if (existing.deleted === 'Y') {
    throw apiError_('DELETED_ON_SERVER', 'This finding was deleted on the server.', { serverFinding: pub_(existing) });
  }
  if (Number(p.baseVersion) !== existing.version) {
    throw apiError_('CONFLICT', 'This finding was changed on another device.', { serverFinding: pub_(existing) });
  }

  const changedKeys = Object.keys(fields).filter(function (k) { return existing[k] !== fields[k]; });
  if (!changedKeys.length) return { finding: pub_(existing), created: false, changed: false };

  const merged = Object.assign({}, existing, fields);
  requireFields_(merged, REQUIRED_FINDING_FIELDS, errors);
  throwIfErrors_(errors);
  merged.version = existing.version + 1;
  merged.updated_at = now;
  merged.last_device_id = ctx.deviceId;
  writeRowObj_(SHEETS.FINDINGS, existing._row, merged);
  if (changedKeys.indexOf('area_location') > -1) tryRenameFolder_(merged.drive_folder_id, findingFolderName_(merged));
  return { finding: pub_(merged), created: false, changed: true };
}

/** payload: { findingId }. Also hides the finding's photos (Drive files are kept). */
function apiDeleteFinding_(p) {
  requireId_('finding', p.findingId, 'findingId');
  const f = findRowById_(SHEETS.FINDINGS, 'finding_id', p.findingId);
  if (!f) return { alreadyGone: true };
  if (f.deleted === 'Y') return { finding: pub_(f), alreadyDeleted: true };
  const ts = nowIso_();
  f.deleted = 'Y'; f.deleted_at = ts; f.updated_at = ts; f.version += 1;
  writeRowObj_(SHEETS.FINDINGS, f._row, f);
  softDeleteWhere_(SHEETS.PHOTOS, 'finding_id', p.findingId, ts);
  return { finding: pub_(f) };
}

/** payload: { projectId, order:[finding_id, ...] }. Findings missing from the list keep their relative order at the end. */
function apiReorderFindings_(p) {
  requireId_('project', p.projectId, 'projectId');
  const rows = readAllRows_(SHEETS.FINDINGS).rows
    .filter(function (r) { return r.project_id === p.projectId && r.deleted !== 'Y'; })
    .sort(bySortOrder_);
  const byId = {};
  rows.forEach(function (r) { byId[r.finding_id] = r; });

  const final = [];
  (Array.isArray(p.order) ? p.order : []).forEach(function (id) {
    if (byId[id] && final.indexOf(id) === -1) final.push(id);
  });
  rows.forEach(function (r) { if (final.indexOf(r.finding_id) === -1) final.push(r.finding_id); });

  final.forEach(function (id, i) {
    const r = byId[id];
    if (r.sort_order !== i + 1) { r.sort_order = i + 1; writeRowObj_(SHEETS.FINDINGS, r._row, r); }
  });
  return { projectId: p.projectId, order: final };
}
