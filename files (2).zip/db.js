/* Marble Site Audit - db.js
   Three things live here:
     Bus    - tiny event system (screens listen for changes)
     DB     - low-level IndexedDB helpers
     Store  - the offline-first data layer the screens use

   HOW OFFLINE SYNC WORKS (important):
   Every project, finding, photo and report saved on the phone carries flags:
     _dirty / _metaDirty / _uploaded  = "the server does not have this yet"
     _deleted                         = "deleted here, server not told yet"
     _op                              = id of the latest local change (makes retries safe)
     version                          = the server version this copy was based on (null = never synced)
   The "queue" of pending work is simply every record whose flags say it is not on the server yet.
   Nothing is removed from the phone until the server has confirmed it. */
(function () {
  'use strict';
  const C = window.APP_CONFIG;

  /* ---------------- Event bus ---------------- */
  const handlers = {};
  window.Bus = {
    on(evt, fn) { (handlers[evt] = handlers[evt] || []).push(fn); },
    off(evt, fn) { handlers[evt] = (handlers[evt] || []).filter(function (f) { return f !== fn; }); },
    emit(evt, data) {
      (handlers[evt] || []).slice().forEach(function (f) { try { f(data); } catch (e) { console.error(e); } });
    }
  };

  /* ---------------- IndexedDB ---------------- */
  const STORES = {
    projects:    { keyPath: 'project_id' },
    findings:    { keyPath: 'finding_id', indexes: ['project_id'] },
    photos:      { keyPath: 'photo_id', indexes: ['project_id', 'finding_id'] },
    photoBlobs:  { keyPath: 'photo_id' },
    reports:     { keyPath: 'report_id', indexes: ['project_id'] },
    reportBlobs: { keyPath: 'report_id' },
    meta:        { keyPath: 'key' }
  };
  const DATA_STORES = ['projects', 'findings', 'photos', 'photoBlobs', 'reports', 'reportBlobs'];
  const REMOVE = { remove: true };
  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise(function (resolve, reject) {
      const req = indexedDB.open(C.DB_NAME, C.DB_VERSION);
      req.onupgradeneeded = function () {
        const db = req.result;
        Object.keys(STORES).forEach(function (name) {
          if (db.objectStoreNames.contains(name)) return;
          const os = db.createObjectStore(name, { keyPath: STORES[name].keyPath });
          (STORES[name].indexes || []).forEach(function (ix) { os.createIndex(ix, ix); });
        });
      };
      req.onsuccess = function () {
        const db = req.result;
        db.onversionchange = function () { db.close(); };
        resolve(db);
      };
      req.onerror = function () { reject(req.error || new Error('Local storage could not be opened.')); };
      req.onblocked = function () { reject(new Error('Close other tabs of this app, then reload.')); };
    });
    return dbPromise;
  }

  function reqP(r) {
    return new Promise(function (res, rej) { r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; });
  }
  function txDone(tx) {
    return new Promise(function (res, rej) {
      tx.oncomplete = function () { res(); };
      tx.onerror = function () { rej(tx.error); };
      tx.onabort = function () { rej(tx.error || new Error('Local storage write was cancelled.')); };
    });
  }

  const DB = {
    REMOVE: REMOVE,
    open: open,
    async get(store, key) {
      const db = await open();
      return reqP(db.transaction(store).objectStore(store).get(key));
    },
    async put(store, value) {
      const db = await open();
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).put(value);
      await txDone(tx);
      return value;
    },
    async del(store, key) {
      const db = await open();
      const tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).delete(key);
      await txDone(tx);
    },
    async getAll(store) {
      const db = await open();
      return reqP(db.transaction(store).objectStore(store).getAll());
    },
    async byIndex(store, index, value) {
      const db = await open();
      return reqP(db.transaction(store).objectStore(store).index(index).getAll(IDBKeyRange.only(value)));
    },
    /* Atomic read-modify-write. fn gets a copy of the record (or undefined) and returns the
       record to save, DB.REMOVE to delete it, or a falsy value to leave it unchanged. */
    update(store, key, fn) {
      return open().then(function (db) {
        return new Promise(function (resolve, reject) {
          const tx = db.transaction(store, 'readwrite');
          const os = tx.objectStore(store);
          let result;
          const g = os.get(key);
          g.onsuccess = function () {
            let out;
            try { out = fn(g.result ? Object.assign({}, g.result) : undefined); }
            catch (e) { try { tx.abort(); } catch (x) { /* already aborted */ } reject(e); return; }
            if (out === REMOVE) { os.delete(key); result = undefined; }
            else if (out) { os.put(out); result = out; }
            else result = g.result;
          };
          tx.oncomplete = function () { resolve(result); };
          tx.onerror = function () { reject(tx.error); };
          tx.onabort = function () { reject(tx.error || new Error('Local storage write was cancelled.')); };
        });
      });
    },
    async clearData() {
      const db = await open();
      const tx = db.transaction(DATA_STORES, 'readwrite');
      DATA_STORES.forEach(function (s) { tx.objectStore(s).clear(); });
      await txDone(tx);
    },
    meta: {
      async get(key) { const r = await DB.get('meta', key); return r ? r.value : undefined; },
      set(key, value) { return DB.put('meta', { key: key, value: value }); },
      del(key) { return DB.del('meta', key); }
    },
    async storageInfo() {
      const info = { usage: null, quota: null, persisted: null };
      try {
        if (navigator.storage && navigator.storage.estimate) {
          const e = await navigator.storage.estimate();
          info.usage = e.usage; info.quota = e.quota;
        }
        if (navigator.storage && navigator.storage.persisted) info.persisted = await navigator.storage.persisted();
      } catch (e) { /* not supported */ }
      return info;
    },
    async requestPersistence() {
      try { return !!(navigator.storage && navigator.storage.persist && await navigator.storage.persist()); }
      catch (e) { return false; }
    }
  };
  window.DB = DB;

  /* ---------------- Helpers ---------------- */
  const PROJECT_FIELDS = ['project_name', 'client_name', 'building_name', 'site_location', 'contact_person',
    'contact_phone', 'contact_email', 'inspection_datetime', 'inspector_name', 'job_reference', 'status',
    'general_notes', 'overall_condition', 'executive_summary', 'overall_recommendations', 'client_rep_name'];
  const FINDING_FIELDS = ['area_location', 'material_type', 'finish', 'finish_other', 'defect_category',
    'defect_category_other', 'existing_condition', 'defect_description', 'possible_cause', 'recommended_method',
    'required_materials', 'estimated_area_sqm', 'priority', 'inspector_remarks', 'client_remarks', 'next_action'];
  const ID_FORMAT = { project: ['PRJ', 6], finding: ['FND', 6], photo: ['PHT', 8], report: ['RPT', 6] };
  const ALNUM = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

  function nowIso() { return new Date().toISOString(); }
  function randChars(n) {
    const a = new Uint8Array(n);
    crypto.getRandomValues(a);
    return Array.from(a, function (b) { return ALNUM.charAt(b % 36); }).join('');
  }
  function newId(kind) {
    const f = ID_FORMAT[kind];
    return f[0] + '-' + new Date().toISOString().slice(0, 10).replace(/-/g, '') + '-' + randChars(f[1]);
  }
  function newOp(prefix) {
    const a = new Uint8Array(12);
    crypto.getRandomValues(a);
    return (prefix || 'o') + Array.from(a, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }
  function pick(obj, keys) {
    const o = {};
    keys.forEach(function (k) { if (obj && Object.prototype.hasOwnProperty.call(obj, k)) o[k] = obj[k]; });
    return o;
  }
  function blank(keys) { const o = {}; keys.forEach(function (k) { o[k] = ''; }); return o; }
  function projectFlags() {
    return { _dirty: false, _op: null, _deleted: false, _conflict: null, _syncError: null, _stale: false,
      _orderDirty: false, _orderOp: null, _restore: false, _full: false };
  }
  function findingFlags() { return { _dirty: false, _op: null, _deleted: false, _conflict: null, _syncError: null }; }
  function changed(rec, fields) {
    return Object.keys(fields).some(function (k) { return rec[k] !== fields[k]; });
  }
  function emit(kind, id, extra) { Bus.emit('data-changed', Object.assign({ kind: kind, id: id }, extra || {})); }

  /* ---------------- Store ---------------- */
  const Store = {
    PROJECT_FIELDS: PROJECT_FIELDS,
    FINDING_FIELDS: FINDING_FIELDS,
    newId: newId, newOp: newOp, pick: pick, nowIso: nowIso,
    projectFlags: projectFlags, findingFlags: findingFlags,
    deviceId: '',

    async init() {
      await open();
      let id = await DB.meta.get('deviceId');
      if (!id) { id = 'D' + randChars(12); await DB.meta.set('deviceId', id); }
      this.deviceId = id;
      return id;
    },
    getDeviceId() { return this.deviceId; },

    /* ----- Projects ----- */
    async createProject(fields) {
      const now = nowIso();
      const rec = Object.assign(blank(PROJECT_FIELDS), { status: 'Draft' }, pick(fields, PROJECT_FIELDS), projectFlags(), {
        project_id: newId('project'), version: null, created_at: now, updated_at: now,
        latest_report_id: '', drive_folder_id: '', photos_folder_id: '', reports_folder_id: '', supporting_folder_id: '',
        _full: true, _dirty: true, _op: newOp(), _localUpdated: now
      });
      await DB.put('projects', rec);
      emit('project', rec.project_id);
      return rec;
    },
    async saveProject(id, fields) {
      const clean = pick(fields, PROJECT_FIELDS);
      let didChange = false;
      const rec = await DB.update('projects', id, function (r) {
        if (!r || !changed(r, clean)) return null;
        Object.assign(r, clean);
        r._dirty = true; r._op = newOp(); r._localUpdated = nowIso();
        if (!r._conflict) r._syncError = null;
        didChange = true;
        return r;
      });
      if (didChange) emit('project', id);
      return rec;
    },
    getProject(id) { return DB.get('projects', id); },
    async listProjects() {
      return (await DB.getAll('projects')).filter(function (p) { return !p._deleted; });
    },
    async deleteProject(id) {
      const p = await DB.get('projects', id);
      if (!p) return;
      if (p.version === null) await this.removeProjectLocal(id);   // never reached the server: just forget it
      else {
        await DB.update('projects', id, function (r) {
          if (!r) return null;
          r._deleted = true; r._op = newOp(); r._syncError = null; r._conflict = null;
          return r;
        });
      }
      emit('project', id);
    },
    async removeProjectLocal(id) {
      const fs = await DB.byIndex('findings', 'project_id', id);
      for (const f of fs) await this.removeFindingLocal(f.finding_id, true);
      const ps = await DB.byIndex('photos', 'project_id', id);
      for (const ph of ps) await this.removePhotoLocal(ph.photo_id);
      const rs = await DB.byIndex('reports', 'project_id', id);
      for (const r of rs) { await DB.del('reports', r.report_id); await DB.del('reportBlobs', r.report_id); }
      await DB.del('projects', id);
      emit('project', id);
    },
    async hasPendingChildren(projectId) {
      const fs = await DB.byIndex('findings', 'project_id', projectId);
      if (fs.some(function (f) { return f._dirty || f._deleted; })) return true;
      const ps = await DB.byIndex('photos', 'project_id', projectId);
      if (ps.some(function (p) { return !p._uploaded || p._metaDirty || p._deleted; })) return true;
      const rs = await DB.byIndex('reports', 'project_id', projectId);
      return rs.some(function (r) { return !r._uploaded || r._deleted; });
    },

    /* ----- Findings ----- */
    async listFindings(projectId) {
      return (await DB.byIndex('findings', 'project_id', projectId))
        .filter(function (f) { return !f._deleted; })
        .sort(function (a, b) {
          return ((a.sort_order || 0) - (b.sort_order || 0)) || String(a.created_at).localeCompare(String(b.created_at));
        });
    },
    getFinding(id) { return DB.get('findings', id); },
    async createFinding(projectId, fields) {
      const siblings = await this.listFindings(projectId);
      const max = siblings.reduce(function (m, f) { return Math.max(m, f.sort_order || 0); }, 0);
      const now = nowIso();
      const rec = Object.assign(blank(FINDING_FIELDS), { priority: 'Medium', estimated_area_sqm: null },
        pick(fields, FINDING_FIELDS), findingFlags(), {
          finding_id: newId('finding'), project_id: projectId, sort_order: max + 1, version: null,
          created_at: now, updated_at: now, drive_folder_id: '', _dirty: true, _op: newOp()
        });
      await DB.put('findings', rec);
      emit('finding', rec.finding_id);
      return rec;
    },
    async saveFinding(id, fields) {
      const clean = pick(fields, FINDING_FIELDS);
      let didChange = false;
      const rec = await DB.update('findings', id, function (r) {
        if (!r || !changed(r, clean)) return null;
        Object.assign(r, clean);
        r._dirty = true; r._op = newOp();
        if (!r._conflict) r._syncError = null;
        didChange = true;
        return r;
      });
      if (didChange) emit('finding', id);
      return rec;
    },
    async deleteFinding(id) {
      const f = await DB.get('findings', id);
      if (!f) return;
      if (f.version === null) await this.removeFindingLocal(id);
      else {
        // Photos that never reached the server can be dropped now; the rest go when the server confirms.
        const ps = await DB.byIndex('photos', 'finding_id', id);
        for (const ph of ps) if (!ph.drive_file_id) await this.removePhotoLocal(ph.photo_id);
        await DB.update('findings', id, function (r) {
          if (!r) return null;
          r._deleted = true; r._op = newOp(); r._syncError = null; r._conflict = null;
          return r;
        });
      }
      emit('finding', id);
    },
    async removeFindingLocal(id, skipEmit) {
      const ps = await DB.byIndex('photos', 'finding_id', id);
      for (const ph of ps) await this.removePhotoLocal(ph.photo_id);
      await DB.del('findings', id);
      if (!skipEmit) emit('finding', id);
    },
    async removePhotoLocal(photoId) {
      await DB.del('photos', photoId);
      await DB.del('photoBlobs', photoId);
      if (window.Photos && window.Photos.revokeUrl) window.Photos.revokeUrl(photoId);
    },
    /* dir = -1 (up) or +1 (down). Re-numbers every finding so the order is unambiguous. */
    async moveFinding(projectId, findingId, dir) {
      const list = await this.listFindings(projectId);
      const i = list.findIndex(function (f) { return f.finding_id === findingId; });
      const j = i + dir;
      if (i < 0 || j < 0 || j >= list.length) return false;
      const tmp = list[i]; list[i] = list[j]; list[j] = tmp;
      for (let k = 0; k < list.length; k++) {
        if (list[k].sort_order !== k + 1) {
          await DB.update('findings', list[k].finding_id, function (r) { if (!r) return null; r.sort_order = k + 1; return r; });
        }
      }
      await DB.update('projects', projectId, function (r) { if (!r) return null; r._orderDirty = true; r._orderOp = newOp('s'); return r; });
      emit('project', projectId);
      return true;
    },

    /* ----- Reports ----- */
    async addReport(meta, blob) {
      const rec = Object.assign({
        report_id: newId('report'), drive_file_id: '', drive_url: '', generated_by_device: this.deviceId,
        _uploaded: false, _deleted: false, _op: null, _syncError: null
      }, meta);
      await DB.put('reportBlobs', { report_id: rec.report_id, blob: blob });
      await DB.put('reports', rec);
      emit('report', rec.report_id);
      return rec;
    },
    async listReports(projectId) {
      return (await DB.byIndex('reports', 'project_id', projectId))
        .filter(function (r) { return !r._deleted; })
        .sort(function (a, b) { return String(b.generated_at).localeCompare(String(a.generated_at)); });
    },
    async deleteReport(id) {
      const r = await DB.get('reports', id);
      if (!r) return;
      if (!r._uploaded && !r.drive_file_id) { await DB.del('reports', id); await DB.del('reportBlobs', id); }
      else await DB.update('reports', id, function (x) { if (!x) return null; x._deleted = true; x._op = newOp(); x._syncError = null; return x; });
      emit('report', id);
    },

    /* ----- Payloads sent to the server (no internal _flags) ----- */
    projectPayload(p) { return Object.assign({ project_id: p.project_id }, pick(p, PROJECT_FIELDS)); },
    findingPayload(f) {
      return Object.assign({ finding_id: f.finding_id, project_id: f.project_id, sort_order: f.sort_order }, pick(f, FINDING_FIELDS));
    },
    photoPayload(p) {
      return pick(p, ['photo_id', 'project_id', 'finding_id', 'stage', 'caption', 'sort_order', 'file_name',
        'mime_type', 'width', 'height', 'content_hash', 'captured_at']);
    },

    /* ----- Everything that still has to reach the server (this IS the sync queue) ----- */
    async getPending() {
      const all = await Promise.all(['projects', 'findings', 'photos', 'reports'].map(function (s) { return DB.getAll(s); }));
      const projects = all[0], findings = all[1], photos = all[2], reports = all[3];
      const items = [];
      const stateOf = function (r) { return r._conflict ? 'conflict' : (r._syncError ? (r._syncError.waiting ? 'waiting' : 'error') : 'pending'); };
      const errOf = function (r) { return r._conflict ? 'Changed on another device. Tap to decide.' : (r._syncError ? r._syncError.message : ''); };
      const pName = {};
      projects.forEach(function (p) { pName[p.project_id] = p.project_name; });

      projects.forEach(function (p) {
        if (p._deleted) items.push({ kind: 'project', id: p.project_id, projectId: p.project_id, label: 'Delete project: ' + p.project_name, state: stateOf(p), error: errOf(p) });
        else if (p._dirty || p._restore || p._orderDirty) items.push({ kind: 'project', id: p.project_id, projectId: p.project_id, label: (p.version === null ? 'New project: ' : 'Project changes: ') + p.project_name, state: stateOf(p), error: errOf(p) });
      });
      findings.forEach(function (f) {
        if (f._deleted) items.push({ kind: 'finding', id: f.finding_id, projectId: f.project_id, label: 'Delete finding: ' + f.area_location, state: stateOf(f), error: errOf(f) });
        else if (f._dirty) items.push({ kind: 'finding', id: f.finding_id, projectId: f.project_id, label: (f.version === null ? 'New finding: ' : 'Finding changes: ') + f.area_location + ' (' + (pName[f.project_id] || '') + ')', state: stateOf(f), error: errOf(f) });
      });
      photos.forEach(function (ph) {
        const nm = ph.caption || ph.file_name || ph.photo_id;
        if (ph._deleted) { if (ph.drive_file_id) items.push({ kind: 'photo', id: ph.photo_id, projectId: ph.project_id, label: 'Delete photo: ' + nm, state: stateOf(ph), error: errOf(ph) }); }
        else if (!ph._uploaded) items.push({ kind: 'photo', id: ph.photo_id, projectId: ph.project_id, label: 'Upload photo: ' + nm, state: stateOf(ph), error: errOf(ph) });
        else if (ph._metaDirty) items.push({ kind: 'photo', id: ph.photo_id, projectId: ph.project_id, label: 'Photo details: ' + nm, state: stateOf(ph), error: errOf(ph) });
      });
      reports.forEach(function (r) {
        if (r._deleted) items.push({ kind: 'report', id: r.report_id, projectId: r.project_id, label: 'Delete report: ' + r.file_name, state: stateOf(r), error: errOf(r) });
        else if (!r._uploaded) items.push({ kind: 'report', id: r.report_id, projectId: r.project_id, label: 'Upload report: ' + r.file_name, state: stateOf(r), error: errOf(r) });
      });
      return items;
    },

    /* ----- Merging what the server sends into local storage (never overwrites unsynced local work) ----- */
    async applyBundle(b, opts) {
      opts = opts || {};
      const sp = b.project, pid = sp.project_id;
      const lp = await DB.get('projects', pid);
      if (!(lp && (lp._dirty || lp._deleted || lp._restore) && !opts.force)) {
        await DB.put('projects', Object.assign(projectFlags(), sp, { _full: true }));
      }

      const localF = await DB.byIndex('findings', 'project_id', pid);
      const srvF = {};
      for (const sf of b.findings) {
        srvF[sf.finding_id] = true;
        const lf = localF.find(function (x) { return x.finding_id === sf.finding_id; });
        if (lf && (lf._dirty || lf._deleted) && !opts.force) continue;
        await DB.put('findings', Object.assign(findingFlags(), sf));
      }
      for (const lf of localF) {
        if (!srvF[lf.finding_id] && lf.version !== null && !lf._dirty && !lf._deleted) await this.removeFindingLocal(lf.finding_id, true);
      }

      const localP = await DB.byIndex('photos', 'project_id', pid);
      const srvP = {};
      for (const sph of b.photos) {
        srvP[sph.photo_id] = true;
        const lph = localP.find(function (x) { return x.photo_id === sph.photo_id; });
        if (lph && (lph._metaDirty || lph._deleted || !lph._uploaded)) continue;
        if (lph && lph.content_hash !== sph.content_hash) {
          await DB.del('photoBlobs', sph.photo_id);
          if (window.Photos) window.Photos.revokeUrl(sph.photo_id);
        }
        await DB.put('photos', Object.assign({ _uploaded: true, _metaDirty: false, _metaOp: null, _deleted: false, _syncError: null }, sph));
      }
      for (const lph of localP) {
        if (!srvP[lph.photo_id] && lph._uploaded && !lph._metaDirty && !lph._deleted) await this.removePhotoLocal(lph.photo_id);
      }

      const localR = await DB.byIndex('reports', 'project_id', pid);
      const srvR = {};
      for (const sr of b.reports) {
        srvR[sr.report_id] = true;
        const lr = localR.find(function (x) { return x.report_id === sr.report_id; });
        if (lr && (lr._deleted || !lr._uploaded)) continue;
        await DB.put('reports', Object.assign({ _uploaded: true, _deleted: false, _op: null, _syncError: null }, sr));
      }
      for (const lr of localR) {
        if (!srvR[lr.report_id] && lr._uploaded && !lr._deleted) { await DB.del('reports', lr.report_id); await DB.del('reportBlobs', lr.report_id); }
      }
      emit('project', pid, { source: 'sync' });
    },

    /* ----- Copies (used for "save mine as a new copy" and local duplicates) ----- */
    async copyFindingPhotos(fromFindingId, toProjectId, toFindingId) {
      let skipped = 0;
      const photos = await window.Photos.listForFinding(fromFindingId);
      for (const ph of photos) {
        const blob = await window.Photos.getBlob(ph.photo_id);
        if (!blob) { skipped++; continue; }
        await window.Photos.addPhoto({
          projectId: toProjectId, findingId: toFindingId, stage: ph.stage, caption: ph.caption,
          processed: { blob: blob, mime_type: ph.mime_type, width: ph.width, height: ph.height, size_bytes: ph.size_bytes, content_hash: ph.content_hash, file_name: ph.file_name }
        });
      }
      return skipped;
    },
    async copyFinding(id) {
      const f = await DB.get('findings', id);
      if (!f) throw new Error('Finding not found.');
      const nf = await this.createFinding(f.project_id, Object.assign(pick(f, FINDING_FIELDS), { area_location: (f.area_location + ' (copy)').slice(0, 300) }));
      const skipped = await this.copyFindingPhotos(id, f.project_id, nf.finding_id);
      return { finding: nf, skippedPhotos: skipped };
    },
    async copyProject(id) {
      const p = await DB.get('projects', id);
      if (!p) throw new Error('Project not found.');
      const np = await this.createProject(Object.assign(pick(p, PROJECT_FIELDS), { project_name: (p.project_name + ' (Copy)').slice(0, 300), status: 'Draft' }));
      let skipped = 0;
      for (const f of await this.listFindings(id)) {
        const nf = await this.createFinding(np.project_id, pick(f, FINDING_FIELDS));
        skipped += await this.copyFindingPhotos(f.finding_id, np.project_id, nf.finding_id);
      }
      return { project: np, skippedPhotos: skipped };
    },

    async clearAllLocal() {
      await DB.clearData();
      await DB.meta.del('lastSync');
      if (window.Photos) window.Photos.revokeAll();
      Bus.emit('data-changed', { kind: 'all', id: null });
    }
  };
  window.Store = Store;
})();
