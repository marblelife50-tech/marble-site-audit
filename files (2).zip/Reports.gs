/**
 * Marble Site Audit - Reports.gs
 * The PDF is built on the phone (jsPDF) and uploaded here. A report only exists once this
 * function has saved the file to Drive AND written the Reports row; the app must wait for
 * { ok:true } before saying "Report saved".
 */

/**
 * payload: { report:{report_id, project_id, file_name, project_version, content_hash, generated_at}, dataBase64 }
 */
function apiUploadReport_(p, ctx) {
  const r = p.report;
  if (!r || typeof r !== 'object') throw apiError_('VALIDATION', 'Report data is missing.');
  requireId_('report', r.report_id, 'report_id');
  requireId_('project', r.project_id, 'project_id');
  const errors = {};
  const fileName = cleanText_(r.file_name, 150, 'file_name', errors);
  const generatedAt = cleanText_(r.generated_at, 40, 'generated_at', errors);
  const projectVersion = cleanNumber_(r.project_version, 0, 1000000, 'project_version', errors);
  const hashIn = String(r.content_hash || '').toLowerCase();
  if (!HASH_RE.test(hashIn)) errors.content_hash = 'Must be a SHA-256 hex string.';
  throwIfErrors_(errors);

  const existing = findRowById_(SHEETS.REPORTS, 'report_id', r.report_id);
  if (existing && existing.deleted !== 'Y' && existing.content_hash === hashIn && getFileSafe_(existing.drive_file_id)) {
    return { report: pub_(existing), deduped: true };
  }
  if (existing && existing.deleted === 'Y') throw apiError_('GONE', 'This report was deleted on the server.');
  if (existing) throw apiError_('VALIDATION', 'This report ID was already used for a different file.');

  const proj = findRowById_(SHEETS.PROJECTS, 'project_id', r.project_id);
  if (!proj || proj.deleted === 'Y') throw apiError_('PROJECT_MISSING', 'The project is not on the server (or was deleted).');

  const bytes = decodeBase64_(p.dataBase64, CONFIG.MAX_REPORT_BYTES);
  if (bytes.length < 5 || bytes[0] !== 37 || bytes[1] !== 80 || bytes[2] !== 68 || bytes[3] !== 70) {
    throw apiError_('VALIDATION', 'The uploaded file is not a PDF.');
  }
  if (sha256Hex_(bytes) !== hashIn) throw apiError_('HASH_MISMATCH', 'The report was damaged during upload. Please retry.');

  let file;
  try {
    const saved = ensureProjectFoldersSaved_(proj);
    const folder = getFolderSafe_(saved.reports_folder_id);
    let name = safeName_(fileName || ('Report - ' + proj.project_name), 120);
    if (!/\.pdf$/i.test(name)) name += '.pdf';
    file = folder.createFile(Utilities.newBlob(bytes, 'application/pdf', name));
    file.setDescription('report_id=' + r.report_id + '; project_id=' + r.project_id);
  } catch (e) { throw apiError_('DRIVE_ERROR', 'Could not save the PDF to Drive: ' + e.message); }

  const now = nowIso_();
  const row = blankRow_(SHEETS.REPORTS);
  Object.assign(row, {
    report_id: r.report_id, project_id: r.project_id, file_name: file.getName(),
    drive_file_id: file.getId(), drive_url: file.getUrl(), project_version: projectVersion,
    size_bytes: bytes.length, content_hash: hashIn, generated_at: generatedAt || now,
    generated_by_device: ctx.deviceId
  });
  appendRowObj_(SHEETS.REPORTS, row);

  // Server-managed pointer: does not change the project's version, so it cannot cause a conflict.
  const fresh = findRowById_(SHEETS.PROJECTS, 'project_id', r.project_id);
  fresh.latest_report_id = r.report_id;
  writeRowObj_(SHEETS.PROJECTS, fresh._row, fresh);

  return { report: pub_(row), latest_report_id: r.report_id, deduped: false };
}

/** payload: { reportId } -> { report_id, file_name, dataBase64 } (for download without a Google login) */
function apiGetReportData_(p) {
  requireId_('report', p.reportId, 'reportId');
  const row = findRowById_(SHEETS.REPORTS, 'report_id', p.reportId);
  if (!row || row.deleted === 'Y') throw apiError_('NOT_FOUND', 'Report not found.');
  const file = getFileSafe_(row.drive_file_id);
  if (!file) throw apiError_('FILE_MISSING', 'The PDF file is missing from Drive.');
  return { report_id: row.report_id, file_name: row.file_name, dataBase64: Utilities.base64Encode(file.getBlob().getBytes()) };
}

/** payload: { reportId }. The PDF goes to the Drive trash. */
function apiDeleteReport_(p) {
  requireId_('report', p.reportId, 'reportId');
  const row = findRowById_(SHEETS.REPORTS, 'report_id', p.reportId);
  if (!row) return { alreadyGone: true };
  if (row.deleted === 'Y') return { report: pub_(row), alreadyDeleted: true };
  const file = getFileSafe_(row.drive_file_id);
  if (file) { try { file.setTrashed(true); } catch (e) { console.warn('PDF not trashed: ' + e.message); } }
  const ts = nowIso_();
  row.deleted = 'Y'; row.deleted_at = ts;
  writeRowObj_(SHEETS.REPORTS, row._row, row);

  const proj = findRowById_(SHEETS.PROJECTS, 'project_id', row.project_id);
  if (proj && proj.latest_report_id === row.report_id) {
    const remaining = readAllRows_(SHEETS.REPORTS).rows
      .filter(function (r) { return r.project_id === row.project_id && r.deleted !== 'Y'; })
      .sort(function (a, b) { return String(b.generated_at).localeCompare(String(a.generated_at)); });
    proj.latest_report_id = remaining.length ? remaining[0].report_id : '';
    writeRowObj_(SHEETS.PROJECTS, proj._row, proj);
  }
  return { report: pub_(row) };
}
