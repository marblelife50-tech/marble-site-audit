/**
 * Marble Site Audit - Sync.gs
 * Every write has an operationId. If the phone repeats an operation (for example because the
 * connection dropped after the server finished), the stored result is returned instead of
 * running it again. That is what prevents duplicates and false conflicts.
 * Callers already hold the script lock.
 */

function describeOp_(action, p) {
  p = p || {};
  const g = function (o, k) { return (o && o[k]) ? String(o[k]) : ''; };
  switch (action) {
    case 'saveProject':      return ['project', g(p.project, 'project_id')];
    case 'deleteProject':
    case 'restoreProject':   return ['project', g(p, 'projectId')];
    case 'duplicateProject': return ['project', g(p, 'sourceProjectId')];
    case 'saveFinding':      return ['finding', g(p.finding, 'finding_id')];
    case 'deleteFinding':    return ['finding', g(p, 'findingId')];
    case 'reorderFindings':  return ['project', g(p, 'projectId')];
    case 'uploadPhoto':
    case 'savePhotoMeta':    return ['photo', g(p.photo, 'photo_id')];
    case 'deletePhoto':      return ['photo', g(p, 'photoId')];
    case 'uploadReport':     return ['report', g(p.report, 'report_id')];
    case 'deleteReport':     return ['report', g(p, 'reportId')];
    default:                 return ['settings', ''];
  }
}

function executeWrite_(ctx, action, payload, opId) {
  if (opId) {
    const prev = findLoggedOp_(opId);
    if (prev) return { data: prev, replayed: true };
  }
  const def = actionTable_()[action];
  const desc = describeOp_(action, payload);
  try {
    const data = def.fn(payload, ctx);
    appendLog_(ctx, opId, desc[0], desc[1], action, 'OK', JSON.stringify(data));
    return { data: data, replayed: false };
  } catch (e) {
    appendLog_(ctx, opId, desc[0], desc[1], action, e.code === 'CONFLICT' ? 'CONFLICT' : 'ERROR',
      (e.code ? e.code + ': ' : '') + e.message);
    throw e;
  }
}

function findLoggedOp_(opId) {
  const t = getTable_(SHEETS.SYNC_LOG);
  const last = t.sh.getLastRow();
  if (last < 2) return null;
  const opCol = t.headers.indexOf('operation_id');
  const resCol = t.headers.indexOf('result');
  const msgCol = t.headers.indexOf('message');
  const hits = t.sh.getRange(2, opCol + 1, last - 1, 1).createTextFinder(opId).matchEntireCell(true).findAll();
  for (let i = 0; i < hits.length; i++) {
    const vals = t.sh.getRange(hits[i].getRow(), 1, 1, t.headers.length).getValues()[0];
    if (String(vals[resCol]) === 'OK') {
      try {
        const d = JSON.parse(String(vals[msgCol]));
        if (d && typeof d === 'object' && !d.__truncated) return d;
      } catch (e) { /* not replayable, run again */ }
    }
  }
  return null;
}

function appendLog_(ctx, opId, entityType, entityId, action, result, message) {
  try {
    let msg = String(message || '');
    if (result === 'OK') { if (msg.length > 45000) msg = '{"__truncated":true}'; }
    else msg = msg.slice(0, 500);
    appendRowObj_(SHEETS.SYNC_LOG, {
      log_id: Utilities.getUuid(), timestamp: nowIso_(), device_id: ctx.deviceId,
      operation_id: opId || '', entity_type: entityType, entity_id: entityId,
      action: action, result: result, message: msg
    });
  } catch (e) {
    console.error('Sync log write failed: ' + e.message); // never block a save because of logging
  }
}

/** payload: { operations: [ { operationId, action, payload } ] }  (max 25) */
function apiSyncBatch_(p, ctx) {
  const ops = Array.isArray(p.operations) ? p.operations : [];
  if (!ops.length) throw apiError_('VALIDATION', 'No operations were sent.');
  if (ops.length > 25) throw apiError_('VALIDATION', 'Send at most 25 operations per batch.');

  const results = ops.map(function (op) {
    const opId = op && op.operationId;
    try {
      if (!op || BATCHABLE_ACTIONS.indexOf(op.action) === -1) {
        throw apiError_('BAD_REQUEST', 'Action not allowed in a batch: ' + String(op && op.action).slice(0, 40));
      }
      const r = executeWrite_(ctx, op.action, op.payload || {}, cleanOpId_(opId));
      return { operationId: opId, ok: true, data: r.data, replayed: !!r.replayed };
    } catch (e) {
      return { operationId: opId, ok: false, error: errorBody_(e) };
    }
  });
  return { results: results };
}

/** Optional housekeeping: run manually now and then to keep the Sync Log small. */
function trimSyncLog() {
  const keep = 5000;
  const sh = getSheet_(SHEETS.SYNC_LOG);
  const extra = sh.getLastRow() - 1 - keep;
  if (extra > 0) sh.deleteRows(2, extra);
  Logger.log('Sync Log rows removed: ' + Math.max(extra, 0));
}
